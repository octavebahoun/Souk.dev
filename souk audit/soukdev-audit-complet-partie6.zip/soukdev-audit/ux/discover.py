import asyncio, json
from playwright.async_api import async_playwright
CH='/home/box/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome'
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path=CH)
        pg = await b.new_page(viewport={'width':1440,'height':900})
        await pg.goto('https://soukdev.shop', wait_until='networkidle', timeout=60000)
        await pg.wait_for_timeout(2000)
        links = await pg.eval_on_selector_all('a[href]', 'els=>els.map(e=>[e.href,(e.innerText||"").trim().slice(0,40)])')
        print(await pg.title())
        for l in sorted(set(map(tuple,links))): print(l)
        txt = await pg.inner_text('body'); print(txt[:3000])
        await b.close()
asyncio.run(main())

import asyncio, glob
from playwright.async_api import async_playwright
CH=glob.glob('/home/box/.cache/ms-playwright/chromium-1248/chrome-linux*/chrome')[0]
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path=CH)
    pg=await b.new_page(viewport={'width':390,'height':844})
    await pg.goto('https://soukdev.shop/',wait_until='networkidle')
    print(await pg.evaluate('''()=>[...document.querySelectorAll('button,[role=button]')].map(b=>(b.innerText.trim()||'')+'|'+(b.getAttribute('aria-label')||'')+'|'+(b.title||''))'''))
    print(await pg.evaluate('()=>[document.documentElement.className,document.documentElement.dataset.theme,localStorage.length,Object.keys(localStorage)]'))
    for path in ['/publier','/copies','/store/1/deployer','/missions','/profil','/paiements','/canaux','/etiquettes','/apps']:
      await pg.goto('https://soukdev.shop'+path,wait_until='networkidle'); await pg.wait_for_timeout(800)
      print(path,'->',pg.url,'|',(await pg.inner_text('body'))[:300].replace('\n',' / '))
    await b.close()
asyncio.run(main())

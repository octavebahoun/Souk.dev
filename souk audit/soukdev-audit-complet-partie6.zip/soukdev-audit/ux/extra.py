import asyncio, glob
from playwright.async_api import async_playwright
CH=glob.glob('/home/box/.cache/ms-playwright/chromium-1248/chrome-linux*/chrome')[0]
B='https://soukdev.shop'
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path=CH)
    for th in ['light','dark']:
      suf='' if th=='light' else '-sombre'
      ctx=await b.new_context(viewport={'width':360,'height':800},is_mobile=True,has_touch=True,locale='fr-FR',color_scheme=th)
      pg=await ctx.new_page()
      # entreprise tab
      await pg.goto(B+'/connexion',wait_until='networkidle')
      await pg.get_by_text('Entreprise ou particulier').first.click(); await pg.wait_for_timeout(700)
      await pg.screenshot(path=f'captures/connexion-entreprise-360{suf}.png',full_page=True)
      print(th,'entreprise:',(await pg.inner_text('main') if await pg.query_selector('main') else '')[:600].replace('\n',' / '))
      if th=='light':
        # inputs visible
        print(await pg.evaluate('''()=>[...document.querySelectorAll('input')].map(i=>[i.type,i.name,i.placeholder,i.autocomplete,i.inputMode,Math.round(i.getBoundingClientRect().height),getComputedStyle(i).fontSize])'''))
        # store empty search
        await pg.goto(B+'/store',wait_until='networkidle')
        inp=pg.get_by_placeholder('Stock, paiement, réservation…')
        await inp.fill('pharmacie'); await pg.wait_for_timeout(1500)
        await pg.screenshot(path='captures/store-recherche-vide-360.png',full_page=True)
        print('store vide:',(await pg.inner_text('main'))[:500].replace('\n',' / '))
        await pg.goto(B+'/store',wait_until='networkidle')
        await pg.get_by_role('button',name='Filtres').first.click(); await pg.wait_for_timeout(700)
        await pg.screenshot(path='captures/store-filtres-360.png')
        # home lazy check
        await pg.goto(B+'/',wait_until='networkidle')
        for y in range(0,6000,400): await pg.mouse.wheel(0,400); await pg.wait_for_timeout(120)
        await pg.wait_for_timeout(1500)
        el=pg.get_by_text('Des applis faites').first; await el.scroll_into_view_if_needed(); await pg.wait_for_timeout(800)
        await pg.screenshot(path='captures/accueil-carte-store-360.png')
        print('home imgs:',await pg.evaluate('()=>[...document.images].map(i=>[i.src.slice(-60),i.naturalWidth,i.loading])'))
        # focus visibility
        await pg.goto(B+'/',wait_until='networkidle')
        for i in range(3): await pg.keyboard.press('Tab')
        await pg.screenshot(path='captures/focus-clavier-360.png')
        # search desktop
      await ctx.close()
    ctx=await b.new_context(viewport={'width':1440,'height':900},locale='fr-FR')
    pg=await ctx.new_page(); await pg.goto(B+'/',wait_until='networkidle')
    await pg.get_by_role('button',name='Rechercher').first.click(); await pg.wait_for_timeout(800)
    await pg.screenshot(path='captures/recherche-globale-1440.png')
    print('recherche:',(await pg.evaluate('()=>document.activeElement.outerHTML.slice(0,200)')))
    await b.close()
asyncio.run(main())

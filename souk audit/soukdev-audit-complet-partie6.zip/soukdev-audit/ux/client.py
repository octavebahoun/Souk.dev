import asyncio, json, time, glob
from playwright.async_api import async_playwright
CH=glob.glob('/home/box/.cache/ms-playwright/chromium-1248/chrome-linux*/chrome')[0]
B='https://soukdev.shop'
exec(open('audit.py').read().split("JS='''")[0].split('VP=')[0].replace('import asyncio, json, time, glob','').replace('from playwright.async_api import async_playwright',''))  # noop for PAGES
JS="'''"+open('audit.py').read().split("JS='''")[1].split("'''")[0]+"'''"
JS=eval(JS)
CTA='''(sel)=>{const vh=innerHeight;const out=[];for(const t of sel){const el=[...document.querySelectorAll('a,button')].find(e=>e.innerText.trim().startsWith(t)&&e.getBoundingClientRect().height>0);if(el){const r=el.getBoundingClientRect();const nav=[...document.querySelectorAll('nav')].filter(n=>getComputedStyle(n).position==='fixed'&&n.getBoundingClientRect().top>vh/2).map(n=>n.getBoundingClientRect().height)[0]||0;out.push({cta:t,top:Math.round(r.top+scrollY),h:Math.round(r.height),w:Math.round(r.width),fold:vh,visibleFold:(r.bottom+scrollY)<=vh-nav,bottomNav:Math.round(nav),fs:getComputedStyle(el).fontSize,href:el.getAttribute('href')})}else out.push({cta:t,absent:true})}return out}'''
PAGES={'store':'/store','fiche-1':'/store/1','deployer':'/store/1/deployer'}
res={}
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path=CH)
    for th in ['clair','sombre']:
      for w,h in [(360,800),(390,844),(768,1024)]:
        mobile=w<768
        ctx=await b.new_context(viewport={'width':w,'height':h},is_mobile=mobile,has_touch=mobile,locale='fr-FR',color_scheme='dark' if th=='sombre' else 'light')
        for n,path in PAGES.items():
          pg=await ctx.new_page(); errs=[]
          pg.on('console',lambda m: errs.append(m.text[:150]) if m.type=='error' else None)
          t=time.time(); r=await pg.goto(B+path,wait_until='load')
          try: await pg.wait_for_load_state('networkidle',timeout=8000)
          except: pass
          await pg.wait_for_timeout(800)
          d=await pg.evaluate(JS,mobile)
          d['cta']=await pg.evaluate(CTA,['Déployer ma copie','Essayer la démo','Se connecter','Payer'])
          d['url']=pg.url; d['console']=errs; d['load']=round(time.time()-t,2)
          if w==360 and th=='clair': d['text']=(await pg.inner_text('main') if await pg.query_selector('main') else await pg.inner_text('body'))[:3000]
          await pg.screenshot(path=f'captures/client/{n}-{w}-{th}.png',full_page=True)
          await pg.screenshot(path=f'captures/client/{n}-{w}-{th}-ecran1.png')
          res[f'{n}-{w}-{th}']=d; print(n,w,th,pg.url,d['overflow'],d['nsmall'],[ (c['cta'],c.get('top'),c.get('visibleFold')) for c in d['cta'] if not c.get('absent')],flush=True)
          await pg.close()
        await ctx.close()
    # guest flow: fiche -> Déployer ma copie -> gate -> Se connecter
    ctx=await b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,locale='fr-FR')
    pg=await ctx.new_page(); await pg.goto(B+'/store/1',wait_until='networkidle')
    await pg.get_by_role('link',name='Déployer ma copie').or_(pg.get_by_role('button',name='Déployer ma copie')).first.click()
    await pg.wait_for_timeout(1500); u1=pg.url
    await pg.screenshot(path='captures/client/invite-clic-deployer-390.png')
    btn=pg.locator('main').get_by_role('link',name='Se connecter').or_(pg.locator('main').get_by_role('button',name='Se connecter')).first
    href=await btn.get_attribute('href')
    await btn.click(); await pg.wait_for_timeout(1500); u2=pg.url
    await pg.screenshot(path='captures/client/invite-gate-vers-connexion-390.png')
    ls=await pg.evaluate('()=>({ls:Object.keys(localStorage),ss:Object.keys(sessionStorage)})')
    txt=(await pg.inner_text('main'))[:600]
    res['flux_invite']={'apres_clic_deployer':u1,'href_se_connecter':href,'apres_clic_se_connecter':u2,'storage_keys':ls,'texte_connexion':txt}
    print(res['flux_invite'])
    await b.close()
  json.dump(res,open('mesures-client.json','w'),ensure_ascii=False,indent=1)
asyncio.run(main())

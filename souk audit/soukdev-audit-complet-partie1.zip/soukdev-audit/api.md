# Audit API — Souk.dev (Bot 5)

- **Cible API** : `https://api.soukdev.shop` (préfixe JSON `/api`, routes web Laravel hors `/api`)
- **Front** : `https://soukdev.shop` (SPA React/Vite ; Axios `baseURL=https://api.soukdev.shop`, helper ` /api` + `withCredentials`)
- **Contrat** : `openapi.yaml` repo public `octavebahoun/Souk.dev` @ `main` (OpenAPI 3.1.0, version 0.1.0, 123 opérations / 89 chemins) — copie locale `/workspace/souk-api/openapi/openapi.yaml`
- **Date** : 10 nov. 2026, Europe/Paris (UTC+1)
- **Méthode** : lecture seule, **sans compte**, **aucune écriture** (pas de POST/PUT/PATCH/DELETE mutateurs). Quelques dizaines de GET/OPTIONS espacés. Artefacts : `/workspace/souk-api/`
- **Hors zone (constat seulement)** : approfondissement CORS / contournement d’auth, webhooks SasPay, UX
- **Accès données d’un autre compte** : **non observé** sur les GET sans session. Les routes `/api/discussions` et `/api/canaux` répondent 200 sans auth mais sont **documentées PUBLIC** (Échange). `/api/missions`, `/api/factures`, `/api/deployments`, `/api/me*`, `/api/admin*` → **401**. Aucun email / téléphone dans les clés JSON publiques sondées.

---

## 0. STATUT FINAL — audit API terminé (2026-11-10, 12:20 heure de Paris)

**Terminé.** 4 passes : anonyme, authentifié client, croisé A/B (IDOR), rôle Développeur (lecture seule via l'UI).
- **Aucune faille Critique/Haute.** Aucun IDOR, aucun accès aux données d'un autre compte, admin → 403 pour un non-admin, routes privées → 401 sans session.
- **Moyenne (4)** : API-01 `/auth/demo` encore enregistrée (garde prod OK, cf. SEC-011) · API-02 `servers: /api` faux pour les routes web · API-03 validation `page≤0` incohérente · API-08 oracle d'existence 403/404 sur `/deployments/{id}`.
- **Basse/Faible (7)** : API-04 (basse à moyenne), 05, 09, 10, 11, 12, 13.
- **Info (3)** : API-06, 07, 14.
- **Hors périmètre / non testé** : paiement et webhook SasPay (Paiement Souk), publication Store, envoi de messages, en-têtes/CORS/contournement d'auth (Sécurité Souk), charge.
- **Verdict API pour la mise en prod** : pas bloquant ; à corriger en priorité API-08, API-01 (désenregistrer la route), API-02/API-11 (contrat OpenAPI).

## 1. Synthèse stack API

| Élément | Constat |
|---|---|
| Serveur | FrankenPHP + Caddy |
| Framework | Laravel + Sanctum (session cookie SPA) |
| Contrat | OpenAPI `servers: [{url: /api}]` — **incomplet** pour les routes web (`/sanctum`, `/auth/*`, `/logout`, `/broadcasting/auth`) qui sont en pratique à la **racine** de `api.soukdev.shop` |
| Temps réel | Reverb `wss://reverb.soukdev.shop` ; auth canal via `POST /broadcasting/auth` |
| BaaS | Pas de Supabase / Firebase dans les bundles |
| Rate limit observé | En-têtes `X-Ratelimit-Limit: 300` / `X-Ratelimit-Remaining` sur routes `/api/*` |
| Format erreur | `{"message":"..."}` ; validation `{"message":"...","errors":{champ:[...]}}` — conforme schémas `Erreur` / `ErreurValidation` |
| Messages | Français (« Introuvable. », « Non connecté. ») sauf certains 405 Laravel en anglais |

---

## 2. Tableau route par route (sondages effectués)

Légende statut : **OK** | **À vérifier** | **Problème**

| Méthode | Route | Appelée depuis (front) | Auth attendue | Code obtenu | Statut | Note |
|---|---|---|---|---|---|---|
| GET | `/sanctum/csrf-cookie` | `preparerCsrf` | Non | 204 | OK | Pose cookies session/XSRF (valeurs non reproduites) |
| GET | `/api/sanctum/csrf-cookie` | — | n/a | 404 | OK | Confirme que Sanctum n’est **pas** sous `/api` |
| OPTIONS | `/api/apps` | navigateur CORS | Non | 204 | OK | ACAO `https://soukdev.shop` + credentials (détail → Sécurité) |
| GET | `/api/apps` | Store, Accueil | Non (PUBLIC) | 200 | OK | `data`/`links`/`meta` ; 1 appli ; clés ≈ schéma `App` |
| GET | `/api/apps?page=1` | Store (infinite query) | Non | 200 | OK | |
| GET | `/api/apps?page=0` | — | Non | 200 | À vérifier | Coercition silencieuse → `current_page=1` (OpenAPI `minimum: 1`) |
| GET | `/api/apps?page=-1` | — | Non | 200 | À vérifier | Idem |
| GET | `/api/apps?page=10000` | — | Non | 200 | OK | Page vide (`data: []`), pas d’erreur |
| GET | `/api/apps?per_page=1` | — | Non | 200 | OK | |
| GET | `/api/apps?per_page=50` | — | Non | 200 | OK | Max documenté |
| GET | `/api/apps?per_page=51` / `10000` / `0` / `-1` | — | Non | 422 | OK | Messages FR + `errors.per_page` |
| GET | `/api/apps?q=…` / `gratuit=1` / `categorie` / `pays` / `prix_max` / `techno` | Store | Non | 200 | OK | Filtres fonctionnels |
| GET | `/api/apps?type_prix=unique\|mensuel` | Store | Non | 200 | OK | Enum OpenAPI |
| GET | `/api/apps?type_prix=gratuit` | — | Non | 422 | OK | « gratuit » = filtre booléen séparé, pas `TypePrix` |
| GET | `/api/apps?tri=recent\|prix_croissant\|note` | Store | Non | 200 | OK | |
| GET | `/api/apps?tri=foo\|populaire\|prix` | — | Non | 422 | OK | |
| GET | `/api/apps?securite=1\|true\|false\|0` | Store (`securite=1`) | Non | 200 | OK | Booléen Laravel |
| GET | `/api/apps?securite=ok` (non booléen) | — | Non | 200 | À vérifier | Pas de 422 ; filtre probablement ignoré |
| GET | `/api/apps/1` | Fiche | Non | 200 | OK | Schéma cohérent |
| GET | `/api/apps/999999` | — | Non | 404 | OK | `Introuvable.` |
| GET | `/api/apps/1/avis` | Fiche | Non | 200 | OK | `peut_noter`, `mon_avis` présents (doc OK) |
| GET | `/api/apps/1/versions` | Fiche / copies | Non | 200 | OK | |
| GET | `/api/events` | Evenements | Non | 200 | OK | Liste vide |
| GET | `/api/devs` | Recherche | Non | 200 | OK | 3 profils ; clés publiques (pas d’email) |
| GET | `/api/devs?page=0` | — | Non | 422 | OK | « La page commence à 1. » — **plus strict** que `/apps` |
| GET | `/api/devs/{username}` | Profil | Non | 200 | OK | Pas d’email/tél. dans les clés |
| GET | `/api/discussions` | Fil / Fiche | Non (PUBLIC doc) | 200 | OK | `data` vide ; pas de fuite privée constatée |
| GET | `/api/canaux` | Fil / admin | Non (PUBLIC doc) | 200 | OK | Liste vide |
| GET | `/api/categories` | (liste aussi en dur front) | Non | 200 | OK | 8 catégories |
| GET | `/api/technos` | — | Non | 200 | OK | 22 technos ; peu utilisée par le front scanné |
| GET | `/api/etiquettes` | — | Non | 200 | OK | 5 étiquettes ; OpenAPI only côté front |
| GET | `/api/reseaux-mobile-money` | Revenus / paiement | Non | 200 | OK | Catalogue |
| GET | `/api/me` | index (`moi`) | Oui | 401 | OK | `Non connecté.` |
| GET | `/api/me/tableau-de-bord` | Tableau | Oui | 401 | OK | |
| GET | `/api/me/revenus` (+ mouvements, reversements) | MesRevenus | Oui | 401 | OK | |
| GET | `/api/me/notifications` | PageNotifications | Oui | 401 | OK | |
| GET | `/api/me/preferences-notifications` | Réglages | Oui | 401 | OK | |
| GET | `/api/missions` | Missions | Oui | 401 | OK | |
| GET | `/api/deployments` | MesCopies | Oui | 401 | OK | |
| GET | `/api/factures` | MesPaiements | Oui | 401 | OK | |
| GET | `/api/admin/machines` | Serveurs | Oui (+ admin) | 401 | OK | |
| GET | `/api/admin/signalements` | Moderation | Oui (+ admin) | 401 | OK | |
| GET | `/api/admin/comptes` | Moderation | Oui (+ admin) | 401 | OK | |
| GET | `/api/admin/deployments` | Moderation | Oui (+ admin) | 401 | OK | |
| GET | `/api/admin/finances` | Finances | Oui (+ admin) | 401 | OK | |
| GET | `/api/admin/factures` | Finances | Oui (+ admin) | 401 | OK | |
| GET | `/api/admin/reversements` | Finances | Oui (+ admin) | 401 | OK | |
| GET | `/api/admin/rapprochements` | Finances | Oui (+ admin) | 401 | OK | |
| GET | `/auth/github?profil=dev` | Connexion | Non | 302 (ou 406 si `Accept: application/json`) | OK | Hors `/api` ; négociation de contenu à noter |
| GET | `/api/auth/github` | — | n/a | 404 | OK | |
| GET | `/auth/demo` | — (OpenAPI POST démo) | n/a | **405** | **À vérifier→Moyenne** | Route encore enregistrée (Allow: POST). Sécurité Souk **SEC-011** : POST démo → 404, session non ouverte. Aucun POST par Bot API. |
| GET | `/logout` | — | Oui | 405 | OK | POST only (attendu) |
| GET | `/api/logout` | — | n/a | 404 | OK | Logout hors `/api` |
| GET | `/broadcasting/auth` | Echo/Reverb | Oui | 403 | OK | `Action non autorisée.` |
| GET | `/api/broadcasting/auth` | — | n/a | 404 | OK | |
| GET | `/simulateur/saspay/test` | — | n/a | 404 | OK | Pas d’exposition évidente du simulateur |
| GET | `/api/this-does-not-exist` | — | n/a | 404 | OK | `Introuvable.` sans stack trace |

### Routes front présentes mais non exercées en écriture (inventaire)

Mutateurs / auth (constat d’existence dans JS + OpenAPI seulement) :  
`POST /api/apps`, `PATCH /api/apps/{id}`, `POST /api/apps/verification`, `POST /api/apps/soukdev-json`, `POST|PATCH /api/apps/{id}/avis`, `POST /api/apps/{id}/versions`, `POST /api/apps/{id}/deployments`, `POST /api/apps/{id}/missions`, `POST /api/deployments/{id}/mise-a-jour`, `POST|GET|DELETE sauvegardes`, `DELETE /api/deployments/{id}`, `POST /api/signalements`, `POST /api/events*`, `POST /api/missions/{id}/messages|note`, `POST /api/discussions/{id}/messages`, `DELETE /api/messages/{id}`, `POST /api/factures/{id}/paiement|verification`, `PUT /api/me/coordonnees-reversement`, `POST /api/me/revenus/reversements`, `PATCH /api/me`, admin `POST/PATCH/DELETE`, `POST /auth/lien-magique`, `POST /logout`, `POST /broadcasting/auth`.

OpenAPI-only (peu ou pas vus dans les chunks front scannés) :  
`GET /api/etiquettes`, `GET /api/categories` / `technos` (API existe ; front catégorise en dur pour les catégories), `POST /correctifs/{id}/*`, `POST /copies/{cle}/auth/*`, `GET|POST /paiement/facture/{id}`, `POST /webhooks/saspay`, `GET|POST /reversement/confirmer/{token}`, `GET /copie-suspendue`, `POST /auth/demo`, simulateur SasPay.

---

## 3. Problèmes classés par gravité

Format : **ID** · sévérité · repro · preuve · impact · correctif

### Moyenne

#### API-01 — Route `POST /auth/demo` encore enregistrée (garde prod OK)
- **Sévérité** : **Moyenne** (surface résiduelle ; **pas** de bypass session confirmé)
- **Repro (Sécurité Souk, SEC-011)** : `POST /auth/demo` avec CSRF valide et comptes démo documentés → **404** `Introuvable.` ; `GET /api/me` reste **401**
- **Preuve (passe 1, Bot API)** : `GET /auth/demo` → **405** avec `Allow: POST` / message listant POST — la route est toujours **enregistrée** dans le routeur
- **Impact** : pas d’ouverture de session démo en prod d’après SEC-011 ; reste une surface (énumération de méthode, bruit, risque de réactivation si la garde `DEMO_CONNEXION` régresse)
- **Correctif** : ne **pas enregistrer** la route hors `local`/`testing` (plutôt que s’appuyer seulement sur un 404 applicatif) ; référence croisée **SEC-011** dans `securite.md`
- **Note Bot API** : `/auth/demo` **n’a pas** été appelé en POST par ce bot

#### API-02 — OpenAPI `servers.url: /api` incorrect pour les routes web
- **Sévérité** : Moyenne (contrat / tooling)
- **Repro** : comparer `GET /api/sanctum/csrf-cookie` (404) vs `GET /sanctum/csrf-cookie` (204) ; idem `/auth/github`, `/logout`, `/broadcasting/auth`
- **Preuve** : sondages ci-dessus ; front Axios appelle ces chemins **sans** le préfixe `/api` (contrairement à `tr(e)=>/api${e}` pour le JSON)
- **Impact** : clients générés depuis OpenAPI appelleraient de mauvaises URL ; confusion audit / intégrateurs
- **Correctif** : documenter deux serveurs (ex. racine hôte pour web + `/api` pour JSON) ou scinder les chemins web hors du préfixe `/api` dans le contrat

#### API-03 — Validation `page` incohérente entre ressources
- **Sévérité** : Moyenne (contrat / robustesse)
- **Repro** : `GET /api/apps?page=0` et `page=-1` → **200** (`current_page=1`) ; `GET /api/devs?page=0` → **422** « La page commence à 1. »
- **Preuve** : OpenAPI paramètre partagé `Page` avec `minimum: 1` pour les listes
- **Impact** : comportement non uniforme ; clients qui s’appuient sur 422 vs coercition ; écart doc↔prod sur `/apps`
- **Correctif** : même Form Request / règle `page|integer|min:1` partout (préférer 422 explicite)

#### API-04 — Filtre booléen `securite` permissif sur valeurs non booléennes
- **Sévérité** : Basse à moyenne (validation)
- **Repro** : `GET /api/apps?securite=ok` → **200** (pas de 422) alors que le schéma OpenAPI est `boolean`
- **Preuve** : contrasté avec `type_prix=gratuit` / `tri=foo` / `categorie=inexistant` qui renvoient bien 422
- **Impact** : filtres silencieusement ignorés ; écart de validation
- **Correctif** : valider strictement `boolean` (ou `0|1|true|false`) et répondre 422 sinon

### Basse / Info

#### API-05 — Messages 405 en anglais (fuite de méthode)
- **Sévérité** : Basse
- **Repro** : `GET /auth/demo`, `GET /logout`
- **Preuve** : message Laravel anglais listant les méthodes supportées ; ailleurs 404 FR « Introuvable. »
- **Impact** : incohérence i18n ; légère fuite d’information sur les verbes autorisés
- **Correctif** : handler d’exception JSON unifié en français, message générique

#### API-06 — Front : catégories en dur vs `GET /api/categories`
- **Sévérité** : Info (cohérence UI↔API)
- **Repro** : bundle `api-DabL0bm-.js` (tableau `commerce`, `gestion`, …) alors que `/api/categories` existe et répond 200
- **Preuve** : inventaire bundles + GET `/api/categories` (8 items)
- **Impact** : risque de dérive si l’API évolue sans le front
- **Correctif** : consommer `/api/categories` (et éventuellement `/api/technos`, `/api/etiquettes`)

#### API-07 — SPA catch-all / absence robots & sitemap réels
- **Sévérité** : Info (chevauche Perf SEO ; noté pour cohérence)
- **Repro** : `GET https://soukdev.shop/robots.txt` → HTML SPA
- **Impact** : hors API à proprement parler
- **Correctif** : voir Bot Perf SEO

---

## 4. Routes auth / droits d’accès — à transmettre à Sécurité Souk

*Constats bruts uniquement — pas de tests d’intrusion, pas de POST mutateur, pas de contournement.*

| Route | Nature | Constat sans session |
|---|---|---|
| `GET /sanctum/csrf-cookie` | Init CSRF / session | 204 ; cookies `XSRF-TOKEN` (JS-readable, normal Sanctum) + `laravel-session` HttpOnly ; domain `.soukdev.shop` |
| `GET /auth/github` | OAuth | Redirect / négociation contenu ; chemin **hors** `/api` |
| `GET /auth/github/callback` | OAuth retour | Documenté OpenAPI ; non sondé en profondeur |
| `POST /auth/lien-magique` | Magic link email | Présent front + OpenAPI ; **non appelé** (écriture) |
| `GET\|POST /auth/lien-magique/{token}` | Consommation lien | Doc OpenAPI ; non exercé |
| **`POST /auth/demo`** | Connexion démo | GET 405 (enregistrée) ; POST non testé ici — **SEC-011** : POST→404 — API-01 |
| `POST /logout` | Fin session | GET → 405 (POST only) |
| `GET /api/me` | Identité session | **401** `Non connecté.` |
| `PATCH /api/me` | Profil | Auth requise (non muté) |
| `GET /api/me/tableau-de-bord` | Stats auteur | **401** |
| `GET /api/me/notifications*` / préférences | Notifs | **401** |
| `GET /api/me/revenus*` / coordonnées reversement | Argent | **401** |
| `POST /broadcasting/auth` | Canaux privés Reverb | GET → **403** ; surface WebSocket à valider avec compte |
| `GET /api/missions*` / messages | Données **privées** client↔dev | Liste **401** — bon signal |
| `GET /api/deployments*` / sauvegardes | Copies client | **401** |
| `GET /api/factures*` / paiement | Paiement | **401** ; idempotence `Idempotency-Key` côté front (Paiement) |
| `POST /api/signalements` | Signalement | Auth (non posté) |
| `GET\|POST /api/admin/*` | Admin (machines, comptes, suspensions, finances, signalements, canaux) | Tous les GET admin sondés → **401** (pas de 200 anonyme). **403 vs 401 admin** non distinguable sans compte non-admin |
| `GET /api/discussions`, `/api/canaux` | Échange public | **200** sans auth — **aligné OpenAPI PUBLIC** ; pas de contenu sensible observé (listes vides) |
| `GET /api/devs`, `/api/devs/{username}`, `/api/apps*` | Profils / store publics | **200** ; pas d’email/téléphone dans les clés JSON |
| Cookies / CORS | Session SPA | Origin verrouillée `https://soukdev.shop` + credentials (détail headers → Bot Sécurité) |

**Points pour Sécurité (sans creuser ici)**  
1. Confirmer que `DEMO_CONNEXION` est **false** en prod et que la route est absente.  
2. Avec compte **user** puis **admin** : vérifier 403 sur `/api/admin/*` pour non-admin (aujourd’hui seulement 401 anonyme).  
3. Isolation IDOR : facture / déploiement / mission / messages / notifications d’un autre compte (nécessite 2 comptes de test).  
4. `POST /broadcasting/auth` : refus canal privé d’autrui.  
5. Pas de fuite PII au-delà du profil public volontaire (github_url, username, etc.).

---

## 5. Cohérence OpenAPI ↔ prod (résumé)

| Thème | Résultat |
|---|---|
| Préfixe `/api` JSON | OK pour ressources métier |
| Routes web sous `/api` dans le YAML | **Écart** (API-02) |
| Codes 401 routes privées | OK (message FR stable) |
| 404 inconnu | OK, pas de stack trace |
| 422 validation | OK format `ErreurValidation` ; bornes `per_page` OK |
| 429 | Non déclenché (budget faible) ; limite 300 annoncée en en-tête |
| Pagination | Meta Laravel standard ; **incohérence page≤0** apps vs devs (API-03) |
| Schéma `App` / avis / versions / devs | Clés alignées sur les réponses sondées (sans recopier les valeurs) |
| `POST /auth/demo` « jamais en prod » | Route encore **enregistrée** (GET 405) ; garde prod OK d’après **SEC-011** (POST→404) — API-01 Moyenne |
| Simulateur SasPay | 404 sur chemin de test — OK apparent |
| Front vs API | Catégories en dur (API-06) ; pas d’URL localhost de prod dans les appels API (mentions `localhost` dans bundles = code Axios/libs, pas baseURL) |

---

## 6. Ce qui nécessite un compte de test pour aller plus loin

1. **Deux comptes non-admin** : tests IDOR lecture (facture, déploiement, mission, messages, notifications, sauvegardes) — **lecture seule** d’abord.  
2. **Un compte admin** + un non-admin : distinguer **401** vs **403** sur `/api/admin/*`.  
3. Session authentifiée : forme exacte de `GET /api/me`, préférences notifs, tableau de bord ; canaux Reverb privés.  
4. Parcours paiement / idempotence : **sandbox SasPay** uniquement (Bot Paiement) — ne pas payer en réel.  
5. Mutateurs contrôlés (avis, signalement) en staging si besoin de couvrir 422 de corps — hors scope de cette passe sans écriture.  
6. Confirmer l’état réel de `DEMO_CONNEXION` / absence de comptes démo utilisables (Sécurité).

---



---

## 8. Passe 2 — authentifié (compte test Entreprise / client)

- **Date** : 10 nov. 2026, Europe/Paris (UTC+1)
- **Compte** : magic link demandé pour l’alias `+audit-api` (boîte agent) ; profil obtenu `client` (Entreprise/particulier), `est_admin=false`, id interne noté seulement comme « compte test audit-api »
- **Auth** : `POST /auth/lien-magique` → mail (dossier spam) → `GET` page confirmation → `POST` consommation avec CSRF + cookie jar dédié `/workspace/souk-api/results/cookies-audit-api.txt` (**valeurs non reproduites**). Flux **faisable en curl** (session isolée, hors navigateur).
- **Non fait** : `POST /auth/demo` ; aucun paiement / publication / message à autrui / webhook
- **IDOR données étrangères** : **non observé** (aucune réponse 200 avec ressource privée d’autrui). Voir API-08 (oracle d’existence).

### 8.1 Tableau — routes protégées (session client)

| Méthode | Route | Auth / rôle | Code | Statut | Note |
|---|---|---|---|---|---|
| GET | `/api/me` | session | 200 | OK | Clés alignées schéma `Compte` (Dev+ProfilPublic+email/github_lie/est_admin/…) ; champ `email` présent (**valeur non recopiée**) |
| GET | `/api/me/tableau-de-bord` | session | 200 | OK | `totaux` + `applis` (vide) ; OK pour compte client |
| GET | `/api/me/revenus` | session | 200 | OK | Clés = schéma `Revenus` (match exact) |
| GET | `/api/me/revenus/mouvements` | session | 200 | OK | Liste vide paginée |
| GET | `/api/me/revenus/reversements` | session | 200 | OK | Liste vide |
| GET | `/api/me/coordonnees-reversement` | session | 200 | À vérifier | Corps JSON `{}` au lieu de `null` documenté (oneOf Coordonnees\|null) — **API-09** |
| GET | `/api/me/notifications` | session | 200 | OK | + `non_lues` ; data vide |
| GET | `/api/me/preferences-notifications` | session | 200 | OK | `types` (7) avec clés application/email/… |
| GET | `/api/missions` | session | 200 | OK | Vide |
| GET | `/api/deployments` (`?type=client`) | session | 200 | OK | Vide |
| GET | `/api/factures` | session | 200 | OK | Vide |
| GET | `/api/discussions` / `/api/canaux` | public+session | 200 | OK | Inchangé / vides |
| GET | `/api/admin/*` (8 routes sondées) | admin | **403** | OK | `Action non autorisée.` — distinct du 401 anonyme |
| GET | `/api/factures/1` `/2` | propriétaire | 404 | OK | Pas de fuite |
| GET | `/api/missions/1` (+ messages) | participants | 404 | OK | |
| GET | `/api/deployments/1` | propriétaire | **403** | À vérifier | Ressource probablement existante mais refusée — oracle ≠ 404 (**API-08**) |
| GET | `/api/deployments/3\|10\|999` | — | 404 | OK | Contraste avec id=1 |
| GET | `/api/deployments/1/sauvegardes` | propriétaire | 404 | OK | |
| GET | `/api/apps/1/deployments` | — | 405 | Info | POST only (anglais) |
| GET | `/api/factures?page=0` | session | 422 | OK | Strict |
| GET | `/api/missions?page=-1` | session | 200 | À vérifier | Coercition `current_page=1` (comme `/apps`) — complète API-03 |
| GET | `/api/deployments?per_page=100` | session | 422 | OK | Cap 50 |
| PATCH | `/api/me` pays invalide | session | 422 | OK | `errors.pays` FR |
| PATCH | `/api/me` `{nom, champ_inconnu}` | session | 200 | À vérifier | Champs hors `CompteModification` **ignorés** (pas de 422) — **API-10** |
| PATCH | `/api/me` `{bio:"audit-api"}` puis `{bio:null}` | session | 200 | OK | Écriture réversible sur ressource propre |
| PUT | `/api/me/preferences-notifications` type inexistant | session | 422 | OK | `preferences.0.type` |

### 8.2 Nouveaux problèmes (passe 2)

#### API-08 — Oracle d’existence sur `GET /api/deployments/{id}`
- **Sévérité** : Moyenne (info disclosure / énumération ; **pas** de lecture de données étrangères constatée)
- **Repro** : session client ; `GET /api/deployments/1` → **403** `Action non autorisée.` ; `GET /api/deployments/3` (et 10, 999) → **404** `Introuvable.`
- **Preuve** : sondages passe 2 ; aucune donnée de déploiement d’autrui dans le corps
- **Impact** : un compte authentifié peut inférer qu’un id de copie existe ; utile à un attaquant ciblant des IDs séquentiels
- **Correctif** : répondre **404** uniforme pour « pas le propriétaire » (comme factures/missions), sans distinguer existence
- **Transmission** : signaler à Sécurité Souk (constat brut, pas d’exploitation)

#### API-09 — `GET /api/me/coordonnees-reversement` renvoie `{}` au lieu de `null`
- **Sévérité** : Basse (contrat)
- **Repro** : compte sans coordonnées ; GET → 200 body `{}`
- **Preuve** : OpenAPI `oneOf: CoordonneesReversement | null`
- **Impact** : clients générés / front qui testent `=== null` peuvent mal gérer l’état vide
- **Correctif** : sérialiser `null` JSON, ou documenter objet vide / 204

#### API-10 — `PATCH /api/me` ignore les propriétés inconnues (`nom`, etc.)
- **Sévérité** : Basse
- **Repro** : `PATCH /api/me` avec `{"nom":"audit-api","champ_inconnu_audit":123}` → **200** ; `nom` reste `null` (non prévu dans `CompteModification`)
- **Preuve** : contraste avec `pays` invalide → 422
- **Impact** : faux sentiment de succès côté client ; dérive de contrat
- **Correctif** : `additionalProperties: false` + 422 sur champs inconnus (ou documenter l’ignorance)

### 8.3 Auth / droits — complément pour Sécurité Souk

| Constat | Détail |
|---|---|
| Magic link curl | OK bout-en-bout avec cookie jar isolé |
| Mail | Remis en **spam** côté boîte agent ; expéditeur `souk@send.excellenceteam.site` |
| Admin | Anonyme **401** ; client **403** — comportement attendu |
| IDOR lecture | Pas de body 200 sur facture/mission/déploiement d’autrui |
| Oracle | **API-08** deployments 403 vs 404 |
| `/me` | Expose `email` au titulaire (attendu) ; ne pas logger la valeur |
| Écriture bio | PATCH bio réversible OK |

### 8.4 Toujours nécessaire pour aller plus loin

1. Second compte (autre client / dev) pour IDOR croisé sur **ses** factures/missions avec ids réels.  
2. Compte **dev** (GitHub) pour tableau de bord non vide, publications, Échange.  
3. Compte **admin** pour chemins admin 200 et contraste.  
4. Déploiement/facture sandbox pour schémas non vides + paiement (Bot Paiement).




---

## 9. Passe 3 — croisé A/B (IDOR)

- **Date** : 10 nov. 2026, Europe/Paris (UTC+1)
- **Compte A** : session passe 2 (`+audit-api`), id interne 8, `profil=client`, non-admin
- **Compte B** : créé via lien magique curl pour `+audit-api-b` (mail spam), cookie jar séparé `cookies-audit-api-b.txt` (valeurs non reproduites), id interne 9, `profil=client`, non-admin
- **Ressources initiales A** : missions / deployments / factures / discussions / events / notifications = **vides**
- **Ressource de test** : A a créé **un événement** temporaire (`POST /api/events` → id=1), puis **supprimé** en fin de passe (`DELETE` → 204, GET → 404). Titre préfixé audit ; pas de paiement / message à autrui / publication Store. *Note* : le détail d’événement est **public par design** (OpenAPI) ; la partie « privée » testée = participants + mutations.
- **IDOR données de A vues/modifiées par B** : **non observé**
- **Données d’un vrai utilisateur** : aucun body 200 privé d’autrui recopié ; arrêt non déclenché

### 9.1 Résultats croisés

| Qui | Méthode | Route | Code | Attendu | Statut | Note |
|---|---|---|---|---|---|---|
| A vs B | GET | `/api/me` | 200 / 200 | ids distincts | OK | A=8, B=9 ; pas de mélange de session |
| B | PATCH | `/api/me` bio temp puis null | 200 | propre compte | OK | bio A inchangée |
| A | POST | `/api/events` | 201 | création test | OK | id=1 |
| A | GET | `/api/events/1` | 200 | owner | OK | |
| A | GET | `/api/events/1/participants` | 200 | owner | OK | |
| B | GET | `/api/events/1` | 200 | public doc | OK | Pas une faille (contrat PUBLIC) |
| B | GET | `/api/events/1/participants` | **403** | 403/404 | OK | `Action non autorisée.` |
| B | PATCH | `/api/events/1` | **403** | deny | OK | ressource A inchangée ensuite |
| B | DELETE | `/api/events/1` | **403** | deny | OK | |
| B | GET | `/api/factures/1` | 404 | 403/404 | OK | |
| B | GET | `/api/missions/1` | 404 | 403/404 | OK | |
| B | GET | `/api/deployments/1` | **403** | 403/404 | À vérifier | Renforce **API-08** (oracle 403 vs 404) — pas de body, pas les données de l’event A |
| A | DELETE | `/api/events/1` | 204 | cleanup | OK | |
| A | GET | `/api/events/1` | 404 | disparu | OK | cleanup vérifié |

### 9.2 Synthèse IDOR

- **Pas de faille IDOR A→B** sur l’événement de test (participants / PATCH / DELETE).
- Isolation session `/api/me` OK.
- Compte client sans factures/copies/missions : couverture IDOR limitée sur ces familles ; à refaire quand A aura des ids réels (sandbox paiement / mission entre comptes de test).
- Oracle `deployments/{id}` (API-08) toujours visible depuis B.

### 9.3 Nettoyage

- Événement de test A **supprimé** (GET → 404).
- Bios temporaires restaurées (`null`).
- Jars cookies conservés hors rapport (non affichés) ; probes pass3 scrubbés (tokens/cookies masqués).


## 10. Passe 4 — rôle Développeur (vrai compte du propriétaire, lecture seule, via l'UI)

Méthode : navigation des pages dev uniquement, relevé onglet Réseau (Fetch/XHR). Aucune écriture, aucun corps de réponse lu, aucune sonde sur ids devinés ou routes admin depuis ce compte (le croisé est couvert par la passe 3).

| Page | Appels API | Statut |
|---|---|---|
| /echange | GET /sanctum/csrf-cookie 204 ; /api/etiquettes, /api/discussions, /api/me, /api/canaux, /api/me/notifications?per_page=6 → 200 | OK |
| /tableau | /api/me, /api/me/tableau-de-bord → 200 | OK |
| /copies | /api/me/deployments?type=client → 200 | ⚠️ route non documentée (API-11) |
| /profil | /api/me, /api/me/notifications?per_page=6 → 200 | OK (champs vides à confirmer côté UX) |
| /revenus | /api/me/revenus, /api/reseaux-mobile-money, /api/me/revenus/reversements?page=1, /api/me/revenus/mouvements?page=1 → 200 | OK |
| /paiements | /api/factures?statut=a_payer, /api/me/deployments?type=client, /api/factures?page=1 → 200 | ⚠️ API-11 |
| /missions | /api/me/missions, /api/me → 200 | ⚠️ route non documentée (API-11) |
| /notifications | /api/me/notifications?filtre=toutes&page=1, ?per_page=6 → 200 | OK |
| /publier (menu « Mes applis ») | aucun appel | ⚠️ API-12 |

Aucun 4xx/5xx, aucune requête en échec.

### Constats
- **API-11 — Faible — Routes appelées par le front absentes de l'OpenAPI.** Repro : pages /copies, /paiements, /missions → `GET /api/me/deployments?type=client`, `GET /api/me/missions` (200). Preuve : 0 occurrence de `/me/deployments` et `/me/missions` dans openapi.yaml. Impact : contrat incomplet, clients/tests générés ne les couvrent pas. Correctif : documenter (params `type`, pagination) ou aligner le front sur `/deployments` et `/missions`.
- **API-12 — Faible — Menu « Mes applis » ouvre /publier (formulaire vide) au lieu de la liste des applis du dev.** Aucun appel de liste des applis du dev. Impact : le dev ne voit pas ses applis publiées depuis ce menu. Correctif : pointer vers une liste (ex. `/api/apps?auteur=me` ou route dédiée) ou renommer l'entrée.
- **API-13 — Faible — Erreur OAuth `github_deja_lie` affichée comme générique.** Repro : connexion GitHub sur un compte GitHub déjà lié à un autre compte Souk alors qu'une session existe → redirection `/connexion?erreur=github_deja_lie`, UI : « La connexion avec GitHub n'a pas abouti. Réessayez dans un instant. » Impact : message trompeur, réessayer ne résout rien. Correctif : message dédié (« ce GitHub est déjà lié à un autre compte »).
- **API-14 — Info — /connexion affiche le formulaire de connexion à un utilisateur déjà connecté** (pas de redirection vers /echange ou /tableau).

## 7. Artefacts

| Chemin | Contenu |
|---|---|
| `/workspace/soukdev-audit/api.md` | Ce livrable |
| `/workspace/souk-api/openapi/openapi.yaml` | Contrat GitHub |
| `/workspace/souk-api/results/openapi_ops.json` | 123 opérations extraites |
| `/workspace/souk-api/results/routes.json` | Inventaire sondages |
| `/workspace/souk-api/results/apps_structure.json` | Clés JSON `/api/apps` (sans valeurs PII) |
| `/workspace/souk-api/results/public_structures.json` | Structures publiques |
| `/workspace/souk-api/bundles/` | Chunks JS front |
| `/workspace/souk-api/results/probes/` | Traces HTTP (peuvent contenir des Set-Cookie — **ne pas republier les valeurs**) |

---

*Fin du rapport Bot API — passe sans compte, lecture seule.*

# Notes — secrets, vérification dépôt, front live, broadcasting/admin

- **Cible** : https://soukdev.shop + repo public https://github.com/octavebahoun/Souk.dev (`main`)
- **Date** : 2026-11-10 (Europe/Paris, UTC+1)
- **Méthode** : lecture seule (raw.githubusercontent.com, curl front, greps). Non destructif. **Aucune valeur secrète reproduite** (masquage).
- **Périmètre** : demandes Lead Audit (secrets repo, promesse analyse avant publication, secrets front, `/broadcasting/auth` + `/api/admin/*`).

---

## Synthèse

| ID | Sévérité | Titre court |
|---|---|---|
| SEC-S01 | Info (positif) | Pas de secrets remplis dans `.env*.example` / compose / workflows / infra |
| SEC-S02 | Info (positif) | `.gitignore` ignore bien `.env` / `.env.prod` ; aucun `.env` servi en raw (404) |
| SEC-S03 | Moyenne | `DEMO_CONNEXION` + usernames démo documentés : risque si activé hors `local` sur une préprod exposée |
| SEC-S04 | Moyenne (écart promesse) | Secrets (gitleaks) = **blocage dur** ; CVE dépendances (Trivy) = **badge soft** après publication |
| SEC-S05 | Moyenne | Clé publique Reverb **mal injectée** au build front live (`VITE_REVERB_KEY` = message stdout de `secrets.sh`) |
| SEC-S06 | Info (positif) | Front live : pas de `sk_`, `AIza`, client secret GitHub, SasPay secret, Firebase, clé privée |
| SEC-S07 | Info (positif) | Canaux privés Reverb autorisés par session + ownership ; comptes suspendus refusés |
| SEC-S08 | Info (positif) | `/api/admin/*` derrière `auth:sanctum` + `compte.actif` + middleware `administrateur` (`est_admin`) |

---

### SEC-S01 — Pas de credentials remplis dans le dépôt public (exemples / compose / CI / infra)

- **Sévérité** : Info (positif)
- **Reproduction** :
  1. Lire `backend/.env.example`, `backend/.env.prod.example`, `frontend/.env.example`
  2. Lire `docker-compose.yml`, `docker-compose.prod.yml`, `infra/proxy/*`, `.github/workflows/ci.yml`
  3. Chercher `APP_KEY=base64:…`, tokens, passwords, private keys, webhook secrets, `GITHUB_CLIENT_SECRET` non vides
- **Preuve (masquée)** :
  - `APP_KEY=` **vide** dans les deux exemples (prod : commentaire `openssl rand -base64 32` sans valeur)
  - `GITHUB_CLIENT_ID=`, `GITHUB_CLIENT_SECRET=`, `REVERB_APP_KEY=`, `REVERB_APP_SECRET=`, `SASPAY_SECRET_KEY=`, `SASPAY_WEBHOOK_SECRET=`, `RESEND_API_KEY=`, `DEEPSEEK_API_KEY=`, `SMS_API_KEY=` → **vides**
  - Valeurs non vides = non secrets (URLs locales, `MAIL_FROM_ADDRESS=bonjour@souk.dev`, `SASPAY_BASE_URL=https://api.saspay.…`, `REVERB_APP_ID=soukdev`, ports, locales)
  - Compose : secrets internes via volume Docker `secrets` + `secrets.sh` (génération runtime), pas de mots de passe en clair dans le YAML
  - CI : `cp .env.example .env` + `php artisan key:generate` (clé éphémère runner), `permissions: contents: read`, aucun secret GitHub Actions référencé
- **Impact** : surface « secret dans le repo public » non observée sur ces chemins.
- **Correctif** : maintenir la discipline ; scanner périodiquement (gitleaks sur le monorepo CI) ; ne jamais committer `backend/.env.prod`.

---

### SEC-S02 — `.gitignore` et absence de `.env` commités

- **Sévérité** : Info (positif)
- **Reproduction** : ouvrir `backend/.gitignore`, `frontend/.gitignore` ; `GET` raw `backend/.env` et `backend/.env.prod`
- **Preuve (masquée)** :
  - Backend ignore : `.env`, `.env.backup`, `.env.production`, **`.env.prod`** (commentaire explicite « jamais commitées »)
  - Frontend ignore : `.env`, `.env.*` avec exception `!.env.example`
  - Arbre `main` : aucun fichier nommé `.env` / `.env.prod` (hors `*.example`)
  - HTTP raw : `backend/.env` → **404**, `backend/.env.prod` → **404**
- **Impact** : bonne hygiène ; réduit le risque de fuite accidentelle d’`APP_KEY` / secrets opérateurs.
- **Correctif** : ajouter éventuellement un job CI « forbid committed .env » (fail si path match).

---

### SEC-S03 — Comptes démo / `DEMO_CONNEXION` documentés (risque de mauvaise config préprod)

- **Sévérité** : Moyenne (si préprod exposée avec flag) ; Info en prod correctement configurée
- **Reproduction** :
  1. Lire `DemoController`, `config/app.php` (`demo_connexion`), `ComptesDemo.tsx`, `DemoSeeder`
  2. Route `POST /auth/demo` dans `routes/web.php` (throttle 60/min)
- **Preuve (masquée)** :
  - Connexion **sans mot de passe** : body `{"compte":"<username>"}` si `DEMO_CONNEXION=true` **et** `APP_ENV !== production`
  - Usernames publics dans le front : `soukdemo-awa`, `soukdemo-pharmacie`, `soukdemo-admin` (emails `…@demo.souk.dev` dans le seeder)
  - Gardes : `abort_unless(demo_connexion && !isProduction(), 404)` ; compte `est_admin` démo → **404 hors `local`/`testing`** même si le flag est true
  - `.env.example` : `DEMO_CONNEXION=false` ; `.env.prod.example` ne documente pas le flag (bon)
  - UI `ComptesDemo` : commentée « développement seulement (serveur Vite) »
- **Impact** : en **production** correctement flaggée → 404, OK. Sur une **préprod/staging** joignable avec `APP_ENV=staging` (ou autre ≠ production) + `DEMO_CONNEXION=true`, un tiers peut ouvrir des sessions démo (client/dev) sans secret — accès aux parcours Store / données cobaye. L’admin démo reste bloqué hors local.
- **Correctif** :
  - Forcer `DEMO_CONNEXION=false` (ou absent) sur tout hôte public ; alerte monitoring si la route répond ≠ 404
  - Idéalement : n’enregistrer la route que si `app()->environment(['local','testing'])`
  - Ne pas seed les démos sur les environnements partagés

---

### SEC-S04 — Promesse « chaque appli analysée avant publication » : gitleaks dur, Trivy soft

- **Sévérité** : Moyenne (écart marketing / attente utilisateur) — conception confirmée par tests
- **Reproduction (code)** :
  - `POST /api/apps/verification` et `POST /api/apps` → `AppliController::sansSecret()` → `VerificationSecrets` → job `AnalyserSecrets` (file `secrets`, gitleaks)
  - Après create : `demanderAnalyseSecurite()` → `AnalyserDependances` (Trivy, file `analyse`) → badge `verifie` / `problemes` / `echec`
  - Tests : `SecuriteDepotTest`, `VerificationDepotTest`
- **Flux** :
  1. Auth Sanctum + gate `lierUnDepot` + throttle `depots`
  2. Lecture `soukdev.json` + `docker-compose` (refus 422 si invalide / privileged / absent)
  3. **Gitleaks** dans conteneur jetable (`--network none`, `--redact`, `--cap-drop ALL`, docker cp, suppression `.gitleaks.toml` / `.gitleaksignore` / neutralisation `gitleaks:allow`)
  4. Secrets trouvés → **422** message lieux+règle **sans** valeur du secret ; timeout/erreur analyse → **503** Retry-After 60 (**fail-closed** : on ne publie pas sans vérif secrets)
  5. Publication OK → Trivy **asynchrone** (MEDIUM+) ; ne bloque **pas** la publication
- **Dépôt piégé** :
  | Contenu | Bloqué à la publication ? |
  |---|---|
  | Secret (ex. fausse clé paiement type cobaye `fuite`) | **Oui** (422) |
  | CVE HIGH/CRITICAL dans lockfile, sans secret | **Non** — publiée, badge orange `problemes` |
  | Analyse secrets indisponible / timeout | **Oui** (503, pas de publication) |
  | Bypass allowlist gitleaks dans le dépôt auteur | **Non efficace** (fichiers/allow retirés avant scan) |
- **Preuve (masquée)** : commentaire test « un secret bloque… les failles des dépendances donnent le badge orange » ; cobaye `database/seeders/demo/depots/fuite` (secret fabriqué à la volée hors repo, README).
- **Impact** : la promesse « analysée avant publication » est **vraie pour les secrets**, **partielle pour les CVE** (post-publication + badge). Un acheteur peut déployer une appli encore « en_cours » / « problemes » selon UI.
- **Correctif** :
  - Clarifier le copy marketing : « secrets bloquants avant publication ; dépendances notées (badge) »
  - Option produit : bloquer ou exiger acknowledgement si `securite_statut !== verifie` avant 1er déploiement Store
  - Surveiller file `secrets` (latence → 503) pour ne pas transformer le fail-closed en déni de publication

---

### SEC-S05 — Front live : `VITE_REVERB_KEY` = message « Secrets déjà présents. »

- **Sévérité** : Moyenne (dispo temps réel / hygiene build) — **pas** une fuite de secret privé
- **Reproduction** :
  1. Télécharger `https://soukdev.shop/assets/index-*.js`
  2. Chercher `reverb.soukdev.shop` / config Echo
- **Preuve (masquée)** : bundle contient littéralement  
  `key: "Secrets déjà présents."`, `wsHost: "reverb.soukdev.shop"`, ports 443, `forceTLS: true`  
  Or `backend/docker/secrets.sh` affiche exactement `echo "Secrets déjà présents."` quand le volume existe déjà ; `docker-compose.prod.yml` passe `VITE_REVERB_KEY: "${VITE_REVERB_KEY:-}"` (à fournir depuis `secrets_publics/public.env` au build).
- **Impact** :
  - La clé Reverb **publique** attendue n’est pas celle générée dans le volume → Echo/Pusher côté navigateur risque de **ne pas s’authentifier correctement** auprès de Reverb (temps réel dégradé/absent)
  - Indique une **erreur d’injection** au build (stdout du service `secrets` capturé au lieu de `VITE_REVERB_KEY=…` lu dans `public.env`) — même classe d’erreur pourrait un jour coller une mauvaise variable si le process de build est fragile
  - Ce n’est **pas** `REVERB_APP_SECRET` (celui-ci reste hors front, volume secrets)
- **Correctif** :
  - Rebuild front avec `export $(grep VITE_REVERB_KEY /run/soukdev-public/public.env)` (ou équivalent documenté) **avant** `docker compose build front`
  - Durcir : script de build qui refuse une clé contenant des espaces / caractères non hex ; smoke test `key` match regex `^[a-f0-9]{32}$` (format actuel `aleatoire 16` → 32 hex)
  - Documenter dans `docs/exploitation.md` un anti-exemple « ne pas faire `VITE_REVERB_KEY=$(docker compose run secrets)` »

---

### SEC-S06 — Front live : pas de secrets interdits dans HTML/JS principaux

- **Sévérité** : Info (positif)
- **Reproduction** : HTML + chunks (`index`, `preparerCsrf`, `pusher`, `Publier`, `Finances`, APIs admin, etc.) ; grep `apiKey|secret|token|sk_|AIza|firebase|saspay|github client|ghp_|base64:`
- **Preuve (masquée)** :
  - **Attendus / publics** : `baseURL=https://api.soukdev.shop` ; hôte `reverb.soukdev.shop` ; libellés UI « SasPay » (admin finances) ; `REVERB`/`VITE_*` patterns = runtime Vite mapDeps (faux positifs)
  - **Absents** : `sk_live`/`sk_test`, `AIza…`, `firebaseConfig`, `GITHUB_CLIENT_SECRET`, `SASPAY_SECRET`, `SASPAY_WEBHOOK`, PEM/private key, `ghp_`/`gho_`
  - Anomalie liée : SEC-S05 (clé publique Reverb incorrecte, pas un secret privé)
- **Impact** : pas d’exfiltration de credentials opérateurs via le bundle observé.
- **Correctif** : garder les secrets côté API uniquement ; CI grep deny-list sur `frontend/dist`.

---

### SEC-S07 — Broadcasting : `/broadcasting/auth` et canaux privés

- **Sévérité** : Info (positif) — à valider dynamiquement avec comptes A/B (hors ce scan lecture)
- **Reproduction** : `routes/channels.php`, `REVERB.md`, `frontend/src/app/tempsReelPrive.ts`, `bootstrap/app.php` (`channels: …`)
- **Preuve (masquée)** :
  - Front privé : `POST /broadcasting/auth` avec CSRF + cookies session (`clientLocal`, `preparerCsrf`)
  - Canaux privés :
    - `deploiement.{id}` → owner `user_id` + non suspendu
    - `mission.{id}` → `client_id` ou `auteur_id` + non suspendu
    - `utilisateur.{id}` → `(int)$id === $user->id` + non suspendu
  - Canaux **publics** documentés : `discussions`, `discussion.{id}`, `evenement.{id}` (payloads sans données réservées, ex. `lien` event null)
  - Guests sur `broadcasting/*` : pas de redirect HTML login (JSON/API style via `redirectGuestsTo`)
- **Impact** : modèle d’auth canaux cohérent Sanctum/session ; IDOR canal privé dépend du respect de ces closures (tests E2E/feature à croiser).
- **Correctif** : tests feature Broadcast::channel refus compte B sur `utilisateur.{idA}` / `deploiement.{idA}` ; rate-limit `/broadcasting/auth` si absent.

---

### SEC-S08 — Middleware `/api/admin/*`

- **Sévérité** : Info (positif) — contrôle d’accès à confirmer en session non-admin
- **Reproduction** : `routes/api.php` (groupe `auth:sanctum` + `compte.actif` puis `prefix('admin')->middleware('administrateur')`) ; `Administrateur.php` ; `bootstrap/app.php` (priority avant `SubstituteBindings`)
- **Preuve (masquée)** :
  - `est_admin !== true` → JSON 403 « Action non autorisée. » (jamais 404 révélateur d’ID)
  - `est_admin` **hors** `Fillable` du modèle `User` (cast boolean seulement) → pas d’auto-promotion via mass assignment nom/email/…
  - Surface admin : finances, factures/avoir, remboursements, reversements, rapprochements, signalements, comptes/suspension, deployments/suspension, canaux, machines
- **Impact** : design access control correct sur le papier ; risque restant = compte admin compromis / flag DB.
- **Correctif** : audit runtime avec compte Entreprise A (expect 403 sur `/api/admin/finances`) ; journaliser les 403 admin ; 2FA admin si exposé.

---

## Annexes

### A. Fichiers repo examinés (extrait)
`backend/.env.example`, `backend/.env.prod.example`, `frontend/.env.example`, `backend/.gitignore`, `frontend/.gitignore`, `docker-compose*.yml`, `infra/proxy/*`, `.github/workflows/ci.yml`, `backend/docker/secrets.sh`, `frontend/Dockerfile`, `AnalyseurDepot.php`, `VerificationSecrets.php`, `AnalyserSecrets.php`, `AnalyserDependances.php`, `AppliController.php` (`verification`/`store`/`sansSecret`/`securite`), `SecuriteDepotTest.php`, `VerificationDepotTest.php`, `DemoController.php`, `ComptesDemo.tsx`, `DemoSeeder.php` (partiel), `routes/api.php`, `routes/channels.php`, `routes/web.php`, `Administrateur.php`, `bootstrap/app.php`, `reverb.ts`, `tempsReelPrive.ts`, `REVERB.md`, cobaye `fuite`.

### B. Front live téléchargé
`index.html`, `assets/index-CLTRcOvM.js`, `preparerCsrf-*`, `pusher-*`, `Publier-*`, `Finances-*`, `Fiche-*`, `BadgeSecurite-*`, plusieurs `api-*`, `ModaleConnexion-*`, `Connexion-*`, `Moderation-*`, …

### C. Séparation clés
| Élément | Statut attendu | Observé |
|---|---|---|
| `REVERB_APP_KEY` / `VITE_REVERB_KEY` | Public (OK dans le JS) | Présent mais **valeur incorrecte** (SEC-S05) |
| `REVERB_APP_SECRET` | Privé (serveur) | Absent du front / exemples vides |
| `GITHUB_CLIENT_SECRET`, SasPay secrets, `APP_KEY` | Privé | Absents repo exemples + front |
| `GITHUB_CLIENT_ID` (OAuth) | Public | Vu côté API OAuth (autre note SEC-001) |


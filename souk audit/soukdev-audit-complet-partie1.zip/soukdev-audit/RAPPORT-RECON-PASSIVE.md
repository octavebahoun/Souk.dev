# Audit sécurité Souk.dev — Reconnaissance passive (non authentifiée)

**Cible :** https://soukdev.shop (front) · https://api.soukdev.shop (API Laravel/Sanctum/FrankenPHP) · https://reverb.soukdev.shop (WebSocket)  
**Date :** 10 novembre 2026 (Europe/Paris, UTC+1)  
**Périmètre :** recon passive uniquement (headers, cookies, CORS, chemins sensibles en GET, scan secrets front, TLS/redirections). Aucun login, fuzzing, injection ou DoS.  
**Référentiels :** OWASP Top 10:2021 · OWASP ASVS 4.0  

---

## Synthèse

| Sévérité | Nb | Principaux thèmes |
|----------|----|-------------------|
| Critique | 0 | — |
| Élevée   | 0 | — |
| Moyenne  | 3 | HSTS absent · HTTP sans redirection HTTPS · cookies `Domain=.soukdev.shop` |
| Faible   | 3 | Divulgation stack · CSP `style-src 'unsafe-inline'` / `frame-src https:` · pas de security.txt |
| Info     | 6 | CORS correct · pas de secrets privés front · TLS OK · SPA catch-all · `/up` Laravel · `payment=()` |

**Points positifs notables :** CSP présente et relativement stricte ; `X-Frame-Options: DENY` + `frame-ancestors 'none'` ; `X-Content-Type-Options: nosniff` ; cookies de session `Secure` + `HttpOnly` + `SameSite=Lax` ; CORS **sans** réflexion d’origine (allowlist fixe `https://soukdev.shop`) ; aucun fichier `.env` / `.git` / clé privée exposé ; aucun `sk_live` / JWT / AWS / clé privée dans les bundles JS ; TLS 1.3 valide (Let’s Encrypt).

---

## Architecture observée (recon)

- Front : SPA (Vite/Rolldown) servie derrière **Caddy + nginx** ; toutes les routes front renvoient le même `index.html` (5680 octets).
- API : **Laravel** via **FrankenPHP/Caddy** sur `api.soukdev.shop` ; Sanctum (`/sanctum/csrf-cookie`), session cookie `laravel-session`, CSRF `XSRF-TOKEN`.
- Temps réel : Laravel Echo + Reverb/Pusher client → `wss://reverb.soukdev.shop`.
- Catalogue public : `GET /api/apps` (JSON paginé) accessible sans auth.

---

## Constats détaillés

### M-01 — HSTS absent sur front, API et Reverb

- **Sévérité :** Moyenne  
- **OWASP / ASVS :** A05:2021 Security Misconfiguration · ASVS V9.1.1 / V9.2.1  
- **Reproduction :**
```bash
curl -sI https://soukdev.shop/ | grep -i strict-transport
curl -sI https://api.soukdev.shop/ | grep -i strict-transport
curl -sI https://reverb.soukdev.shop/ | grep -i strict-transport
# → aucune sortie (header absent)
```
- **Preuve :** en-têtes présents (CSP, XFO, XCTO, Referrer-Policy, Permissions-Policy) mais **pas** de `Strict-Transport-Security`.  
- **Impact :** un attaquant en position MITM (réseau Wi-Fi, DNS local) peut forcer un premier contact HTTP et tenter du SSL stripping / injection ; pas de `preload` ni `includeSubDomains`.  
- **Correctif :** sur Caddy (et/ou reverse proxy) pour `soukdev.shop`, `api.soukdev.shop`, `reverb.soukdev.shop` :
```
Strict-Transport-Security: max-age=63072000; includeSubDomains; preload
```
Puis soumettre le domaine à la liste HSTS preload une fois stable.

---

### M-02 — HTTP clair ne redirige pas vers HTTPS (erreur 500 Pingora)

- **Sévérité :** Moyenne  
- **OWASP / ASVS :** A02:2021 Cryptographic Failures · ASVS V9.1.2  
- **Reproduction :**
```bash
curl -sI http://soukdev.shop/
curl -sI http://api.soukdev.shop/
curl -sI http://www.soukdev.shop/
```
- **Preuve (extrait) :**
```
HTTP/1.1 500 Internal Server Error
Server: Pingora
Content-Length: 0
Cache-Control: private, no-store
```
Attendu : `301/308` → `https://…`.  
- **Impact :** pas de bascule HTTPS fiable ; comportement opaque (500) côté edge (Pingora) ; risque accru si un client retombe en HTTP.  
- **Correctif :** configurer l’edge / DNS / tunnel pour une redirection **301/308 permanente** HTTP→HTTPS sur tous les hôtes ; vérifier aussi le certificat `www` (aujourd’hui `https://www.soukdev.shop` → 301 vers apex, OK).

---

### M-03 — Cookies de session avec `Domain=.soukdev.shop` (trop large)

- **Sévérité :** Moyenne  
- **OWASP / ASVS :** A01:2021 Broken Access Control (session) · ASVS V3.4.2 / V3.4.3  
- **Reproduction :**
```bash
curl -sI https://api.soukdev.shop/sanctum/csrf-cookie
```
- **Preuve (secrets de valeur masqués) :**
```
Set-Cookie: XSRF-TOKEN=eyJpdiI6****In0%3D; Max-Age=7200; path=/; domain=.soukdev.shop; secure; samesite=lax
Set-Cookie: laravel-session=eyJpdiI6****In0%3D; Max-Age=7200; path=/; domain=.soukdev.shop; secure; httponly; samesite=lax
```
Attributs :
| Cookie | Secure | HttpOnly | SameSite | Domain | Path | Durée |
|--------|--------|----------|----------|--------|------|-------|
| `laravel-session` | oui | oui | Lax | `.soukdev.shop` | `/` | 7200 s (2 h) |
| `XSRF-TOKEN` | oui | **non** | Lax | `.soukdev.shop` | `/` | 7200 s |

- **Impact :** tout sous-domaine (`reverb.`, futur `staging.`, XSS sur un sous-domaine) peut recevoir/lire (selon HttpOnly) ces cookies. Compromission d’un sous-domaine = session API.  
  Note : l’absence d’HttpOnly sur `XSRF-TOKEN` est **normale** pour Laravel (le JS doit le lire) — classée Info ci-dessous, pas comme défaut.  
- **Correctif :** restreindre `domain` à `api.soukdev.shop` (ou omettre Domain pour host-only) si le front consomme l’API en cross-origin via CORS + Sanctum stateful ; sinon documenter/justifier le partage apex et durcir tous les sous-domaines (CSP, pas de user content HTML).

---

### F-01 — Divulgation de stack via en-têtes `Server`

- **Sévérité :** Faible  
- **OWASP / ASVS :** A05:2021 · ASVS V14.3.3  
- **Reproduction :** `curl -sI https://soukdev.shop/` et `curl -sI https://api.soukdev.shop/`  
- **Preuve :**
  - Front : `server: Caddy` + `server: nginx`
  - API : `server: Caddy` + `server: FrankenPHP Caddy`
  - `/up` (HTML) : titre « Laravel », assets bunny.net / Tailwind CDN  
- **Impact :** aide un attaquant à cibler des CVE connues (FrankenPHP, Caddy, nginx, Laravel). Pas d’exploitation directe.  
- **Correctif :** uniformiser / masquer `Server` (valeur générique) ; ne pas exposer la page HTML `/up` avec branding Laravel en prod (JSON health derrière auth réseau ou interne).

---

### F-02 — CSP : `style-src 'unsafe-inline'` et `frame-src https:` trop permissifs

- **Sévérité :** Faible  
- **OWASP / ASVS :** A03:2021 Injection (défense XSS) · ASVS V14.4.3 / V5.3  
- **Reproduction :** `curl -sI https://soukdev.shop/ | grep -i content-security-policy`  
- **Preuve (extrait) :**
```
content-security-policy: default-src 'self'; script-src 'self' 'sha256-…' 'sha256-…';
  style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https:;
  connect-src 'self' https://api.soukdev.shop wss://reverb.soukdev.shop;
  frame-src https:; frame-ancestors 'none'; …
```
Points bons : `object-src 'none'`, `frame-ancestors 'none'`, `base-uri 'self'`, scripts hashed (pas `'unsafe-inline'` / `'unsafe-eval'` sur scripts).  
- **Impact :** en cas de XSS HTML, styles inline facilitent le phishing UI ; `frame-src https:` autorise n’importe quelle iframe HTTPS (clickjacking inverse / phishing embarqué).  
- **Correctif :** migrer styles vers nonces/hashes ; restreindre `frame-src` aux origines nécessaires (ex. lecteurs embed, paiement) ; envisager `img-src` plus strict que `https:`.

---

### F-03 — Absence de `security.txt` (et robots/sitemap front non réels)

- **Sévérité :** Faible (processus) / Info technique  
- **OWASP / ASVS :** A05 · bonne pratique disclosure (RFC 9116)  
- **Reproduction :**
```bash
curl -sI https://api.soukdev.shop/.well-known/security.txt   # 404
curl -s https://soukdev.shop/robots.txt | head -5            # = index.html SPA
```
- **Preuve :** front SPA : `/.git/config`, `/.env`, `/robots.txt`, etc. → **tous HTTP 200 mais même HTML** (md5 identique à `index.html`) — **pas** de fuite réelle. API : chemins sensibles → **404** JSON `Introuvable.` ; `robots.txt` API = `User-agent: *` / `Disallow:` vide.  
- **Impact :** pas de canal clair pour signaler une vulnérabilité ; crawlers front n’ont pas de robots dédié.  
- **Correctif :** publier `https://soukdev.shop/.well-known/security.txt` (et miroir API) avec contact, politique, éventuellement clé PGP ; servir de vrais `robots.txt` / `sitemap.xml` hors fallback SPA.

---

### I-01 — CORS : pas de réflexion d’origine (positif)

- **Sévérité :** Info (contrôle OK)  
- **OWASP / ASVS :** A05 · ASVS V14.5.3  
- **Reproduction :**
```bash
curl -s -D - -o /dev/null -H "Origin: https://evil.example" \
  https://api.soukdev.shop/sanctum/csrf-cookie | grep -i access-control
curl -s -D - -o /dev/null -H "Origin: https://evil.example" \
  https://api.soukdev.shop/api/apps | grep -i access-control
```
- **Preuve :** même avec `Origin: https://evil.example`, `Origin: null` ou `https://evil.soukdev.shop` :
```
access-control-allow-origin: https://soukdev.shop
access-control-allow-credentials: true
```
Le navigateur **refuse** d’exposer la réponse si l’Origin de la page ≠ ACAO → **pas** de CORS misconfig de type « reflet ». Preflight Sanctum : méthodes/headers limités (`GET`, headers demandés).  
- **Impact :** aucun (bonne config).  
- **Correctif :** maintenir l’allowlist explicite ; éviter `*` avec credentials.

---

### I-02 — Aucun secret privé détecté dans le front (positif) ; clé Reverb côté client

- **Sévérité :** Info  
- **OWASP / ASVS :** A02 · ASVS V2.10 / V14.1  
- **Reproduction :** téléchargement HTML + ~80 bundles sous `/assets/*.js`, puis recherche de motifs `sk_live`, `AIza`, `AKIA`, `eyJ…`, `-----BEGIN`, `mongodb://`, `postgres://`, etc.  
- **Preuve :**
  - Aucune clé privée, JWT, AWS, Stripe live, Firebase/Supabase secret.
  - `baseURL` API client : `https://api.soukdev.shop` (attendu).
  - Config Echo/Reverb dans `assets/index-CLTRcOvM.js` :
```
key: `Secrets déjà présents.`
wsHost: `reverb.soukdev.shop`
wsPort/wssPort: 443
forceTLS: true
broadcaster: `reverb`
```
  La valeur littérale `Secrets déjà présents.` ressemble à un **placeholder de build** (ou clé app volontairement non sensible). Les *app keys* Reverb/Pusher sont conçues pour le client ; le **app secret** ne doit jamais y figurer (non trouvé).  
- **Impact :** si ce littéral n’est pas la vraie `REVERB_APP_KEY`, le temps réel peut être cassé ; si c’est la vraie clé publique, OK tant que le secret serveur reste privé et que `/broadcasting/auth` exige une session (observé : `403` sans auth).  
- **Correctif :** vérifier en CI que `VITE_/REVERB_APP_KEY` injectée est la vraie app key publique ; scanner les artefacts de build pour secrets ; garder `broadcasting/auth` authentifié.

---

### I-03 — TLS valide (positif) ; couverture SAN limitée

- **Sévérité :** Info  
- **OWASP / ASVS :** A02 · ASVS V9.2  
- **Reproduction :**
```bash
echo | openssl s_client -connect soukdev.shop:443 -servername soukdev.shop 2>/dev/null \
  | openssl x509 -noout -subject -issuer -dates -ext subjectAltName
```
- **Preuve :**
  - `soukdev.shop` : Let’s Encrypt, valide 9 nov 2026 → 7 fév 2027, TLS 1.3 `TLS_AES_128_GCM_SHA256`, vérif OK.  
  - Certs séparés OK pour `api.soukdev.shop` et `reverb.soukdev.shop`.  
  - `https://www.soukdev.shop` → 301 vers apex.  
- **Impact :** aucun sur HTTPS ; voir M-02 pour HTTP.  
- **Correctif :** conserver renouvellement auto ; optionnellement SAN multi-hôte ou certs wildcard maîtrisés + HSTS.

---

### I-04 — Endpoint santé Laravel `/up` public

- **Sévérité :** Info  
- **OWASP / ASVS :** A05 · ASVS V14.3  
- **Reproduction :** `curl -sH 'Accept: application/json' https://api.soukdev.shop/up` → `{"status":"up"}` ; sans Accept → page HTML Laravel.  
- **Impact :** fingerprinting + sonde de disponibilité (faible).  
- **Correctif :** restreindre par IP / réseau privé, ou répondre JSON minimal sans HTML / libs CDN.

---

### I-05 — `Permissions-Policy: payment=()` sur une marketplace

- **Sévérité :** Info  
- **OWASP / ASVS :** A05  
- **Preuve :** header présent front + API : `camera=(), microphone=(), geolocation=(), payment=()`.  
- **Impact :** bloque l’API Payment Request du navigateur ; OK si paiements 100 % redirect/hosted ; sinon friction UX.  
- **Correctif :** autoriser explicitement les origines de paiement si besoin (`payment=(self "https://…")`).

---

### I-06 — Catalogue public `/api/apps` (attendu métier)

- **Sévérité :** Info  
- **Reproduction :** `curl -sH 'Accept: application/json' https://api.soukdev.shop/api/apps`  
- **Preuve :** JSON `{ data, links, meta }` ; champs catalogue (`nom`, `prix`, `stack`, `demo_url`, …) — **aucun** champ email/téléphone/token dans l’échantillon.  
- **Impact :** surface d’énumération publique normale pour une marketplace.  
- **Correctif :** rate-limit / pagination déjà présents (`meta`) ; surveiller fuite de champs internes dans de futures versions.

---

## Tableau récapitulatif des en-têtes

| En-tête | Front `soukdev.shop` | API `api.soukdev.shop` |
|---------|----------------------|-------------------------|
| Content-Security-Policy | Présente (bonne base) | Présente (`default-src 'none'`) |
| Strict-Transport-Security | **Absente** | **Absente** |
| X-Frame-Options | DENY | DENY |
| frame-ancestors | 'none' | 'none' |
| X-Content-Type-Options | nosniff | nosniff |
| Referrer-Policy | strict-origin-when-cross-origin | idem |
| Permissions-Policy | camera/mic/geo/payment = () | idem |
| Server | Caddy + nginx | Caddy + FrankenPHP Caddy |
| X-Powered-By | absent | absent |
| COOP / CORP / COEP | absents | absents |

---

## Fichiers sensibles (lecture seule)

| Chemin | Front | API |
|--------|-------|-----|
| `/.git/config`, `/.env`, backups | 200 = SPA HTML (non sensible) | 404 |
| `/robots.txt` | SPA HTML | 200 (`Disallow` vide) |
| `/.well-known/security.txt` | SPA HTML | 404 |
| `/server-status`, `/phpinfo.php`, `/telescope`, `/horizon` | SPA HTML | 404 |
| `/sanctum/csrf-cookie` | n/a | 204 + cookies |
| `/up` | SPA | 200 health |

**Aucun contenu sensible (credentials, dump git, .env) observé en clair.**

---

## Priorisation correctifs (ordre recommandé)

1. Activer **HSTS** (+ preload quand prêt) sur tous les hôtes.  
2. Corriger la **redirection HTTP→HTTPS** (éliminer le 500 Pingora).  
3. Restreindre le **Domain** des cookies de session / documenter le modèle Sanctum.  
4. Durcir **CSP** (`frame-src`, styles) et masquer `Server`.  
5. Ajouter **security.txt** ; verrouiller `/up` HTML.  
6. Valider la **clé Reverb** embarquée vs placeholder de build.

---

## Hors périmètre (prochaine phase)

Auth/session fixation, IDOR sur commandes/copies, CSRF métier, uploads, WebSocket auth poussée, logique paiement, rate-limit login — **non testés** ici (nécessitent auth / tests actifs sous accord).

---

*Preuves brutes sous `/workspace/souk-audit/` (`headers/`, `cookies/`, `cors/`, `sensitive/`, `frontend/`, `tls/`).*

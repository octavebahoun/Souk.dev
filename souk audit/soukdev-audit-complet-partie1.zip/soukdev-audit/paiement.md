# Audit paiement & business — Souk.dev

**Cible :** https://soukdev.shop · repo `octavebahoun/Souk.dev` @ `main` (`624431c`)  
**Dates :** phase 1 ~01:29 · phase 2 revue de code ~01:45 · complément UX SasPay / facture impayée 10 nov. 2026 ~11:35 Europe/Paris  
**Méthode :** curl/WebFetch + bundles (phase 1) ; clone lecture seule `/workspace/souk-paiement/repo` @ `624431c` + doc SasPay (phase 2) ; recoupement captures UX `ux/captures/saspay/` (aucun paiement, aucun POST webhook).  
**Hors zone :** UI/responsive, infra Docker, auth générale.  
**Règles :** aucun POST paiement/webhook en prod, aucun paiement réel, aucun secret affiché.

---

## Statut final — 10 nov. 2026, 12:20 (heure de Paris)

**Audit paiement terminé** pour le périmètre lecture seule (pages publiques, revue de code `main` @ `624431c`, état réel de SD-2026-000003). Aucun paiement réel, aucun POST vers paiement ou webhook en prod, aucun secret affiché.

- **PAY-01 (Critique) : NON confirmé avec SasPay.** Le défaut est confirmé dans le code (`Encaissement.php` l.216-245 : comparaison du montant uniquement si devise = XOF, crédit + déploiement sinon). L'exploitabilité dépend de SasPay (possibilité d'obtenir un débit dans une autre devise, ou pour un montant inférieur, sur une session créée en XOF) : la doc SasPay récupérée ne documente pas le champ devise et rien n'a été testé, faute de sandbox fiable et pour respecter la règle « aucun paiement ». Reste Critique par prudence ; le correctif (refuser ou mettre en attente toute devise ≠ XOF tant que l'équivalent XOF n'est pas vérifié ≥ montant facture, sans déployer) est simple et à appliquer avant la prod. À confirmer auprès du support SasPay ou en `sk_test`.
- **SD-2026-000003** : à payer, copie en attente de paiement, rien déployé (captures `paiement-captures/`). Annulation automatique prévue le 17 nov. à 07:00 (heure de Paris) si le scheduler et le worker `paiements` tournent en prod (non vérifiable d'ici). La facture est sur le compte réel d'Octave, pas un compte audit.
- **Non couvert** : tunnel complet avec un compte audit dédié, double clic Payer, reçu `frais_client`, page `/revenus` avec reversements actifs, rejeu de webhook en sandbox.

## Synthèse exécutive

| Zone | Verdict code |
|---|---|
| Montants 3500/7000/13500 | **Serveur** (`config/facturation.php` → `Facturation`) ; le client **ne peut pas** envoyer un plan/montant |
| Frais opérateur | Mode SasPay `ADD_ON` ; **non chiffrés** sur Souk avant checkout |
| 0 % commission | **Respecté** au grand livre (part appli → `dev`) ; revenu = hébergement |
| `/paiement/retour` | Statut **jamais** tiré de l’URL ; `POST …/verification` → API SasPay |
| Webhooks | HMAC conforme doc SasPay + tolérance 300 s + empreinte + **re-verify API** |
| Sandbox | Simulateur local ; prod exige `SASPAY_SECRET_KEY` ; doc `sk_test` à traiter avec prudence |
| Secrets | Aucune clé réelle commitée (`.env` gitignoré ; exemples vides) |
| Facture impayée (1ʳᵉ commande) | Annulée **après 7 jours calendaires** (`annulee`) par le job quotidien 06:00 UTC ; copie créée en `attente_paiement`, **jamais lancée** sans paiement |
| Checkout SasPay (live, 10 nov.) | Marchand affiché « to Gentube » ; 3 500 + **123** = 3 623 XOF ; page EN par défaut ; pas de `cancel_url` dans l’API |

---

## Liste des constats (par sévérité)

| ID | Sévérité | Titre |
|---|---|---|
| **PAY-01** | **Critique** | Crédit facture si devise ≠ XOF sans égalité de montant (carte / FX) |
| **PAY-02** | **Haute** | CGU/CGV « brouillon » + absence de mentions légales (RCCM/IFU/éditeur) |
| **PAY-03** | **Haute** | Reversements MoMo **inactifs** en production tant que `REVERSEMENTS_REELS` ≠ true |
| **PAY-04** | Moyenne | Frais Mobile Money/carte annoncés mais non chiffrés avant SasPay |
| **PAY-05** | Moyenne | Double source des formules (front `formules.ts` vs `config/facturation.php`) |
| **PAY-06** | Moyenne | « Choisir la formule » : la taille est celle de l’appli, pas un choix client |
| **PAY-07** | Moyenne | Marketing « 0 % » vs réalité (hébergement + frais opérateur) |
| **PAY-13** | Moyenne | Bénéficiaire SasPay affiché « to Gentube » (nom du compte marchand, pas un champ d’API) |
| **PAY-14** | Moyenne | Checkout SasPay en anglais par défaut — l’API officielle n’offre pas de `locale` |
| **PAY-15** | Moyenne | Première facture impayée : **aucune relance** avant l’annulation à J+7 |
| **PAY-08** | Basse | `robots.txt` / `sitemap.xml` front = HTML SPA |
| **PAY-16** | Basse | Pas de `cancel_url` / CGV sur SasPay : non prévu par l’API ; `return_url` seulement après **succès** |
| **PAY-09** | Info | Montants non manipulables côté requête (commande / paiement) — **contrôle OK** |
| **PAY-10** | Info | Webhook SasPay : signature, idempotence, rejeu, faux callback — **conforme doc + tests** |
| **PAY-11** | Info | Mode test : simulateur local ; `sk_test`/`sk_live` ; sandbox doc à valider avant argent réel |
| **PAY-12** | Info | Aucun secret SasPay commité (placeholders `.env.example` seulement) |
| **PAY-17** | Info | Cycle impayé 1ʳᵉ commande + scheduler prévu en prod — **copie jamais déployée sans paiement** (OK code) |

---

## Détail — Critiques & Hautes

### PAY-01 — Crédit si devise ≠ XOF sans comparer le montant
- **Sévérité :** Critique  
- **Reproduction :** lire `Encaissement::appliquerVerificationReussie` ; test `VerificationPaiementTest::test_une_carte_debitee_dans_une_autre_devise_est_creditee_et_verifiee_par_l_equipe`  
- **Preuve :** `backend/app/Paiement/Encaissement.php:215-245` — si `$devise === 'XOF'` et montants ≠ → blocage + alerte ; **sinon** (ex. `USD`) → `appliquerSucces` (facture `payee`, grand livre, **déploiement lancé**) + alerte admin seulement. Test crédite une facture avec `VerificationPaiement(..., 31, ..., 'USD')`.  
- **Impact :** Si SasPay renvoie `SUCCESS` dans une devise non XOF avec un petit `requested_amount`, la facture FCFA entière est soldée et la copie démarre avant revue humaine.  
- **Correctif :** Pour toute devise ≠ XOF, **ne pas** activer tant qu’un taux/équivalent XOF n’est pas validé (file admin, ou refus automatique si hors bande) ; ou forcer le checkout carte en XOF uniquement et rejeter tout `currency !== XOF`.

### PAY-02 — Légal non opposable + pas de mentions légales
- **Sévérité :** Haute  
- **Reproduction :** https://soukdev.shop/legal/cgv · `frontend/src/features/legal/Legal.tsx`  
- **Preuve :** bandeau « Brouillon à faire valider par un juriste » / « n’a pas de valeur contractuelle » ; routes `/legal/cgu|cgv|confidentialite|abus` seulement — **pas** de page mentions (RCCM/IFU/éditeur/contact). Contenu CGV décrit bien paliers, SasPay, grâce 7 j, reversements.  
- **Impact :** Litiges paiement/remboursement sans base contractuelle claire ; identification éditeur manquante (Bénin / APDP évoquée seulement en confidentialité).  
- **Correctif :** Mentions légales complètes ; validation juriste ; retirer le bandeau brouillon.

### PAY-03 — Reversements désactivés en prod par défaut
- **Sévérité :** Haute  
- **Reproduction :** `REVERSEMENTS_REELS` absent/false + `APP_ENV=production`  
- **Preuve :** `AppServiceProvider::enregistrerPasserelles` → `ReversementsInactifs` ; message « Les reversements sur Mobile Money ne sont pas encore ouverts. » ; docs/paiement.md l.103–104.  
- **Impact :** Promesse « vous encaissez / Mobile Money » vs solde qui **n’est pas versé** tant que le flag + IP whitelist SasPay ne sont pas en place. Risque réputation / litige devs.  
- **Correctif :** Checklist go-live explicite ; UI revenus qui affiche clairement l’état « bientôt » (déjà partiel) ; activer `REVERSEMENTS_REELS` seulement après IP whitelist + tests payout sandbox/micro.

---

## Détail — Moyennes / Basses / Info (condensé)

### PAY-04 — Frais non chiffrés avant paiement (Moyenne) — confirmé live
- **Reproduction :** `/store/1/deployer` affiche « Payer 3 500 F » ; après clic (UX, 10 nov. 2026 11:30 Europe/Paris, sans payer) : checkout SasPay.
- **Preuve code :** `Commande.tsx:209,258` « frais … affichés avant de valider » ; `SasPayPaiement.php:20-29` envoie `amount: 3500.00`, `fee_charge_mode: ADD_ON`, **aucun** champ de frais estimés. Reçu : `FacturePage` `frais_client` seulement après paiement.
- **Preuve capture :** `ux/captures/saspay/saspay-checkout-desktop.png` — Amount 3,500 XOF, Fees +123 XOF, Total due **3,623 XOF** (Moov / MTN / Celtiis BJ : tous +123). `ux/captures/saspay/deployer-avant-clic.png` : bouton toujours « Payer 3 500 F ».
- **Formule 123 F :** 123 / 3 500 = 3,514 % → **3,5 % arrondi au franc** (122,5 → 123). Les trois réseaux BJ ont le même surplus.  
  Grille marketing publique SasPay (https://www.saspay.me/, « Bénin dès 2,2 % » ; « dès 1,75 % + 100 F ») donnerait **77 F** (2,2 %) ou **161 F** (1,75 % + 100) — **pas 123**. L’exemple doc `GET /pricing/my-rates/` (Orange CI, 2,5 % plancher 50 F) donnerait 87,5 → 88 F, pas davantage. Le tarif réel est celui du **compte marchand** (éventuellement `is_custom`) ; non lu ici (endpoint authentifié).
- **Impact :** écart 3 500 → 3 623 (≈ +3,5 %) découvert seulement chez SasPay.
- **Correctif :** afficher avant le clic « 3 500 F + frais Mobile Money (ex. 123 F, total 3 623 F) » via `GET /pricing/my-rates/` (cache serveur) ; bouton au total TTC frais inclus, ou « Continuer vers le paiement ».

### PAY-05 — Double source formules (Moyenne)
- **Preuve :** `frontend/.../formules.ts` vs `backend/config/facturation.php` (3500/7000/13500). Affichage client peut diverger si un seul côté change ; **facture serveur reste exacte**.  
- **Correctif :** Endpoint public des tarifs ou génération front depuis OpenAPI/config unique + test de non-régression.

### PAY-06 — Formule non choisie par le client (Moyenne)
- **Preuve :** `DeploiementController::taille` lit `$appli->taille` ; `Facturation::commander` idem ; UI `Commande.tsx` affiche `formules[fiche.taille]` sans sélecteur.  
- **Impact :** Écart vs carte produit « choisir formule » ; le client paie la taille fixée par l’auteur.  
- **Correctif :** Clarifier le copy, ou permettre un choix client validé serveur.

### PAY-07 — « 0 % » vs coût réel (Moyenne)
- **Preuve :** Accueil « 0 % de commission » ; `GrandLivre::encaisser` part appli → `dev` intégrale ; hébergement → `revenu_hebergement` ; frais payout sur marge Souk (`Reversements` doc).  
- **Correctif :** Formuler « 0 % sur le prix de l’appli ».


### PAY-13 — Bénéficiaire SasPay « to Gentube » (Moyenne)
- **Reproduction :** capture `ux/captures/saspay/saspay-checkout-desktop.png` : titre « Souk.dev — portfolio-open — … 3,500 XOF », sous-titre **« to Gentube »**.
- **Preuve code :** `SasPayPaiement.php:20-36` / `Encaissement.php:98-106` envoient `description` (« Souk.dev — {appli} — facture {numero} »), `customer_name`, `customer_email`, `return_url`, `metadata`, `country`, `fee_charge_mode`. **Aucun** champ `merchant_name` / `business_name` dans le code ni dans l’OpenAPI SasPay `POST /checkout-sessions/` (propriétés : amount, currency, description, country, customer_*, return_url, metadata, fee_charge_mode, expires_at).
- **Conclusion :** « Souk.dev — portfolio-open » = `description`. « to Gentube » = **nom d’affichage du compte marchand** côté tableau de bord SasPay, pas un paramètre d’API.
- **Impact :** le client croit payer Gentube, pas Souk.dev — abandon / litige / suspicion de phishing.
- **Correctif :** renommer le marchand (et le logo) dans le dashboard SasPay en « Souk.dev » (ou raison sociale liée) ; vérifier le KYC rattaché.

### PAY-14 — Page SasPay en anglais par défaut (Moyenne)
- **Reproduction :** même capture : libellés « Country », « Payment method », « Total due », « Pay 3,623 XOF » ; bascule **FR | EN** présente, EN actif.
- **Preuve :** le corps de `creerSession` ne contient ni `locale` ni `language`. L’OpenAPI SasPay **0 occurrence** de locale/lang pour le checkout. La doc « Créer une session » ne documente pas non plus ce champ.
- **Impact :** public francophone (pharmacie, association) face à un écran EN ; bascule manuelle possible mais facile à rater.
- **Correctif :** demander à SasPay un paramètre `locale=fr` (ou détection `Accept-Language`) ; en attendant, mentionner sur `/deployer` que la page de paiement propose FR.

### PAY-15 — Pas de relance sur une 1ʳᵉ facture impayée (Moyenne)
- **Reproduction :** cycle `CycleFacturation` ; facture d’audit SD-2026-000003 (1ʳᵉ commande, abonnement `en_attente`).
- **Preuve :**
  - `FactureEmise` n’est envoyée que dans `CycleFacturation::emettre` (`CycleFacturation.php:51-86`) pour les renouvellements (J-3, abonnements **actifs**). `Facturation::commander` (`Facturation.php:26-59`) émet la 1ʳᵉ facture **sans** notification.
  - `relancer` (`CycleFacturation.php:93-128`, e-mail `FactureEnRetard`) exige un abonnement dans `STATUTS_ACTIFS` = `actif` | `en_retard` (`Abonnement.php:20`). Une commande jamais payée reste `en_attente` → **pas de relance** le lendemain de l’échéance (qui est le jour même de la commande, `emettre(..., now()->startOfDay())`).
  - Seul e-mail prévu : `CopieResiliee` (`jamaisPayee: true`, `CycleFacturation.php:273`) **au moment de l’annulation J+7**.
- **Impact :** un client qui a ouvert SasPay et est parti ne reçoit aucun rappel avant que la commande disparaisse ; pour une facture d’audit, pas de « harcèlement » de relances, mais silence jusqu’à l’annulation.
- **Correctif :** envoyer `FactureEmise` (ou un « paiement en attente ») à la commande, et/ou une relance à J+3 même si l’abonnement est `en_attente`.

### PAY-16 — Pas de lien d’annulation ni de CGV chez SasPay (Basse)
- **Reproduction :** capture checkout : pas de « Cancel », pas de retour Souk, pas de CGV / remboursement.
- **Preuve :** OpenAPI `POST /checkout-sessions/` : **pas** de `cancel_url`. `return_url` est bien envoyé (`Encaissement.php:103` → `{FRONTEND_URL}/paiement/retour?facture={id}`). Doc SasPay : `return_url` redirige **uniquement 3 s après un succès** ; en cas d’échec/abandon, le client doit fermer l’onglet (bouton « Réessayer » sur place). Souk le documente déjà (`docs/paiement.md`).
- **Impact :** friction (retour manuel) ; pas d’acceptation CGV chez SasPay — à coupler avec l’absence de case CGV sur `/deployer` (UX-041) et PAY-02 (brouillon).
- **Correctif :** ne pas inventer un `cancel_url` hors contrat API ; demander le champ à SasPay. Sur Souk, lien « Annuler et revenir » avant redirection, et mention CGV. Indiquer « fermez l’onglet pour abandonner ».

### PAY-17 — Cycle de vie d’une 1ʳᵉ facture impayée (Info — comportement voulu, à surveiller)
Voir section dédiée ci-dessous. **Oui : aucune copie n’est déployée sans facture payée.** Annulation `annulee` à J+7 si le scheduler + worker `paiements` tournent. Scheduler **prévu** en prod (`docker-compose.prod.yml` service `scheduler` : `php artisan schedule:work`, `restart: unless-stopped`, healthcheck `planificateur`) ; exécution **réelle** sur le VPS non vérifiable en lecture seule.

### PAY-08 — robots/sitemap front (Basse)
- SPA HTML sur `/robots.txt` et `/sitemap.xml` (phase 1). API a un robots réel.

### PAY-09 — Montants non manipulables (Info — positif)
- **Preuve :** `Facturation` l.19 « Aucun montant ne vient du navigateur » ; `POST /apps/{id}/deployments` n’accepte que `variables` ; `POST /factures/{id}/paiement` sans body montant → `facture.montant_total` ; session SasPay créée avec ce montant (`Encaissement.php:91-99`). Tests déploiement `montant_total` attendu.

### PAY-10 — Webhooks (Info — positif, conforme doc)
- **Doc SasPay** (`docs.saspay.me/api-reference/webhooks`) : `X-Webhook-Signature` = HMAC-SHA256 hex minuscules de `{timestamp}.{raw body}` ; `X-Webhook-Timestamp` ; âge.  
- **Code :** `SignatureWebhook.php` identique + `hash_equals` + tolérance 300 s ; secret vide refusé hors `local` ; `WebhookSasPayController` empreinte SHA-256 unique (« Déjà reçu ») ; job `TraiterWebhookSasPay` **ne fait pas confiance** au webhook → `Encaissement::verifier` / API verify. Tests : signature fausse 401, rejeu, corps reformaté refusé, success webhook sans verify API ne paie pas.  
- **Route prod :** `POST https://api.soukdev.shop/api/webhooks/saspay` (GET → 405).

### PAY-11 — Mode test / sandbox (Info)
- Dev sans clé → passerelle `simulee` + UI `/simulateur/saspay/{session}` (404 en prod / si passerelle ≠ simulee).  
- Prod : `SASPAY_SECRET_KEY` obligatoire.  
- Doc SasPay : `sk_test_` vs `sk_live_` ; signal tiers (sandbox parfois non isolé) → micro-montants + refund dashboard si doute.

### PAY-12 — Secrets (Info — positif)
- `.env` / `.env.production` gitignorés ; `.env.example` : `SASPAY_SECRET_KEY=` / `SASPAY_WEBHOOK_SECRET=` vides. Chaînes `sk_live_…` dans **tests** = fixtures fictives. `PROGRESS.md` mentionne la présence de clés en local (type `sk_live_`) sans valeur.

---


## Cycle de vie — facture / commande impayée (ex. SD-2026-000003)

Réponse nette :

- **Expiration / annulation : oui**, statut facture **`annulee`** (pas de statut `expiree`).
- **Quand :** **7 jours calendaires** après la création de l’abonnement (`facturation.jours_grace` = 7), au passage quotidien **06:00 UTC** (07:00 Europe/Paris et heure du Bénin en novembre). Pour une création le **10 nov. 2026** : annulation au passage du **17 nov. 2026, 07:00 Europe/Paris**, si le job tourne.
- **Copie / déploiement :** créé **avant** le paiement, état **`attente_paiement`** ; **`LancerDeploiement` uniquement après SUCCESS SasPay vérifié**. Sans paiement : jamais en ligne. À J+7 : état passé à **`arrete`** (rien n’avait été lancé) + abonnement `resilie` + factures `a_payer` → `annulee`.
- **Rappels :** **aucune relance** sur cette 1ʳᵉ facture avant J+7 (PAY-15) ; e-mail « Commande annulée » alors seulement.

| Étape | Code | Effet |
|---|---|---|
| Clic « Payer » | `DeploiementController::store` → `Facturation::commander` (`Facturation.php:26-59`, `DeploiementController.php:21-35`) | Déploiement `attente_paiement`, abonnement `en_attente`, 1ʳᵉ facture `a_payer`, échéance = jour de commande. Aucun conteneur. |
| Session SasPay | `Encaissement::ouvrirSession` (`Encaissement.php:44-119`) | `Paiement` `en_attente`, montant = `facture.montant_total` (3 500). Session réutilisée 30 min. |
| Succès vérifié | `Encaissement::activer` (`Encaissement.php:300-319`) | Facture `payee`, abonnement `actif`, `LancerDeploiement`. **Jamais** sur la foi du navigateur ou du seul webhook. |
| J+7, job quotidien | `Schedule::job(new FacturationQuotidienne)->dailyAt('06:00')` (`routes/console.php:64-65`) → `CycleFacturation::annulerLesCommandesImpayees` (`CycleFacturation.php:243-277`) | Si `statut === en_attente` et `created_at` date ≤ aujourd’hui − 7 j : `resilier` (`Facturation.php:91-104` : factures `a_payer` → `annulee`), déploiement `attente_paiement` → `arrete`, notif `CopieResiliee` (`jamaisPayee`). Test : `CycleFacturationTest.php:137-149` (créée le 5 oct., encore en attente le 11, **annulée le 12** à 06:00). |
| Renouvellement (hors 1ʳᵉ commande) | `emettre` / `relancer` / `suspendre` / `resilierLesSuspendues` | J-3 rappel `FactureEmise` + lien signé 30 j ; lendemain échéance `FactureEnRetard` ; J+7 grâce : suspension (données gardées) ; J+30 suspension : arrêt définitif. **Ne s’applique pas** tant que l’abonnement est `en_attente`. |

**Scheduler en prod (risque résiduel) :**  
`docker-compose.prod.yml:224-232` service `scheduler` (`php artisan schedule:work`, ancre `x-php` → `restart: unless-stopped`, healthcheck `php docker/sante.php planificateur`). Le job est poussé sur la file **`paiements`** (`FacturationQuotidienne.php:21`) : le **worker** `queue:work --queue=paiements,default` (`docker-compose.prod.yml:132-134`) doit aussi tourner. `docs/exploitation.md` inclut le planificateur dans le stack `./scripts/prod.sh up -d`. **Non vérifiable** depuis l’extérieur (pas d’endpoint public de battement). Si l’un des deux services est down, SD-2026-000003 **resterait `a_payer` indéfiniment**.

---

## Flux vérifié (code)

```
POST /api/apps/{id}/deployments  → Facturation::commander (taille=appli.taille, prix serveur)
POST /api/factures/{id}/paiement (+ Idempotency-Key) → checkout_url SasPay (montant facture, ADD_ON)
Redirection SasPay → /paiement/retour?facture={id}
POST /api/factures/{id}/verification → verify session/payment chez SasPay
(+ webhook POST /api/webhooks/saspay → même verify)
Facture payee → grand livre → LancerDeploiement / ReactiverCopie
```

**Factures / rappels (renouvellements) :** `CycleFacturation` (J-3 `FactureEmise` + lien signé, retard, grâce 7 j, suspension, arrêt 30 j).  
**Revenus :** `/revenus` · `GET/POST /api/me/revenus*` · seuil 5 000 F · numéro MoMo chiffré + confirmation e-mail.

---

## Reste à tester dans le navigateur (compte test)

Sans paiement réel en prod ; préférer **simulateur** local ou staging + confirmation que `sk_test` ne débite pas.

0. **Fait (UX, 10 nov., sans payer) :** tunnel jusqu’à SasPay ; facture **SD-2026-000003** (3 500 F) créée ; frais 123 F constatés.
1. **Dans le compte d’audit (lecture seule, pages exactes) :**
   - `/paiements` et `/paiements/{id}` (pas `/factures`, route front inexistante — 404 SPA) : confirmer SD-2026-000003 en **`À payer`**, montant 3 500 (pas 3 623), échéance = 10 nov., tentative `en_attente`, éventuellement `checkout_url` encore valable (~1 h côté SasPay, réutilisation 30 min côté Souk).
   - `/copies` : une copie **portfolio-open** en **« en attente de paiement »** (`attente_paiement`), **sans URL**, pas « en ligne ».
   - `/notifications` : **pas** de « Facture … à régler » / relance (PAY-15) ; rien d’attendu avant le 17 nov.
2. Cohérence totaux déjà vue (3 500 Souk vs 3 623 SasPay). Après un vrai paiement sandbox : `frais_client` = 123 sur le reçu.
3. Auteur = acheteur : prix appli 0 (déjà sur le récap).
4. Retour `/paiement/retour?facture=` : succès/échec/attente via API — **pas** en prod live.
5. Annulation J+7 : revoir `/paiements` et `/copies` le **17 nov. après 07:00 Europe/Paris** (ou plus tard si le scheduler a du retard) : facture `Annulée`, copie `Arrêtée`, notif « Commande annulée ».
6. Dashboard SasPay (opérateur) : nom marchand « Gentube », grille `my-rates` Bénin pour figer la formule des 123 F.
7. Ne pas rejouer de faux webhooks en **prod**.

**Besoins restants :** accès lecture du compte audit (pages ci-dessus) ; éventuellement dashboard SasPay ; pas de nouveau paiement.

---

## Annexes

**Clone :** `/workspace/souk-paiement/repo` (lecture seule, `main` @ `624431c`)  
**Artefacts phase 1 :** `/workspace/souk-paiement/assets/*`, `reseaux.json`  
**Doc interne :** `docs/paiement.md`  
**Captures UX SasPay :** `/workspace/soukdev-audit/ux/captures/saspay/` ; rapport `ux/rapport-client-deployer-v1.md` (complément 11:30).  
**Doc SasPay :** webhooks, [checkout-create](https://docs.saspay.me/api-reference/payments/checkout-create), [my-rates](https://docs.saspay.me/api-reference/reference/my-rates) ; marketing https://www.saspay.me/

*Fin rapport paiement (phases 1–2 + complément facture impayée / checkout live).*

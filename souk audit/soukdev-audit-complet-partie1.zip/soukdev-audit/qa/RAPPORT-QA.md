# QA Parcours Souk — rapport (10 nov. 2026, Europe/Paris)

## Phase 1 — Visiteur non connecté (captures : visiteur/)
Pages : /, /store (+ ?q=pharmacie, ?q=zzqxw, ?categorie=sante, ?securite=1), /store/1, /echange, /devs, /evenements, /connexion, /connexion?profil=dev, /publier, /copies, /legal/{cgu,cgv,confidentialite,abus}. Aucun lien mort menu/pied de page.
Auth : pas de /inscription ni /mot-de-passe-oublie (page introuvable, cohérent) ; dev = GitHub ; client = lien magique email.

| ID | Sévérité | Repro | Attendu / Obtenu | Preuve | Impact | Correctif |
|---|---|---|---|---|---|---|
| QA-001 | Majeur | Pied de page → pages légales | Textes finalisés / mention « Brouillon à faire valider par un juriste », sans valeur contractuelle | visiteur/16-legal-cgu.png … 19-legal-abus.png | Pas de base contractuelle pour vendre/payer en prod | Faire valider et publier les versions définitives avant prod |
| QA-002 | Mineur | Carte/fiche portfolio-open (/, /store, /store/1) | « portfolio » / « portoflio open source » | visiteur/01-accueil.png, 02-catalogue.png, 06-fiche-appli.png | Crédibilité | Corriger la description (contenu auteur) |
| QA-003 | Mineur | /store → filtres | Libellé FR / « Badge Security Checked seulement » | visiteur/05-filtres-categorie.png | Cohérence langue | « Badge Sécurité vérifiée seulement » |
| QA-004 | Cosmétique | /store/1 section discussions | « Discussions (0) » / « Discussions0 » | visiteur/06-fiche-appli.png | Lisibilité | Espace ou badge autour du compteur |

Note : /inscription et /mot-de-passe-oublie → page introuvable ; acceptable si on n'y renvoie jamais (à vérifier dans les emails/liens).

## Phase 2 — Client, connexion par lien magique (captures : client/)
- /connexion → « Entreprise ou particulier » : email invalide → « Cette adresse ne semble pas valide : vérifiez le @ et le domaine. » (client/02-email-invalide.png) ; envoi OK → « Lien envoyé à … Ouvrez-le depuis cet appareil. Il ne sert qu'une seule fois. » (client/03-lien-envoye.png). Email reçu en ~2 s.

| ID | Sévérité | Repro | Attendu / Obtenu | Preuve | Impact | Correctif |
|---|---|---|---|---|---|---|
| QA-005 | Majeur | Demander un lien magique client | Email reçu en boîte, expéditeur sur le domaine soukdev.shop / email « Votre lien de connexion Souk.dev » classé SPAM, expéditeur souk@send.excellenceteam.site (domaine sans rapport avec Souk.dev) | Boîte de test (spam), 10/11 01:34:58 Paris | Clients ne trouvent pas le lien → connexion impossible en pratique ; aspect hameçonnage | Envoyer depuis un sous-domaine de soukdev.shop avec SPF/DKIM/DMARC alignés |

### Parcours client connecté (détail : client/rapport.md)
Connexion OK (client/04-connecte.png). Montants cohérents : /store/1 Gratuit + Petite 512 Mo 3 500 F/mois, commission 0 F ; /store/1/deployer « à payer aujourd'hui 3 500 F », frais du moyen de paiement en sus. Arrêt avant « Payer 3 500 F » (seul accès à SasPay) — aucun paiement initié.

| ID | Sévérité | Repro | Attendu / Obtenu | Preuve | Impact | Correctif |
|---|---|---|---|---|---|---|
| QA-006 | Majeur (à confirmer) | /store/1/deployer | Choix Petite/Moyenne/Grande (3 500/7 000/13 500 F) + variables client / seule Petite récapitulée, ni sélecteur ni variables | client/07-deployer-avant-paiement.png | Client ne peut pas choisir sa formule | Afficher le sélecteur de formule (ou expliquer si l'appli impose Petite) |
| QA-007 | Majeur | Accès direct /factures (route présente dans le bundle) | Liste des factures / « Cette page n'existe pas » | client/10-factures-404.png | Lien mort si référencé (emails, menus) | Router /factures vers /paiements ou créer la page |
| QA-008 | Majeur | Compte client → /tableau | Tableau client / métriques auteur (vues, applis publiées, encaissé) + CTA « Publier une appli » | client/15-tableau.png | Confusion des rôles | Tableau selon le profil |
| QA-009 | Info (→ Sécurité) | /store/1 | Appli listée malgré « 61 dépendances avec faille connue, dont 1 Critique » | client/06-fiche.png | Confiance client | Politique de seuil avant mise en vente |
| QA-010 | Mineur | Accès direct /paiement/retour | Message clair / « Lien de retour incomplet » + renvoi Mes paiements (OK) | client/11-paiement-retour.png | Faible | RAS, comportement correct |

## Phase 3 — Dev (lecture seule) (captures : dev/)
Connexion GitHub OK (compte octavebahoun). Tour en lecture seule de 15 pages : /publier, /apps, /apps/verification, /apps/soukdev-json, /echange, /missions, /evenements, /revenus (aucun RIB / numéro de reversement saisi), /notifications, /profil, /devs/octavebahoun, /devs/inexistant, /tableau, /trouver-un-dev, /logout. Aucune publication, aucune discussion créée, aucune page /admin ouverte.

**Bons points.** Les états vides de /missions, /evenements, /revenus et /notifications sont clairs (dev/18-missions.png, 19-evenements.png, 20-revenus.png, 21-notifications.png). Le formulaire /publier se fait en quatre étapes, avec le prix en F, les choix Mensuel ou Une fois, et les tailles 3 500, 7 000 et 13 500 F (dev/12-publier.png).

**Rattachements.** La faute « portoflio open source » (contenu du dev, visible aussi depuis le compte dev) reste QA-002. La pastille « Problèmes détectés » sur une appli déjà publiée reste QA-009 (à transmettre à Sécurité).

| ID | Sévérité | Repro | Attendu / Obtenu | Preuve | Impact | Correctif |
|---|---|---|---|---|---|---|
| QA-011 | Faible | Accès direct /logout | Déconnexion ou redirection vers l'accueil / « Cette page n'existe pas » | dev/00-logout-route-404.png | Lien mort si quelqu'un y accède ou le référence | Router /logout vers l'action de déconnexion du menu, qui fonctionne |
| QA-012 | Info (positif) | /connexion?profil=dev → « Continuer avec GitHub » | Scopes minimaux / `user:email` et `read:user` uniquement, aucun scope de dépôt | dev/02-connexion-dev.png | RAS : surface d'autorisation limitée, cohérente avec « dépôts publics uniquement » | Conserver ces scopes ; l'écran de consentement le confirme |
| QA-013 | Mineur | Accès /apps, /apps/verification, /apps/soukdev-json ; menu « Mes applis » | Pages de gestion des applis / « Cette page n'existe pas » ; « Mes applis » mène à /publier | dev/13-apps.png, 14-apps-verification.png, 15-soukdev-json.png | Le dev ne peut pas lister ni gérer ses applis ; routes documentées mortes | Créer les pages ou les rediriger ; faire pointer « Mes applis » vers la liste réelle |
| QA-014 | Mineur | Accès direct /trouver-un-dev | Page de recherche de devs / « Cette page n'existe pas » ; la vraie route est /devs | dev/24-trouver-un-dev.png | Lien mort si une ancienne URL est encore citée | Rediriger /trouver-un-dev vers /devs |
| QA-015 | Majeur (à confirmer, → Sécurité) | Compte « Dev » → menu « Mon espace » | Liens d'administration absents, sauf si le compte est admin / Finances, Serveurs et Modération pointent vers /admin/finances, /admin/serveurs et /admin/moderation (pages non ouvertes) | dev/10-menu-compte.png, 11-tableau.png | Surface d'administration exposée à un simple dev si le compte n'est pas admin | N'afficher ces liens que pour un rôle admin ; à confirmer si ce compte l'est |
| QA-016 | Mineur | /profil comparé à /devs/:username | Section réputation (Souk Score, badges) aussi sur le profil / absente de /profil ; Score 65/1000 et badges seulement sur la page publique | dev/22-profil.png, 23-devs-public.png | Le dev ne voit pas sa réputation dans son espace | Afficher le Souk Score et les badges aussi sur /profil |
| QA-017 | Cosmétique | Menu du compte | Le @username est visible / le menu ne l'affiche pas | dev/10-menu-compte.png | Orientation | Afficher le @username dans le menu du compte |
| QA-018 | Mineur | Listes de pays sur /profil, /revenus et /devs | Un seul référentiel, complet / 17 pays sur /profil, 7 sur /revenus, 5 sur /devs ; le Cameroun est absent des autres listes | dev/20-revenus.png, 22-profil.png, 24-trouver-un-dev.png | Pays manquants selon l'écran, risque d'incohérence de profil | Unifier la liste des pays sur les trois écrans |
| QA-019 | Bloquant (confirmé) | /echange → « Nouvelle discussion » : titre, texte, étiquette bug, fiche du bug et dépôt remplis | Publication possible / le sélecteur « Canal » n'a aucune option sous « Généraux » et « Par pays » ; le canal est obligatoire, donc « Publier la discussion » reste désactivé, sans message expliquant pourquoi | dev/16-echange.png, 17-nouvelle-discussion.png, 42-liste-canaux.webp, 43-discussion-remplie.webp, 44-discussion-publiee.webp | Tout le parcours bug → correctif → copie de test → acceptation est impossible | Créer des canaux par défaut (Général, Bénin…) ou rendre le canal facultatif, et afficher ce qui manque |
| QA-020 | Cosmétique | /tableau, /missions, /notifications | Pied de page comme sur les autres pages ; chargement discret / squelette d'environ 2 s avec un menu latéral vide sur /tableau ; pas de pied de page sur /missions, /notifications et /tableau | dev/11-tableau.png, 18-missions.png, 21-notifications.png | Impression de page inachevée | Harmoniser le pied de page ; ne pas afficher un menu vide pendant le chargement |
| QA-021 | Mineur | /devs/inexistant | Message d'introuvable clair / « Profil indisponible… » avec un bouton « Réessayer » | dev/25-dev-inexistant.png | On croit à une erreur transitoire plutôt qu'à une absence | Page « profil introuvable », sans « Réessayer » |
| QA-022 | Mineur (→ Perf SEO) | Onglet du navigateur, toutes les pages | Titre propre à chaque page / partout le même : « Souk.dev — le marché des applis des devs africains » | Constat global (déjà côté Perf SEO) | SEO et orientation dans les onglets | Titre unique par page, à transmettre à Perf SEO |

## Phase 4 — Publication et échange (captures : dev/)
Dépôt de test public [octavebahoun/audit-qa-souk-todo](https://github.com/octavebahoun/audit-qa-souk-todo) (dev/26-depot-audit-cree.png). Publication depuis /publier : l'appli est en ligne sur https://soukdev.shop/store/2. Branche de correctif `fix-tache-vide` (commit `c6e144d`, dev/41-branche-fix.webp) préparée pour l'échange. Le parcours bug → correctif → copie de test → acceptation n'a pas pu aboutir (QA-019, confirmé bloquant ; preuves 42-44).

**Bons points.** Messages d'erreur de dépôt clairs : « Le champ adresse du dépôt doit être une URL valide. » et « Impossible de cloner le dépôt GitHub public. » (dev/30-publier-url-invalide.png, 31-publier-depot-inexistant.png). Analyse rapide, avec le badge Security Checked moins d'une minute après la publication (dev/38-publier-resultat.png, 39-fiche-appli-test.png). Fiche https://soukdev.shop/store/2 cohérente : Gratuit, commission 0 F, hébergement 3 500 F/mois (dev/39-fiche-appli-test.png). La fiche bug s'ouvre avec l'étiquette bug, et un sous-filtre Difficulté (dev/43-discussion-remplie.webp, 48-echange-filtres.webp).

**Artefacts de test.** Dépôt https://github.com/octavebahoun/audit-qa-souk-todo ; branche `fix-tache-vide` (commit `c6e144d`) ; appli publiée /store/2.

| ID | Sévérité | Repro | Attendu / Obtenu | Preuve | Impact | Correctif |
|---|---|---|---|---|---|---|
| QA-023 | Majeur | /publier → prix `-100`, puis `abc` | Refus du négatif et message d'erreur sur une saisie non numérique / le signe est perdu et 100 F s'affiche, sans erreur ; `abc` laisse le prix vide, sans message | dev/34-publier-prix-invalide.png | Un prix erroné peut être publié ; la saisie invalide n'est pas expliquée | Refuser les montants négatifs ou nuls selon la règle métier ; afficher une erreur pour les caractères non numériques |
| QA-024 | Mineur | /publier → démo `http://exemple.com` | Refus ou exigence HTTPS, conformément à l'aide « Sa démo, en HTTPS » / l'URL HTTP est acceptée | dev/33-publier-demo-http.png | L'aide et le contrôle ne correspondent pas ; démo non sécurisée | N'accepter que les URL en HTTPS, ou corriger le texte d'aide |
| QA-025 | Mineur | /publier → lien de démo = URL du dépôt GitHub (ou n'importe quelle URL) | Vérifier que l'appli de démo est bien en ligne / n'importe quelle URL est acceptée, y compris celle du dépôt | dev/39-fiche-appli-test.png | Lien de démo inutile ou trompeur sur la fiche | Vérifier que l'URL répond en HTTPS et sert l'appli, pas seulement un dépôt |
| QA-026 | Cosmétique | /publier → vérification du dépôt | Message confirmant le service, le port et la présence de soukdev.json et docker-compose.yml / « Dépôt valide : service web « web », backend propre. » — ni le port ni les fichiers ne sont confirmés | dev/32-publier-depot-verifie.png | Le dev n'a pas la preuve que les fichiers attendus ont bien été lus | Mentionner le port (80) et la présence des fichiers à la racine |
| QA-027 | Mineur (→ Paiement) | /publier → récapitulatif à 15 000 F | Détail de la commission et de la part nette du dev / le montant 15 000 F est affiché sans ce détail | dev/35-publier-prix-15000.png | Le dev publie sans savoir ce qu'il touchera | Afficher commission et net ; à transmettre à Paiement |
| QA-028 | Mineur | /echange → recherche du bandeau | Recherche dans les discussions / la recherche du bandeau mène vers /store?q= | dev/48-echange-filtres.webp | Impossible de chercher une discussion depuis Échange | Recherche propre à /echange, ou indiquer clairement que le bandeau ne cherche que le store |

### QA-029 — Majeur — Aucun moyen de dépublier ou masquer une appli
- Étapes : en tant qu'auteur, chercher une action de gestion pour l'appli /store/2 dans la fiche, dans /tableau, dans « Mes applis » (qui ouvre /publier) et dans /admin/moderation.
- Attendu : un bouton Dépublier, Masquer ou Mettre hors ligne.
- Obtenu : aucune option. La fiche propose seulement Relancer l'analyse et Publier la version. /store/2/modifier et /store/2/edit renvoient 404, et il n'y a pas d'onglet Applis en modération.
- Preuve : dev/50-gestion-appli.png, dev/52-store-apres.png
- Impact : un dev ne peut pas retirer une appli cassée ou abandonnée, et l'appli de test reste en tête du Store en production.
- Correctif : ajouter Dépublier/Masquer pour l'auteur, et une action de modération des applis côté admin.

## Phase 5 — Échange complet (canal audit-qa, accord d'Octave du 10/11 à 11h27)

QA-019 se débloque une fois un canal créé. Le parcours a pu aller jusqu'au bout : canal → discussion → correctif → copie de test → acceptation. Captures : dev/52b à dev/62.

### QA-030 — Majeur — La copie de test déploie la branche principale et non la branche du correctif
- Étapes : sur /echange/1, proposer la branche fix-tache-vide, puis « Essayer sur une copie de test » (https://d4.souk-apps.duckdns.org), puis cliquer sur Ajouter avec le champ vide.
- Attendu : la copie fait tourner la branche proposée, donc la tâche vide est refusée par une alerte.
- Obtenu : la tâche vide est acceptée. La page servie par la copie contient `const texte = champ.value;` (l.35) sans le contrôle `trim()` que contient la branche fix-tache-vide (l.36 du fichier brut sur GitHub). La copie sert donc main.
- Preuve : dev/58-copie-test.png, dev/59-copie-test-resultat.png, plus la comparaison faite avec curl.
- Impact : la fonction « essayer avant d'accepter » ne teste pas le correctif. On peut accepter un correctif sans l'avoir vérifié.
- Correctif : cloner la branche ou le ref de la proposition (checkout du commit proposé) et afficher le commit déployé dans la copie.

### QA-031 — Majeur — Un auteur peut proposer et accepter son propre correctif et gagner de la réputation
- Étapes : en tant qu'auteur de /echange/1, proposer un correctif sur sa propre discussion, puis l'accepter.
- Attendu : refus, ou acceptation possible mais sans gain de réputation.
- Obtenu : la proposition et l'acceptation passent, et le Souk Score passe de 65 à 205/1000 (de 100 à 250 XP).
- Preuve : dev/57-proposer-correctif.png, dev/60-correctif-accepte.png
- Impact : la réputation se gonfle seul à l'infini, et le classement /devs n'est plus fiable.
- Correctif : interdire l'auto-proposition, ou ne donner aucun XP quand l'auteur de la proposition est l'auteur de la discussion. Ajouter une limite de débit.

### QA-032 — Mineur — Réputation incohérente après acceptation
- Obtenu : le profil affiche « 0 bug résolu » et le badge « Premier correctif » comme « pas encore obtenu », alors que « 1 correctif accepté » apparaît et que le score a augmenté.
- Preuve : dev/60-correctif-accepte.png
- Correctif : recalculer les compteurs et les badges au moment de l'acceptation.

### QA-033 — Mineur — Aucune notification pour les événements d'Échange
- Obtenu : /notifications reste sur « Pas encore de notification » après une proposition de correctif et son acceptation, alors que la page promet « Un correctif proposé… apparaîtra ici ».
- Preuve : dev/62-notifications.png
- Remarque : c'est peut-être lié à l'auto-proposition. À revérifier avec deux comptes dev.

### QA-034 — Cosmétique — Création de canal sans choix de visibilité ni modération
- Obtenu : n'importe quel dev connecté crée un canal public dans Généraux (nom, description facultative, pays facultatif), qui est publié aussitôt avec le message « Canal #audit-qa créé. ».
- Preuve : dev/53-creer-canal.png, dev/54-canal-cree.png
- Correctif : prévoir une validation par l'admin ou une limite, pour éviter la prolifération de canaux. À évaluer par Sécurité et la modération.

### Bons points
- La confirmation d'acceptation est claire : « La discussion passe en résolue ; Souk.dev ne fusionne rien sur GitHub. »
- Les filtres bug, Ouvertes et Résolues fonctionnent (0 discussion ouverte, 1 résolue).
- La copie de test a démarré gratuitement, sans paiement.

### À nettoyer (artefacts créés par QA)
- Canal Échange `audit-qa` : https://soukdev.shop/echange?canal=audit-qa
- Discussion https://soukdev.shop/echange/1 (résolue) et son correctif accepté
- Copie de test en ligne : https://d4.souk-apps.duckdns.org
- Appli publiée /store/2 (`audit-qa-souk-todo`), sans moyen de la dépublier (voir QA-029)
- Dépôt public https://github.com/octavebahoun/audit-qa-souk-todo et sa branche fix-tache-vide (commit c6e144d). Aucune PR créée.
- Score du compte octavebahoun gonflé de 140 points par l'auto-acceptation (QA-031), à corriger en base.

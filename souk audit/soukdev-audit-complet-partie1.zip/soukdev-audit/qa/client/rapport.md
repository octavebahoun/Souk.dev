# QA Souk.dev — parcours client (compte de test)

## Résumé
- Connexion réussie; capture `04-connecte.png`.
- Aucun réseau Mobile Money choisi, aucun numéro ni carte saisi, aucun paiement initié.
- Parcours SasPay non ouvert : l’unique action disponible sur l’écran de commande est « Payer 3 500 F », explicitement interdite par la consigne. Aucune variable ni sélecteur de formule n’était visible avant ce bouton.

## Étapes et montants observés
| Page / étape | Résultat / textes et montants | Capture |
|---|---|---|
| `/` | Accueil; explication du modèle et « dès 3 500 F par mois ». Page complète rendue. | `01-accueil.png` |
| `/store` | Une appli, `portfolio-open`, catégorie « Autre », « Gratuit ». | `05-store-initial.png` |
| `/store?q=portfolio` | Recherche renvoie 1 appli. | `02-recherche.png` |
| `/store?q=portfolio&categorie=sante` | Santé sélectionnée; 0 appli correspondante, message d’état vide. | `03-categorie-sante.png` |
| `/store/1` | Appli : Gratuit; Petite (512 Mo) : 3 500 F/mois; commission 0 F; total 3 500 F/mois. Fiche indique aussi 61 dépendances vulnérables, dont une critique. | `06-fiche.png` |
| `/store/1/deployer` | Récapitulatif : appli gratuite, hébergement Petite 3 500 F/mois, à payer aujourd’hui 3 500 F, puis même montant chaque mois; frais du moyen de paiement en plus. | `07-deployer-avant-paiement.png` |
| `/copies` | « Vous n’avez pas encore de copie ». Aucun montant. | `08-copies.png` |
| `/paiements` | « Aucune facture pour l’instant ». Aucun montant. | `09-paiements.png` |
| `/factures` | Page introuvable (404). | `10-factures-404.png` |
| `/paiement/retour` | « Lien de retour incomplet »; renvoie vers Mes paiements. Aucun montant. | `11-paiement-retour.png` |
| `/notifications` | « Pas encore de notification ». | `12-notifications.png` |
| `/notifications/reglages` | Préférences visibles, interrupteurs activés; e-mail des suspensions indiqué « Toujours envoyé ». | `13-notifications-reglages.png` |
| `/profil` | Pays et bio facultatifs laissés vierges; aucune modification enregistrée. | `14-profil.png` |
| `/tableau` | Dashboard affiche vues 0, copies actives 0, encaissé ce mois-ci 0 F et depuis le début 0 F; « Aucune appli publiée ». | `15-tableau.png` |

## Problèmes
1. **Majeur — Choix de formule / variables impossibles à tester**. URL `/store/1/deployer`. Attendu : afficher les trois formules (Petite 3 500 F, Moyenne 7 000 F, Grande 13 500 F), permettre de sélectionner Petite et de renseigner les variables avant SasPay. Obtenu : seule Petite (512 Mo), à 3 500 F/mois, est récapitulée; aucune sélection ni variable n’est présentée. Le bouton « Payer 3 500 F » est le seul accès suivant; non cliqué conformément à la règle anti-débit. Capture `07-deployer-avant-paiement.png`.
2. **Majeur — Route factures morte**. URL `/factures`. Attendu : accès direct à la page des factures. Obtenu : « Cette page n’existe pas » (404), alors que `/paiements` est présenté comme l’espace des factures. Capture `10-factures-404.png`.
3. **Majeur — Tableau de bord orienté développeur pour un compte client/Entreprise**. URL `/tableau`. Attendu : contenu adapté à l’espace client. Obtenu : métriques d’auteur (vues, applis publiées, revenus) et CTA « Publier une appli ». Capture `15-tableau.png`.
4. **Mineur — Faute visible dans la description de la fiche**. URL `/store/1`. Obtenu : « portoflio open source » au lieu de « portfolio open source ». Captures `05-store-initial.png` et `06-fiche.png`.
5. **Majeur — Avertissement de sécurité sur l’appli**. URL `/store/1`. La fiche avertit que 61 dépendances ont une faille connue, dont une criticité « Critique ». Capture `06-fiche.png`.

## Captures
Toutes les captures créées sont dans `/workspace/soukdev-audit/qa/client/`. La capture `04-connecte.png` confirme la session; aucun lien de connexion n’est inclus dans les captures de parcours.

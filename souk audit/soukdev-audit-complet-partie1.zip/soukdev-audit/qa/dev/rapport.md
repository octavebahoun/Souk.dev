# QA Souk.dev — profil dev

**Résultat : partiel / bloqué à la connexion GitHub.** Aucune autorisation OAuth n'a été accordée et aucun dépôt n'a été touché.

## Parcours effectué

1. `https://soukdev.shop/logout` a affiché « Cette page n'existe pas ». Capture : `00-logout-route-404.png`.
2. Sur `https://soukdev.shop/connexion?profil=dev`, le menu du compte montrait qu'une session client était ouverte. J'ai choisi **Se déconnecter**. La page est revenue à l'accueil; les liens « Se connecter » et « Publier une appli » confirmaient la déconnexion. Capture de l'état déconnecté : `01-logout-client.png`.
3. J'ai rouvert `https://soukdev.shop/connexion?profil=dev` (profil **Développeur** sélectionné). Le texte clé affiché est : « Dépôts publics uniquement : on ne demande jamais l’accès à vos dépôts privés. » Capture : `02-connexion-dev.png`.
4. Après **Continuer avec GitHub**, GitHub a demandé une connexion. La page affiche les champs « Username or email address » et « Password », ainsi que l'option « Sign in with a passkey ». Je me suis arrêté sans saisir d'identifiant, mot de passe, code ou passkey, comme demandé. Capture : `03-github-signin.png`.

URL de l'écran GitHub (valeur anti-CSRF `state` masquée) :
`https://github.com/login?client_id=Ov23liXbZfiwbiXQq0Me&return_to=%2Flogin%2Foauth%2Fauthorize%3Fclient_id%3DOv23liXbZfiwbiXQq0Me%26redirect_uri%3Dhttps%253A%252F%252Fapi.soukdev.shop%252Fauth%252Fgithub%252Fcallback%26response_type%3Dcode%26scope%3Duser%253Aemail%252Cread%253Auser%26state%3D[masqué]`

## Permissions OAuth observées

L'écran de consentement n'a pas été atteint; les permissions finales ne peuvent donc pas être confirmées. Dans le paramètre `scope` de la redirection GitHub, les scopes demandés sont exactement **`user:email`** et **`read:user`**. Aucun scope de dépôt (`repo`, `public_repo`, etc.) n'apparaît dans cette requête observée : pas d'accès dépôt ni d'écriture dépôt indiqués. La page Souk.dev affirme également que seuls les dépôts publics sont concernés et que l'accès aux dépôts privés n'est jamais demandé. Aucun accès n'a été autorisé.

## Problèmes / constats

### 1. Route de déconnexion directe inexistante — sévérité faible
- **Étapes :** ouvrir `/logout`.
- **Attendu :** déconnexion ou redirection vers l'accueil.
- **Obtenu :** page « Cette page n'existe pas ».
- **URL :** `https://soukdev.shop/logout`
- **Capture :** `00-logout-route-404.png`
- **Résolution :** la déconnexion a réussi via le menu du compte (« Se déconnecter »); état anonyme confirmé à l'accueil (`01-logout-client.png`).

### 2. Connexion GitHub requise avant l'écran OAuth — sévérité bloquante pour cet audit
- **Étapes :** connexion dev Souk.dev → « Continuer avec GitHub ».
- **Attendu :** écran de consentement OAuth à examiner.
- **Obtenu :** formulaire GitHub demandant un nom d'utilisateur/e-mail et mot de passe, avec une option passkey. L'instruction exigeait de s'arrêter à ce point.
- **URL :** URL GitHub ci-dessus (`state` masqué).
- **Capture :** `03-github-signin.png`
- **Suite :** connexion laissée à l'utilisateur; aucune permission n'a été approuvée.

## Pages visitées et restantes

Visitées : `/logout` (404), `/`, `/connexion?profil=dev`, puis la page de connexion GitHub. Les pages `/publier`, `/apps`, `/apps/verification`, `/apps/soukdev-json`, `/echange`, `/missions`, `/evenements`, `/revenus`, `/notifications`, `/profil`, `/devs/octavebahoun` et `/tableau` **n'ont pas été ouvertes**, car le parcours s'est arrêté au formulaire GitHub conformément à la consigne. Aucun formulaire de publication ou de reversement n'a été utilisé.

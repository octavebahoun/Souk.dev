# Audit Perf, SEO & Accessibilité — Souk.dev

- **Cible** : https://soukdev.shop  
- **Date** : 10 nov. 2026, Europe/Paris (CET, UTC+1)  
- **Contexte** : audit non destructif **avant mise en prod**  
- **Stack** : SPA **React 19 + Vite/Rolldown** (front), API Laravel (hors mesure navigateur)  
- **Méthode** : Lighthouse 12 (Chrome headless), axe-core via Playwright (CSP bypass local), curl ; ~1 req/s hors runs Lighthouse espacés ; ≤ ~20 URLs  
- **Hors zone** : bugs métier, ergonomie tactile, OAuth GitHub (non exercé)  
- **Artifacts bruts** : `/workspace/souk-audit/` (JSON/HTML Lighthouse, axe, meta) et copies dans `/workspace/soukdev-audit/raw-lighthouse/`, `axe-results.json`, `seo-*.json`

---

## Résumé exécutif — Top 5 priorités

1. **PERF-01 — Activer la compression Brotli/gzip** sur HTML/JS/CSS : ~**450–468 KiB** économisés (mesuré Lighthouse). Sans ça, LCP mobile 4–7 s et score perf 61–75. Correctif Caddy/`encode`.
2. **SEO-01 — Servir un vrai `robots.txt` et `sitemap.xml`** : aujourd’hui `Content-Type: text/html` + shell SPA (5680 o). Bloque le crawl propre et fait échouer Lighthouse SEO (`robots-txt`, 55 erreurs).
3. **SEO-02 / SEO-03 — Indexabilité SPA** : HTML brut = squelette sans contenu métier, **mêmes** `<title>` / meta description sur toutes les URLs, **aucun** Open Graph / Twitter / canonical / JSON-LD. Les crawlers sans JS voient une coquille vide.
4. **SEO-04 — Soft-404 HTTP** : URLs inventées, `/admin`, `/store/999999` répondent **200** + HTML SPA (client affiche « Page introuvable »). Risque d’indexation de pages vides / dilution.
5. **PERF-02 — Captures PNG trop lourdes + sans cache** : sur `/store/1`, ~**590 KiB** d’images (PNG non WebP/AVIF), Lighthouse estime **~464 KiB** en formats modernes et **~530 KiB** en responsive ; `Cache-Control` absent sur `api…/storage/captures/*`.

---

## Tableau des métriques Lighthouse

Throttling mobile par défaut = **Slow 4G simulé** Lighthouse. Run dédié « Afrique Ouest entrée de gamme » = **3G ~1,6 Mbps, RTT 300 ms, CPU ×6**.

| Page | Form factor | Perf | A11y | BP | SEO | LCP | FCP | CLS | TBT | Speed Index | Poids total | Requêtes (approx.) |
|---|---|---:|---:|---:|---:|---|---|---|---|---|---|---|
| `/` | Mobile Slow 4G | **75** | 100 | 96 | 92 | **4,4 s** | 4,1 s | 0 | 0 ms | 4,1 s | 928 KiB | 28 |
| `/` | Mobile 3G / CPU×6 | **63** | — | — | — | **7,4 s** | 4,7 s | 0 | 60 ms | 5,3 s | 928 KiB | — |
| `/` | Desktop | **68** | 100 | 96 | 92 | **3,0 s** | 2,6 s | 0,003 | 0 ms | 2,6 s | 928 KiB | 28 |
| `/store` | Mobile Slow 4G | **68** | 100 | 96 | 92 | **7,4 s** | 3,5 s | 0 | 20 ms | 3,5 s | 864 KiB | 22 |
| `/store` | Desktop | **93** | 100 | 96 | 92 | **1,4 s** | 0,6 s | 0,084 | 0 ms | 1,1 s | 864 KiB | — |
| `/store/1` (portfolio-open) | Mobile Slow 4G | **70** | 100 | 96 | 92 | **5,4 s** | 4,1 s | 0 | 20 ms | 4,1 s | **1 349 KiB** | 38 |
| `/store/1` | Desktop | **61** | 100 | 96 | 92 | **3,9 s** | 3,4 s | 0,003 | 0 ms | 3,4 s | **1 334 KiB** | — |
| `/devs/octavebahoun` | Mobile Slow 4G | **61** | 100 | 96 | 92 | **7,2 s** | 4,4 s | 0,085 | 0 ms | 5,6 s | 962 KiB | — |
| `/devs/octavebahoun` | Desktop | **63** | 100 | 96 | 92 | **3,2 s** | 2,0 s | **0,199** | 0 ms | 2,0 s | 962 KiB | — |

**Répartition poids typique (home mobile)** : JS ≈ **621 KiB**, CSS ≈ **65 KiB**, images ≈ **219 KiB**, font ≈ **32 KiB**, HTML ≈ **6 KiB**.  
**Bundles clés (Content-Length, sans compression)** : `index-*.js` **260 752 o**, `titre-*.js` ~179 Ko (présent dans unused-JS), CSS **65 089 o**, hero WebP **23 174 o**.

**PageSpeed Insights / CrUX** : API publique `pagespeedonline/v5` → **HTTP 429** quota dépassé (sans clé). **Pas de données terrain CrUX** dans cet audit.

**Limite login** : `/connexion` mesurée côté SEO/axe (page publique « Se connecter » / GitHub). **Aucun OAuth GitHub** lancé ; parcours post-auth (`/copies`, `/paiements`, `/admin/*` authentifié) non audités en perf.

---

## Performance

### PERF-01 — Pas de compression texte (br/gzip)
- **Sévérité** : Critique  
- **Repro** : `curl -sI -H 'Accept-Encoding: br,gzip' https://soukdev.shop/assets/index-CLTRcOvM.js` → pas de `Content-Encoding` ; `Content-Length: 260752`. Idem CSS/HTML.  
- **Preuve** : Lighthouse `uses-text-compression` score 0 ; économies estimées **453 KiB** (home) à **468 KiB** (fiche). Top fichiers : `index-CLTRcOvM.js` (wasted ~181 KiB), `titre-CpeQ2xLE.js` (~114 KiB), `index-TRsC6q5x.css` (~53 KiB).  
- **Impact** : sur Slow 4G / 3G Afrique de l’Ouest, téléchargement JS+CSS gonflé → FCP/LCP 4–7 s, abandon probable store/fiche.  
- **Correctif** : côté **Caddy** (déjà en frontal) activer `encode zstd gzip` (ou br) pour `text/html`, `application/javascript`, `text/css`, `application/json`. Vérifier que l’origin nginx ne strippe pas l’encodage. Assets hashés Vite restent `immutable`.

### PERF-02 — Captures d’applis PNG lourdes, non modernes, peu adaptées
- **Sévérité** : Haute  
- **Repro** : ouvrir `/store/1` ; Lighthouse mobile.  
- **Preuve** : transfert images fiche ≈ **590 KiB** ; `modern-image-formats` ~**464 KiB** économisables (`captures/1/2.png` ~385 KiB wasted, `1/1.png` ~90 KiB) ; `uses-responsive-images` ~**530 KiB**. Hero home déjà en **WebP** (bon).  
- **Impact** : LCP/poids de la fiche produit (parcours conversion) ; desktop perf **61**.  
- **Correctif** : pipeline upload → variantes WebP/AVIF + largeurs (ex. 640/960/1280) ; `<img srcset>` / `<picture>` dans le composant React `CarteAppli` / fiche ; compression à la source.

### PERF-03 — Cache HTTP absent sur `/storage/captures/*`
- **Sévérité** : Haute  
- **Repro** : `curl -sI https://api.soukdev.shop/storage/captures/1/1.png`  
- **Preuve** : Lighthouse `uses-long-cache-ttl` : `cacheLifetimeMs: 0` sur captures (157–432 KiB). Assets front `/assets/*` OK : `max-age=31536000, public, immutable`. HTML : `no-cache` (acceptable pour SPA shell).  
- **Impact** : re-téléchargement systématique des captures à chaque visite.  
- **Correctif** : en-têtes `Cache-Control: public, max-age=604800` (ou plus avec fingerprint URL) sur le storage API / Caddy API.

### PERF-04 — JavaScript unused important (~268–272 KiB)
- **Sévérité** : Haute  
- **Preuve** : Lighthouse `unused-javascript` : `index-CLTRcOvM.js` ~120 KiB wasted, `titre-CpeQ2xLE.js` ~83–87 KiB, `fonctionsAnimation-Dw_cXl0H.js` ~43 KiB (quasi tout le fichier).  
- **Impact** : parse/compile sur CPU ×4–×6 (téléphones entrée de gamme) ; contribue au délai avant hydratation (LCP fiche = surtout *Render Delay* 86 %).  
- **Correctif** (Vite/React 19) : code-split plus agressif ; charger animations seulement si utilisées ; auditer ce que contient `titre-*` / bundle principal ; `manualChunks` / dynamic `import()`.

### PERF-05 — LCP mobile trop élevé (CWV « Poor » sur plusieurs pages)
- **Sévérité** : Haute  
- **Preuve** : LCP Slow 4G : home **4,4 s**, store **7,4 s**, fiche **5,4 s**, profil **7,2 s** ; 3G/CPU×6 home **7,4 s**. Seuil « good » LCP = 2,5 s. TBT globalement bas (0–60 ms) — bon signe pour INP lab. CLS home/store/fiche ≈ 0 ; **profil desktop CLS 0,199** (à surveiller).  
- **Impact** : Core Web Vitals lab mauvais avant prod ; SEO Google + UX 3G.  
- **Correctif** : enchaîner PERF-01/02/04 ; précharger LCP image (déjà partiel sur hero) ; éviter LCP texte tardif après fetch API (fiche) — skeleton → contenu plus tôt ou prerender.

### PERF-06 — HTTP clair ne redirige pas vers HTTPS
- **Sévérité** : Moyenne (perf/confiance + SEO)  
- **Preuve** : `curl -sI http://soukdev.shop/` → **500** `Server: Pingora`, pas de `Location` HTTPS. `https://www` → **301** apex OK.  
- **Impact** : liens http cassés ; pas de HSTS possible tant que le redirect n’est pas fiable (signal aussi côté sécu).  
- **Correctif** : 301/308 http→https sur apex et www (edge Pingora / DNS).

### PERF-07 — Appel `/api/me` 401 dans la console à froid
- **Sévérité** : Basse (Best Practices)  
- **Preuve** : Lighthouse `errors-in-console` : `https://api.soukdev.shop/api/me` → 401.  
- **Impact** : bruit console / score BP 96 ; mineur pour perf.  
- **Correctif** : ne pas logger comme erreur réseau attendue, ou endpoint « session optionnelle » 204.

---

## SEO

### SEO-01 — `robots.txt` invalide (HTML SPA)
- **Sévérité** : Critique  
- **Repro** : `curl -sI https://soukdev.shop/robots.txt` → `content-type: text/html`, body `<!doctype html>…`  
- **Preuve** : Lighthouse `robots-txt` score 0, « 55 errors found » (premières lignes = balises HTML).  
- **Impact** : directives crawl absentes ; outils SEO / Search Console confus.  
- **Correctif** : fichier statique servi **avant** le fallback SPA (Caddy `handle /robots.txt`) :
  ```
  User-agent: *
  Allow: /
  Sitemap: https://soukdev.shop/sitemap.xml
  ```

### SEO-02 — `sitemap.xml` = HTML SPA
- **Sévérité** : Critique  
- **Repro** : `curl -sI https://soukdev.shop/sitemap.xml` → `text/html`, 5680 o.  
- **Impact** : Google ne découvre pas `/store/:id`, `/devs/:username`.  
- **Correctif** : générer un XML (`application/xml`) listant home, store, fiches apps, profils publics ; endpoint Laravel ou job + fichier statique ; exclure `/admin`, `/connexion`, soft-404.

### SEO-03 — Meta / OG / Twitter / canonical absents ou identiques (shell)
- **Sévérité** : Critique  
- **Repro** : comparer HTML brut de `/`, `/store`, `/store/1`, `/devs/octavebahoun`.  
- **Preuve** (curl) : partout le même `<title>Souk.dev — le marché…</title>` et la même meta description ; **aucun** `og:*`, `twitter:*`, `link rel=canonical`, JSON-LD. Après hydratation JS : titres deviennent corrects (`Store — Souk.dev`, `portfolio-open — Souk.dev`, `Octave BAHOUN-HOUTOUKPE — Souk.dev`) mais **toujours pas d’OG/Twitter/canonical** ; description reste celle du shell.  
- **Impact** : partage social générique/vide ; crawlers sans JS indexent un titre unique ; cannibalisation.  
- **Correctif** : prerender/SSR (ex. Vite SSR, ou prerender routes publiques) **ou** injection meta côté serveur par route ; `react-helmet-async` seul ne suffit pas aux bots non-JS. Ajouter OG image (capture appli / avatar).

### SEO-04 — Soft-404 (statut HTTP 200)
- **Sévérité** : Haute  
- **Repro** : `curl -sI https://soukdev.shop/cette-page-nexiste-pas-xyz-999` et `/admin`, `/store/999999` → **200** + même shell. Client : titre « Page introuvable — Souk.dev », h1 « Cette page n'existe pas ».  
- **Impact** : indexation de URLs fantômes ; `/admin` exposé en 200 (contenu 404 client — l’auth API reste critique côté sécu).  
- **Correctif** : pour routes inconnues, répondre **404** (edge ou SSR) ; éventuellement `noindex` sur 404 client en attendant. Ne pas servir `/admin/*` au crawler sans auth (robots + 401/404 serveur).

### SEO-05 — Contenu métier absent du HTML initial (CSR only)
- **Sévérité** : Haute  
- **Preuve** : HTML initial contient `#root` + squelette `aria-busy="true"` / barres de chargement ; pas de h1 métier, pas du nom d’appli. Framework : **SPA React 19 Vite** (pas Next.js).  
- **Impact** : indexabilité Store/fiches/profils faible hors Googlebot avancé.  
- **Correctif** : prerender des pages publiques (`/`, `/store`, `/store/:id`, `/devs/:username`, légales) ou migration progressive SSR ; au minimum meta + JSON-LD Product/Person dans le HTML.

### SEO-06 — Pas de données structurées JSON-LD
- **Sévérité** : Moyenne  
- **Preuve** : aucun `<script type="application/ld+json">` (HTML brut ni DOM rendu).  
- **Impact** : pas de rich results (SoftwareApplication, Product, Person, Organization).  
- **Correctif** : JSON-LD sur fiche (`SoftwareApplication` / `Product`) et profil (`Person`) + `Organization` sur home.

### SEO-07 — `lang="fr"` OK ; viewport OK (zoom non bloqué)
- **Sévérité** : Info / positif  
- **Preuve** : `<html lang="fr">` ; viewport `width=device-width, initial-scale=1.0, viewport-fit=cover` (pas de `user-scalable=no` / `maximum-scale=1`).  
- **www→apex** HTTPS 301 OK.

---

## Accessibilité (WCAG 2.2 AA — auto)

Scores Lighthouse **Accessibility = 100** sur toutes les pages mesurées. axe-core (Playwright, CSP bypass) : **1 violation** sérieuse sur fiche ; contrastes « incomplete » sur home/store (à vérifier manuellement).

### A11Y-01 — Région scrollable non focusable (`<pre>`)
- **Sévérité** : Haute (axe impact: serious)  
- **Repro** : `/store/1` — bloc code `git clone …`  
- **Preuve** : axe `scrollable-region-focusable`, cible `pre.overflow-x-auto` (snippet clone GitHub).  
- **Impact** : utilisateurs clavier / Safari ne peuvent pas scroller le snippet.  
- **Correctif** : `tabIndex={0}` + nom accessible, ou wrapper focusable ; éviter overflow-x sans focus.

### A11Y-02 — Captures / avatars avec `alt=""`
- **Sévérité** : Moyenne  
- **Preuve** : DOM rendu — captures `api…/storage/captures/1/*.png` et avatar GitHub en `alt=""` (home 5 images vides, fiche 2, profil 2). Lighthouse `image-alt` passe (alt présent mais vide = décoratif).  
- **Impact** : lecteurs d’écran n’annoncent pas le contenu visuel des applis (pertinence produit).  
- **Correctif** : `alt` descriptif (« Capture de portfolio-open — page d’accueil ») ; décoratifs purs seulement pour motifs UI.

### A11Y-03 — Contrastes à confirmer (axe incomplete)
- **Sévérité** : Moyenne (non conclusif auto)  
- **Preuve** : axe `incomplete` `color-contrast` : 6 nœuds (home), 4 (store).  
- **Impact** : possible échec AA sur texte doux / badges.  
- **Correctif** : revue manuelle thème clair/sombre ; tokens Tailwind `text-texte-doux` vs fond.

### A11Y-04 — Points positifs mesurés
- Skip link « Aller au contenu » présent.  
- Boutons/liens nommés (0 sans nom sur pages testées).  
- Ordre de titres cohérent après rendu (un h1 par page).  
- Zoom non bloqué.  
- Skeleton initial avec `role="status"` / `aria-busy`.

---

## Synthèse par sévérité

| ID | Sévérité | Thème |
|---|---|---|
| PERF-01 | Critique | Compression absente |
| SEO-01 | Critique | robots.txt HTML |
| SEO-02 | Critique | sitemap.xml HTML |
| SEO-03 | Critique | Meta/OG identiques / absents |
| PERF-02 | Haute | Images PNG captures |
| PERF-03 | Haute | Cache captures |
| PERF-04 | Haute | JS unused |
| PERF-05 | Haute | LCP CWV |
| SEO-04 | Haute | Soft-404 200 |
| SEO-05 | Haute | CSR sans contenu HTML |
| A11Y-01 | Haute | pre scrollable |
| PERF-06 | Moyenne | http→https 500 |
| SEO-06 | Moyenne | JSON-LD |
| A11Y-02 | Moyenne | alt vides captures |
| A11Y-03 | Moyenne | contrastes à valider |
| PERF-07 | Basse | 401 /api/me console |

---

## Limites de l’audit

- Pas de clé PageSpeed Insights → **pas de CrUX terrain**.  
- Pas de connexion GitHub OAuth → pas de Lighthouse sur `/copies`, `/paiements`, admin authentifié.  
- Lighthouse lab (simulation) ≠ RUM ; TBT ≠ INP réel.  
- axe auto ≠ audit manuel WCAG complet (clavier réel, lecteurs d’écran).  
- Catalogue = **1 appli** (`portfolio-open` id=1) au moment de la mesure.  
- Compression / soft-404 / robots vérifiés par curl ; scores Lighthouse issus des JSON dans `/workspace/souk-audit/`.

---

*Fin du rapport Perf / SEO / a11y — 10 nov. 2026 Europe/Paris.*

# Rapport d'audit consolidé — Souk.dev avant mise en production

| | |
|---|---|
| **Cible** | https://soukdev.shop · API https://api.soukdev.shop · temps réel wss://reverb.soukdev.shop |
| **Date** | 10 novembre 2026 (heure de Paris, UTC+1) — consolidation à 12:20, mises à jour à 12:58 (volet UX thème clair et `/missions`) 13:03 (revérification UX-056) et 13:20 (DEP-01 et DEP-02 confirmés par exécution locale) |
| **Code audité** | dépôt public `octavebahoun/Souk.dev`, branche `main`, commit `624431c` (9 nov. 2026, 23:52 heure de Paris) |
| **Coordination** | Lead Audit Souk |
| **Règles appliquées** | lecture et tests non destructifs, rien payé, pas de DoS ni de brute force, comptes de test (`+audit-…`) ou compte GitHub `octavebahoun` autorisé par Octave, aucun secret reproduit |

## 1. En-tête : périmètre, bots et statut des volets

| Volet | Bot | Fichier source | Statut d'après le fichier | Ce qui a été fait |
|---|---|---|---|---|
| Sécurité | Sécurité Souk | `securite.md`, `notes-secrets-verif.md`, `RAPPORT-RECON-PASSIVE.md` | **Terminé** (12:20), restes listés « non couverts » | En-têtes, TLS, CORS, cookies, secrets front et dépôt, OAuth Dev, comptes magic link A/B, 403 admin, IDOR lecture |
| Paiement | Paiement Souk | `paiement.md` | **Terminé** (12:20) pour le périmètre lecture seule | Pages publiques, revue de code SasPay/facturation, état réel de SD-2026-000003, page SasPay (captures UX) |
| Déploiement | Déploiement Souk | `deploiement.md` | **Partiel** : revue de code et exécution locale du vérificateur terminées (statut final 13:19) ; aucun test en production | Revue du moteur de copies Docker/Traefik, compose, formules, sauvegardes ; exécution locale de `VerificateurCompose`, `ValidateurSoukdev` et `LimitesTaille` |
| API | API Souk | `api.md` | **Terminé** (12:20), 4 passes | Anonyme, client authentifié, croisé A/B (IDOR), rôle Dev en lecture |
| Perf / SEO / a11y | Perf SEO Souk | `perf-seo-a11y.md` | **Terminé** (mesures de labo), limites listées | Lighthouse mobile/desktop, axe-core, robots/sitemap/meta |
| Parcours QA | QA Parcours Souk | `qa/RAPPORT-QA.md` (+ `qa/client/rapport.md`, `qa/dev/rapport.md`) | **Terminé** (phases 1 à 5) | Visiteur, client magic link, dev GitHub, publication, Échange complet |
| UX / mobile | UX Mobile Souk | `ux/rapport-public-v1.md`, `ux/rapport-connecte-dev-v1.md`, `ux/rapport-client-deployer-v1.md`, `ux/rapport-theme-clair-v1.md` | **Terminé avec réserves** : thème clair des pages connectées et `/missions` désormais couverts (12:56) ; commande connectée non vue en mobile (360/390/768), parcours complet Entreprise non fait | Pages publiques (4 largeurs, 2 thèmes), espace dev (sombre et clair), commande client, page SasPay, `/missions` |
| Carte | Lead Audit | `CARTE.md` | Terminé | Recon passive, rôles, répartition des 7 bots |

Note : `qa/dev/rapport.md` est un premier passage arrêté à la page de connexion GitHub ; il est remplacé par la phase 3 de `qa/RAPPORT-QA.md`.

---

## 2. Verdict : **NO-GO**

**La mise en production avec paiements réels n'est pas recommandée en l'état.** Les preuves confirment la tendance :

1. **Argent** : un défaut de code crédite une facture et lance la copie quand SasPay confirme un paiement dans une devise autre que XOF, sans comparer le montant (SOUK-001, PAY-01). L'exploitabilité n'est pas confirmée avec SasPay, mais le correctif est simple et doit précéder tout encaissement. Les reversements aux devs sont inactifs en prod (SOUK-007), et le client voit « Payer 3 500 F » puis 3 623 F chez un marchand nommé « Gentube » (SOUK-010, SOUK-011).
2. **Cœur du produit** : l'Échange (« postez un bug, un autre dev le corrige ») est inutilisable sans canal créé à la main (SOUK-002). Une fois débloqué, la copie de test ne teste pas le correctif (SOUK-003) et un auteur peut gonfler sa réputation en acceptant ses propres correctifs (SOUK-004).
3. **Cadre légal** : les CGU/CGV sont des brouillons « sans valeur contractuelle », sans mentions légales ni contact, et sans acceptation au paiement (SOUK-005, SOUK-028).
4. **Hygiène d'accès** : `http://soukdev.shop` et `http://www.soukdev.shop` renvoient 500 au lieu de rediriger vers HTTPS (SOUK-006), sans HSTS (SOUK-020).

Ce qui tient bien : pas d'IDOR, 403 admin, montants calculés côté serveur, webhook HMAC + re-vérification API, secrets absents du dépôt et du front, isolation des copies bien conçue (section 5). **Le passage au GO est atteignable** une fois les correctifs 1 à 7 du top 10 appliqués et revérifiés ; les points 8 à 10 peuvent suivre de près.

---

## 3. Top 10 des correctifs avant la prod (ordonnés)

1. **SOUK-001 (PAY-01)** — Dans `Encaissement::appliquerVerificationReussie`, refuser ou mettre en attente (sans créditer ni déployer) tout paiement dont la devise n'est pas XOF tant que l'équivalent XOF n'est pas vérifié ≥ montant de la facture ; confirmer le comportement auprès de SasPay ou en `sk_test`.
2. **SOUK-002 (QA-019)** — Créer des canaux par défaut sur l'Échange (Général, Bénin…) ou rendre le canal facultatif, et dire sous le bouton ce qui manque.
3. **SOUK-003 (QA-030)** — Faire déployer à la copie de test la branche ou le commit proposé, et afficher le commit servi.
4. **SOUK-004 (QA-031)** — Interdire l'auto-proposition ou ne donner aucun XP quand l'auteur du correctif est l'auteur de la discussion ; recalculer les scores gonflés.
5. **SOUK-005 + SOUK-028 (PAY-02, QA-001, UX-005/006, UX-041)** — Faire valider CGU/CGV/confidentialité/abus par un juriste, retirer le bandeau « Brouillon », publier mentions légales (éditeur, RCCM/IFU, hébergeur) et une page Contact, ajouter « En payant, vous acceptez les CGV » sur `/deployer`.
6. **SOUK-006 + SOUK-020 (SEC-006, SEC-005)** — Redirection 301/308 `http://` → `https://` sur l'edge Pingora pour apex et www (et l'API), puis HSTS sur tous les hôtes.
7. **SOUK-007 (PAY-03, UX-026)** — Activer `REVERSEMENTS_REELS` après liste blanche IP SasPay et test de reversement, ou afficher un seul message clair « reversements ouverts le … » (retirer la date contradictoire).
8. **SOUK-010 + SOUK-011 + SOUK-072 (PAY-04, UX-051, PAY-13, UX-050, UX-057)** — Afficher avant le clic le total frais inclus (ex. 3 500 F + 123 F = 3 623 F), n'afficher sur `/deployer` que les moyens de paiement réellement actifs chez SasPay, et renommer le compte marchand « Gentube » en « Souk.dev ».
9. **SOUK-008 + SOUK-009 (DEP-01, DEP-02)** — Refuser `extra_hosts`, `dns`, `dns_search`, `links` dans `VerificateurCompose` et plafonner la mémoire/CPU par projet, pas par conteneur.
10. **SOUK-012 (SEC-004, QA-005)** — Envoyer le lien magique depuis un domaine `soukdev.shop` avec SPF/DKIM/DMARC alignés : aujourd'hui il part de `send.excellenceteam.site` et arrive en spam.

Juste après : nettoyer la vitrine (SOUK-013 appli à 61 failles en tête, SOUK-014 capture personnelle, SOUK-015 appli de test publique et absence de « Dépublier ») et activer la compression (SOUK-016).

---

## 4. Constats dédoublonnés

Barème harmonisé : **Critique** = perte d'argent possible ou fonction cœur impossible ; **Haute** = risque sérieux de sécurité, de litige ou de confiance au moment de payer, à corriger avant la prod ; **Moyenne** = à corriger rapidement ; **Basse** = finition ou durcissement ; **Info** = observation. Les « Majeur » et « Bloquant » des bots ont été convertis selon ce barème ; les écarts sont signalés dans chaque fiche et récapitulés en 4.6.

Chemins des captures : relatifs à `/workspace/soukdev-audit/` (`ux/captures/…` pour UX, `qa/…` pour QA).

### 4.1 Critique

#### SOUK-001 — Paiement crédité sans contrôle du montant si la devise n'est pas XOF
- **Sources** : PAY-01 (Paiement, Critique).
- **Description** : quand SasPay confirme un `SUCCESS`, le montant n'est comparé à la facture que si la devise est XOF. Pour toute autre devise (ex. USD, paiement carte converti), la facture est passée `payee`, le grand livre est crédité et la copie est déployée ; seule une alerte admin est envoyée.
- **Reproduction** : lire `Encaissement::appliquerVerificationReussie` ; test existant `VerificationPaiementTest::test_une_carte_debitee_dans_une_autre_devise_est_creditee_et_verifiee_par_l_equipe` (crédite une facture FCFA avec `VerificationPaiement(..., 31, ..., 'USD')`).
- **Preuve** : `backend/app/Paiement/Encaissement.php` l.213-246 au commit `624431c` (relu en lecture seule) : `if ($devise === 'XOF' && montantDemande !== montant)` → blocage ; sinon `appliquerSucces()` puis, si `$devise !== 'XOF'`, simple `AlerteAdmin`.
- **Statut de preuve** : **défaut avéré dans le code, exploitabilité non confirmée avec SasPay.** Il faudrait que SasPay accepte, sur une session créée en XOF, un débit dans une autre devise ou d'un montant inférieur ; la doc SasPay ne documente pas ce champ et rien n'a été testé (aucun paiement, pas de sandbox fiable). Maintenu en Critique par prudence.
- **Impact** : une facture de 3 500 à 13 500 F pourrait être soldée par un paiement minime, avec mise en ligne immédiate de la copie avant toute revue humaine.
- **Correctif** : pour toute devise ≠ XOF, ne rien créditer ni déployer tant qu'un équivalent XOF ≥ montant facture n'est pas validé (file admin ou refus automatique), ou forcer le checkout en XOF et rejeter `currency !== XOF`. Ajouter le test inverse. Confirmer auprès du support SasPay ou en `sk_test`.

#### SOUK-002 — Échange inutilisable : aucun canal, publication d'une discussion impossible
- **Sources** : QA-019 (QA, Bloquant confirmé) ; UX-031 (UX, Majeur) ; UX-016 (UX, Mineur).
- **Description** : le sélecteur « Canal » de « Nouvelle discussion » n'a aucune option (« Généraux » et « Par pays » vides). Le canal est obligatoire, donc « Publier la discussion » reste désactivé, sans message. Les groupes vides et les actions réservées aux membres apparaissent aussi en invité.
- **Reproduction** : dev connecté → `/echange` → « Nouvelle discussion » → remplir titre, texte, étiquette bug, dépôt → le bouton reste grisé.
- **Preuve** : `qa/dev/16-echange.png`, `17-nouvelle-discussion.png`, `42-liste-canaux.webp`, `43-discussion-remplie.webp`, `44-discussion-publiee.webp` ; `ux/captures/connecte/nouvelle-discussion-desktop.png`, `nouvelle-discussion-390.png`, `ux/captures/echange-1440.png`. Débloqué uniquement après création manuelle du canal `audit-qa` (phase 5, accord d'Octave).
- **Impact** : le parcours bug → correctif → copie de test → acceptation, promesse centrale du produit, est impossible en prod tant qu'aucun canal n'existe.
- **Correctif** : canaux par défaut (Général, Bénin, Sénégal…) créés au déploiement, ou canal facultatif ; marquer les champs obligatoires et afficher « Il manque : un canal » ; mettre en avant le champ Dépôt si l'étiquette est « bug ».
- **Harmonisation** : « Bloquant » QA → Critique (fonction cœur), bien que le correctif soit trivial.

### 4.2 Haute

#### SOUK-003 — La copie de test déploie `main`, pas la branche du correctif
- **Sources** : QA-030 (QA, Majeur).
- **Description** : « Essayer sur une copie de test » démarre une copie de la branche principale de l'auteur, pas de la branche proposée.
- **Reproduction** : sur `/echange/1`, proposer `fix-tache-vide`, lancer la copie de test (`https://d4.souk-apps.duckdns.org`), ajouter une tâche vide → acceptée.
- **Preuve** : la page servie contient `const texte = champ.value;` (l.35) sans le contrôle `trim()` présent l.36 de la branche sur GitHub (comparaison curl) ; `qa/dev/58-copie-test.png`, `59-copie-test-resultat.png`.
- **Impact** : on accepte un correctif sans l'avoir vu tourner ; la fonction « essayer avant d'accepter » est trompeuse.
- **Correctif** : cloner le ref/commit de la proposition, afficher le commit déployé dans la copie.

#### SOUK-004 — Auto-proposition et auto-acceptation d'un correctif : réputation gonflable à volonté
- **Sources** : QA-031 (QA, Majeur).
- **Description** : un auteur peut proposer un correctif sur sa propre discussion puis l'accepter ; il gagne des XP.
- **Reproduction** : auteur de `/echange/1` → proposer un correctif → l'accepter.
- **Preuve** : Souk Score 65 → 205/1000 (100 → 250 XP) ; `qa/dev/57-proposer-correctif.png`, `60-correctif-accepte.png` ; même évolution relevée par UX sur `/tableau` (`ux/rapport-connecte-dev-v1.md`, « À transmettre »).
- **Impact** : classement `/devs` et Souk Score non fiables, donc l'argument de recrutement « trouver un dev par son score » aussi.
- **Correctif** : interdire l'auto-proposition ou ne donner aucun XP dans ce cas ; limite de débit ; recalcul des scores existants.

#### SOUK-005 — Textes légaux en brouillon, ni mentions légales ni contact
- **Sources** : PAY-02 (Paiement, Haute) ; QA-001 (QA, Majeur) ; UX-006 (UX, Majeur) ; UX-005 (UX, Majeur).
- **Description** : `/legal/cgu`, `/legal/cgv`, `/legal/confidentialite`, `/legal/abus` portent « Brouillon à faire valider par un juriste » / « n'a pas de valeur contractuelle ». Pas de page mentions légales (éditeur, RCCM/IFU, hébergeur), pas de Contact/Support ; `/legal/confidentialite` §5 renvoie à « l'équipe » sans adresse.
- **Reproduction** : pied de page → pages légales ; chercher Contact/À propos.
- **Preuve** : `qa/visiteur/16-legal-cgu.png` à `19-legal-abus.png` ; `ux/captures/cgu-360.png`, `cgv-360.png`, `cgu-1440.png`, `confidentialite-360.png`, `zooms/accueil-360-p2.png` ; code `frontend/src/features/legal/Legal.tsx`.
- **Impact** : abonnements mensuels vendus sans base contractuelle ; éditeur non identifiable ; litiges paiement/remboursement sans recours clair.
- **Correctif** : validation juridique, retrait du bandeau, version datée ; pages Mentions légales et Contact (e-mail, WhatsApp, délai) dans le pied de page et le menu mobile.

#### SOUK-006 — HTTP clair renvoie 500 (Pingora) au lieu de rediriger vers HTTPS
- **Sources** : SEC-006 (Sécurité, Élevée) ; PERF-06 (Perf, Moyenne) ; M-02 (recon passive, Moyenne).
- **Description** : le port 80 répond `HTTP/1.1 500`, `Server: Pingora`, corps vide, sans `Location`.
- **Reproduction** : `curl -sI http://soukdev.shop/` ; `curl -sI http://www.soukdev.shop/` (la recon passive cite aussi `http://api.soukdev.shop/`).
- **Preuve** : `securite.md` SEC-006 ; `RAPPORT-RECON-PASSIVE.md` M-02 ; `CARTE.md` §5.4. `https://www` → 301 vers l'apex (OK).
- **Impact** : tout lien ou favori en `http://` mène à une erreur ; empêche d'activer HSTS sereinement.
- **Correctif** : 301/308 systématique `http://` → `https://` sur l'edge pour apex, www et api ; alerte si 5xx sur :80.
- **Désaccord** : Sécurité classe Élevée, Perf et recon Moyenne → retenu Haute (visible par tout utilisateur, bloque HSTS).

#### SOUK-007 — Reversements Mobile Money inactifs en prod, messages contradictoires sur `/revenus`
- **Sources** : PAY-03 (Paiement, Haute) ; UX-026 (UX, Majeur).
- **Description** : en prod, tant que `REVERSEMENTS_REELS` ≠ true, la passerelle est `ReversementsInactifs`. `/revenus` affiche à la fois « Reversement automatique le 1er décembre 2026 » et « Les reversements… ouvrent bientôt », au-dessus d'un formulaire MTN/Moov/Celtiis actif ; le seuil de 5 000 F des CGV n'apparaît pas.
- **Reproduction** : code `AppServiceProvider::enregistrerPasserelles` ; dev connecté → `/revenus`.
- **Preuve** : `paiement.md` PAY-03 (docs/paiement.md l.103-104) ; `ux/captures/connecte/revenus-desktop.png`, `zooms/revenus-390-p0.png`, `revenus-390-p1.png`.
- **Impact** : promesse « vous encaissez en Mobile Money » non tenue au lancement ; doute sur l'argent des devs, risque de litige.
- **Correctif** : activer après liste blanche IP SasPay et test de reversement réel minimal, ou afficher un seul état clair avec date fiable, rythme et seuil.

#### SOUK-008 — `extra_hosts` / `dns` / `dns_search` acceptés sans filtre dans le compose auteur (Haute, confirmée par exécution locale, non observée en production)
- **Sources** : DEP-01 (Déploiement, Haute).
- **Description** : ces clés figurent dans `CLES_SERVICE` acceptées ; aucune vérification dédiée.
- **Reproduction locale (faite)** : `php /workspace/souk-deploiement/verif-locale/verif-dep.php` sur une copie du clone `624431c` (PHP 8.4.27), le 10/11 à 13:19 (heure de Paris).
- **Reproduction en production (non exécutée)** : publier un compose avec `extra_hosts: ["host.docker.internal:host-gateway"]` et `dns: [1.2.3.4]`, lancer une copie, tenter de joindre la passerelle hôte. PoC inoffensif proposé : dépôt `audit-extra-hosts`.
- **Preuve** : `backend/app/Moteur/VerificateurCompose.php:22-30` ; aucun test dans `VerificateurComposeTest.php`.
- **Preuve d'exécution** : `/workspace/souk-deploiement/verif-locale/sortie.txt` — `VerificateurCompose::verifier()` renvoie ACCEPTÉ pour `extra_hosts host.docker.internal:host-gateway`, `dns 10.0.0.1` (IP privée), `dns_search`, `links` et le dépôt `audit-extra-hosts` ; le témoin `privileged: true` est bien REFUSÉ (« Le service « web » est privileged. »), ce qui montre que le vérificateur filtre les autres clés dangereuses.
- **Statut** : **confirmé par exécution locale du code de la plateforme, non observé en production** (aucun dépôt public créé, rien déployé sur soukdev.shop).
- **Impact** : depuis une copie, accès facilité à la passerelle hôte (Traefik en `network_mode: host`) et résolution DNS hostile ; n'ouvre pas à lui seul le socket Docker ni les autres copies.
- **Correctif** : refuser `extra_hosts`, `dns`, `dns_search`, `links` (et `hostname`/`domainname` inutiles) + tests de régression + doc auteur.

#### SOUK-009 — Plafonds de formule appliqués par conteneur, pas par projet (jusqu'à 6×) (Haute, confirmée par exécution locale, non observée en production)
- **Sources** : DEP-02 (Déploiement, Haute).
- **Description** : chaque service reçoit la limite de la formule ; jusqu'à 6 services auteur, plus `soukdev-db` et `soukdev-api` en backend intégré.
- **Reproduction locale (faite)** : même script, `LimitesTaille::ecrire(..., 'petite')` sur un compose de 6 services (`web`, `repos1` à `repos5`).
- **Reproduction en production (non exécutée)** : compose de 6 services, formule Petite → ~3 Go / 3 CPU. PoC proposé : `audit-amp-limites`.
- **Preuve** : `backend/app/Moteur/LimitesTaille.php:7-11` et `:81-119` ; `VerificateurCompose::MAX_SERVICES = 6` (`:37`) ; `LanceurCompose.php:101-108`.
- **Preuve d'exécution** : `/workspace/souk-deploiement/verif-locale/sortie.txt` — chacun des 6 services reçoit `mem_limit=512m` et `cpus=0.5` ; « Total projet : 3072 Mo (3 Gi) et 3 CPU pour une formule Petite annoncée à 512 Mo / 0.5 CPU », facteur ×6.
- **Statut** : **confirmé par exécution locale du code de la plateforme, non observé en production.**
- **Impact** : une copie à 3 500 F peut saturer un nœud ; écart avec « Petite = 512 Mo ».
- **Correctif** : plafond projet (cgroup parent ou budget total), ou division de la formule par service ; afficher le plafond total.

#### SOUK-010 — Frais de paiement inconnus avant SasPay : « Payer 3 500 F » débite 3 623 F
- **Sources** : PAY-04 (Paiement, Moyenne) ; UX-004, UX-040, UX-051 (UX, Majeur).
- **Description** : la fiche, l'accueil et `/deployer` n'affichent aucun montant de frais ; le bouton dit « Payer 3 500 F ». Chez SasPay : 3 500 + 123 XOF = 3 623 XOF (Moov, MTN, Celtiis BJ). Les CGV (art. 1) annoncent pourtant que les frais s'ajoutent.
- **Reproduction** : `/store/1/deployer` → « Payer 3 500 F » (fait une fois par UX à 11:30 avec l'accord d'Octave, sans rien saisir).
- **Preuve** : `ux/captures/saspay/saspay-checkout-desktop.png`, `deployer-avant-clic.png`, `ux/captures/client/deployer-desktop-sombre.png`, `ux/captures/cgv-360.png` ; code `Commande.tsx:209,258`, `SasPayPaiement.php:20-29` (`amount: 3500.00`, `fee_charge_mode: ADD_ON`, aucun frais estimé). 123 F ≈ 3,5 % arrondi, différent de la grille publique SasPay (tarif réel du compte marchand non lu).
- **Impact** : prix perçu comme caché, abandons et réclamations ; contredit l'argument « transparent ».
- **Correctif** : lire `GET /pricing/my-rates/` (cache serveur) et afficher « 3 500 F + 123 F de frais = 3 623 F » avant le clic, ou renommer le bouton « Continuer vers le paiement » avec la fourchette ; préciser si les frais reviennent chaque mois.
- **Désaccord** : Paiement Moyenne, UX Majeur → retenu Haute (écart de prix au moment de payer).

#### SOUK-011 — Le client paie « to Gentube », pas Souk.dev
- **Sources** : PAY-13 (Paiement, Moyenne) ; UX-050 (UX, Majeur).
- **Description** : la page SasPay affiche le sous-titre « to Gentube ». Ce n'est pas un champ d'API (Souk envoie seulement `description` « Souk.dev — {appli} — facture {numero} ») : c'est le nom d'affichage du compte marchand dans le tableau de bord SasPay.
- **Reproduction** : même clic que SOUK-010.
- **Preuve** : `ux/captures/saspay/saspay-checkout-desktop.png` ; `SasPayPaiement.php:20-36`, `Encaissement.php:98-106` ; OpenAPI SasPay `POST /checkout-sessions/` sans champ marchand.
- **Impact** : suspicion de hameçonnage, abandon, litige.
- **Correctif** : renommer le marchand (et le logo) en « Souk.dev » dans le tableau de bord SasPay ; vérifier le KYC rattaché.
- **Désaccord** : Paiement Moyenne, UX Majeur → retenu Haute (confiance au paiement, correctif immédiat).

#### SOUK-012 — Lien magique classé spam, envoyé depuis un domaine sans rapport
- **Sources** : SEC-004 (Sécurité, Moyenne) ; QA-005 (QA, Majeur) ; `api.md` §8.3.
- **Description** : « Votre lien de connexion Souk.dev » arrive en spam, expéditeur `souk@send.excellenceteam.site` ; jeton dans l'URL (`/auth/lien-magique/<jeton>`, valable 15 min).
- **Reproduction** : `/connexion` → « Entreprise ou particulier » → saisir une adresse de test → observer le dossier spam.
- **Preuve** : boîtes de test des bots (QA le 10/11 à 01:34:58 heure de Paris ; Sécurité ; API pour `+audit-api` et `+audit-api-b`) ; `qa/client/03-lien-envoye.png`.
- **Impact** : les clients (seul mode de connexion Entreprise) ne trouvent pas le lien ; domaine non aligné = terrain favorable au phishing.
- **Correctif** : envoi depuis `soukdev.shop` (ou sous-domaine dédié) avec SPF/DKIM/DMARC alignés, tests de délivrabilité ; envisager une consommation POST du jeton.
- **Désaccord** : Sécurité Moyenne, QA Majeur → retenu Haute (connexion client compromise en pratique).

#### SOUK-013 — Appli à 61 failles (1 critique) en vitrine ; l'analyse Trivy ne bloque pas la publication
- **Sources** : UX-001 (UX, Majeur) ; QA-009 (QA, Info) ; `qa/client/rapport.md` point 5 (Majeur) ; SEC-013 / SEC-S04 (Sécurité, Moyenne).
- **Description** : `portfolio-open`, seule appli réelle, est mise en avant avec « Problèmes détectés » (61 dépendances vulnérables, dont 1 Critique). Côté code, gitleaks bloque bien les secrets (422, fail-closed 503), mais Trivy ne produit qu'un badge après publication : une appli à CVE HIGH/CRITICAL est publiable et déployable.
- **Reproduction** : `/`, `/store`, `/store/1` ; code `AppliController::sansSecret()` → `AnalyserSecrets` (bloquant) puis `AnalyserDependances` asynchrone.
- **Preuve** : `ux/captures/zooms/accueil-360-p1.png`, `store-360-p0.png`, `fiche-appli-360-p1.png` ; `qa/client/06-fiche.png` ; tests `SecuriteDepotTest`, `VerificationDepotTest`.
- **Impact** : le premier client conclut que le Store n'est pas sûr ; la promesse « chaque appli analysée avant publication » n'est vraie que pour les secrets.
- **Correctif** : ne pas mettre en vitrine une appli à failles hautes/critiques ; option de blocage du déploiement si `securite_statut !== verifie` ; clarifier le texte marketing ; résumé en langage simple côté client.
- **Désaccord** : QA Info, Sécurité Moyenne, UX Majeur → retenu Haute pour le lancement (vitrine).

#### SOUK-014 — La capture de l'appli en vitrine est une capture d'un navigateur personnel (données de l'auteur)
- **Sources** : UX-007 (UX, Majeur).
- **Description** : la première capture de `/store/1` (et sa vignette, réutilisée dans le récapitulatif de commande) montre les onglets personnels, une URL tierce contenant un paramètre e-mail (tronqué) et une page de commande d'un autre service.
- **Reproduction** : `/store/1`, `/store`, `/`.
- **Preuve** : `ux/captures/zooms/capture-appli-1-haut.png`, `zooms/fiche-appli-768-p0.png`, `zooms/store-360-p0.png` ; vignette aussi notée sur `audit-qa-souk-todo` (UX-045).
- **Impact** : fuite d'informations personnelles publique ; image amateur.
- **Correctif** : remplacer la capture immédiatement ; aperçu et avertissement « aucune donnée personnelle » à l'envoi, guide des captures.

#### SOUK-015 — Appli de test publique en tête du Store, et aucun moyen de dépublier une appli
- **Sources** : UX-045 (UX, Majeur) ; QA-029 (QA, Majeur).
- **Description** : `audit-qa-souk-todo` (« Ne pas déployer ») est publique et triée en premier sur `/store` ; ni l'auteur ni l'admin n'ont d'action Dépublier/Masquer (`/store/2/modifier` et `/store/2/edit` → 404, pas d'onglet Applis en modération).
- **Reproduction** : `/store` ; en auteur, chercher une action sur la fiche, `/tableau`, « Mes applis », `/admin/moderation`.
- **Preuve** : `ux/captures/client/zoom-store-360-sombre-cartes.png`, `store-360-clair.png`, `store-desktop-connecte.png` ; `qa/dev/50-gestion-appli.png`, `52-store-apres.png`.
- **Impact** : Store d'apparence amateur ; un client pourrait payer 3 500 F/mois pour une appli de test ; une appli cassée ou abusive ne peut pas être retirée sans passer par la base.
- **Correctif** : action Dépublier/Masquer pour l'auteur et modération admin des applis ; statut « non listée » pour les tests ; retrait de `/store/2` (voir section 7).

#### SOUK-016 — Pas de compression HTTP ; LCP mobile de 4,4 à 7,4 s
- **Sources** : PERF-01 (Perf, Critique) ; PERF-05 (Perf, Haute).
- **Description** : HTML/JS/CSS servis sans `Content-Encoding` ; Core Web Vitals de labo « Poor ».
- **Reproduction** : `curl -sI -H 'Accept-Encoding: br,gzip' https://soukdev.shop/assets/index-CLTRcOvM.js` → pas de `Content-Encoding`, `Content-Length: 260752`.
- **Preuve** : Lighthouse `uses-text-compression` = 0, 453-468 KiB économisables ; LCP Slow 4G : accueil 4,4 s, store 7,4 s, fiche 5,4 s, profil 7,2 s ; 3G/CPU×6 accueil 7,4 s (`raw-lighthouse/`, `lh-summary.json`).
- **Impact** : abandon probable sur réseaux mobiles d'Afrique de l'Ouest.
- **Correctif** : `encode zstd gzip` dans Caddy ; puis SOUK-048 et SOUK-049 ; LCP de la fiche à rendre plus tôt (prerender ou squelette → contenu).
- **Désaccord** : Perf classe PERF-01 Critique → retenu Haute (pas de risque d'argent ni de sécurité, correctif de configuration).

### 4.3 Moyenne

#### SOUK-017 — `robots.txt` et `sitemap.xml` servent la page HTML de la SPA
- **Sources** : SEO-01, SEO-02 (Perf, Critique) ; PAY-08 (Paiement, Basse) ; API-07 (API, Info) ; SEC-009 (Sécurité, Info/Faible) ; F-03 (recon, Faible, partie robots).
- **Reproduction** : `curl -sI https://soukdev.shop/robots.txt` et `/sitemap.xml` → `text/html`, 5 680 o.
- **Preuve** : Lighthouse `robots-txt` = 0 (« 55 errors ») ; `seo-static-meta.json`. L'API, elle, sert un vrai robots.
- **Impact** : crawl non piloté, fiches et profils non découverts.
- **Correctif** : fichiers statiques servis avant le fallback SPA (`handle /robots.txt`) ; sitemap XML généré (accueil, store, fiches, profils, légal).
- **Désaccord** : Critique pour Perf, Basse/Info pour Paiement, API et recon → retenu Moyenne (pas bloquant pour ouvrir, important pour l'acquisition).

#### SOUK-018 — Indexabilité : même titre et description partout, ni OG, ni canonical, ni JSON-LD, contenu absent du HTML
- **Sources** : SEO-03 (Perf, Critique) ; SEO-05 (Perf, Haute) ; SEO-06 (Perf, Moyenne) ; QA-022 (QA, Mineur).
- **Reproduction** : comparer le HTML brut de `/`, `/store`, `/store/1`, `/devs/octavebahoun`.
- **Preuve** : `seo-static-meta.json`, `seo-rendered-meta.json` ; aucun `og:*`, `twitter:*`, `canonical`, `ld+json`, même après hydratation.
- **Impact** : partages sociaux génériques, indexation pauvre.
- **Correctif** : prerender/SSR des pages publiques ou injection de meta par route côté serveur ; OG image ; JSON-LD `SoftwareApplication`/`Person`/`Organization`.
- **Désaccord** : Perf Critique → retenu Moyenne.

#### SOUK-019 — Soft-404 : URL inexistantes, `/admin`, `/.git/HEAD`, `/.env` répondent 200
- **Sources** : SEO-04 (Perf, Haute) ; SEC-009 (Sécurité, Info) ; recon F-03 / tableau « Fichiers sensibles ».
- **Reproduction** : `curl -sI https://soukdev.shop/cette-page-nexiste-pas-xyz-999`, `/admin`, `/store/999999`, `/.env` → 200 + shell SPA (pas de contenu sensible).
- **Impact** : indexation d'URL fantômes ; confusion de scanners ; l'auth doit rester strictement côté API (c'est le cas, voir section 5).
- **Correctif** : 404 à l'edge pour les routes inconnues et `/.git`, `/.env` ; `noindex` sur la 404 client en attendant.

#### SOUK-020 — HSTS absent sur front, API et Reverb
- **Sources** : SEC-005 (Sécurité, Moyenne) ; M-01 (recon, Moyenne).
- **Reproduction** : `curl -sI https://soukdev.shop/ | grep -i strict-transport` (idem `api.`, `reverb.`) → rien.
- **Impact** : pas de HTTPS « collant » ; aggravé par SOUK-006.
- **Correctif** : `Strict-Transport-Security: max-age=31536000; includeSubDomains; preload` après correction de SOUK-006.

#### SOUK-021 — CSP du front trop permissive (`frame-src https:`, `style-src 'unsafe-inline'`)
- **Sources** : SEC-007 (Sécurité, Moyenne) ; F-02 (recon, Faible).
- **Reproduction** : `curl -sI https://soukdev.shop/` → CSP.
- **Preuve** : `headers-front.txt` ; `script-src 'self'` + 2 hashes (bon).
- **Impact** : n'importe quel site HTTPS peut être embarqué en iframe ; styles inline exploitables en cas d'injection HTML.
- **Correctif** : liste blanche `frame-src` (domaines nécessaires) ; nonces/hashes pour les styles.
- **Désaccord** : Sécurité Moyenne, recon Faible → retenu Moyenne.

#### SOUK-022 — Cookies de session `Domain=.soukdev.shop` partagés avec tous les sous-domaines
- **Sources** : SEC-010 (Sécurité, Moyenne) ; M-03 (recon, Moyenne).
- **Reproduction** : `curl -sI https://api.soukdev.shop/sanctum/csrf-cookie` (valeurs non reproduites).
- **Preuve** : `laravel-session` Secure/HttpOnly/Lax et `XSRF-TOKEN` Secure/Lax, `Domain=.soukdev.shop`, Max-Age 7200.
- **Impact** : un XSS ou un contenu hostile sur n'importe quel `*.soukdev.shop` peut utiliser la session. Les copies sont aujourd'hui sur un domaine distinct (`souk-apps.duckdns.org`), ce qui limite le risque (voir aussi SOUK-037).
- **Correctif** : garder les copies hors de `soukdev.shop` ; aucun contenu utilisateur sous l'apex ; cookies host-only (`__Host-`) si le modèle le permet.

#### SOUK-023 — Route de connexion démo `POST /auth/demo` encore enregistrée en prod (garde active)
- **Sources** : SEC-011 (Sécurité, Moyenne) ; API-01 (API, Moyenne) ; SEC-S03 (Sécurité, Moyenne).
- **Reproduction** : `GET /auth/demo` → 405 `Allow: POST` ; `POST /auth/demo` avec CSRF et `{"compte":"soukdemo-awa"}` → 404 ; `/api/me` reste 401 (Sécurité ; API n'a fait aucun POST).
- **Preuve** : `routes/web.php` enregistre la route (throttle 60/min) ; garde `abort_unless(demo_connexion && !isProduction(), 404)` ; usernames démo publics dans `ComptesDemo.tsx`.
- **Impact** : pas de contournement constaté ; surface résiduelle et risque si la garde régresse ou sur une préprod exposée avec `DEMO_CONNEXION=true` et `APP_ENV ≠ production`.
- **Correctif** : n'enregistrer la route qu'en `local`/`testing` ; 404 uniforme ; alerte CI si elle apparaît en build prod.

#### SOUK-024 — Clé Reverb du front = littéral « Secrets déjà présents. » (temps réel probablement cassé)
- **Sources** : SEC-014 / SEC-S05 (Sécurité, Moyenne) ; I-02 (recon, Info).
- **Reproduction** : télécharger `https://soukdev.shop/assets/index-*.js`, chercher la config Echo.
- **Preuve** : `key: "Secrets déjà présents."` = sortie de `backend/docker/secrets.sh` capturée au build ; ce n'est pas un secret privé.
- **Impact** : notifications temps réel probablement inopérantes ; processus de build fragile.
- **Correctif** : rebuild avec la vraie `VITE_REVERB_KEY` de `public.env` ; contrôle de format au build (regex hex 32).

#### SOUK-025 — Oracle d'existence sur `GET /api/deployments/{id}` (403 vs 404)
- **Sources** : API-08 (API, Moyenne).
- **Reproduction** : session client → `/api/deployments/1` → 403 ; `/3`, `/10`, `/999` → 404 ; confirmé depuis le compte B.
- **Impact** : énumération des ids de copies existants (aucune donnée lue).
- **Correctif** : 404 uniforme quand l'appelant n'est pas propriétaire, comme pour factures et missions.

#### SOUK-026 — Page de paiement SasPay en anglais par défaut
- **Sources** : PAY-14 (Paiement, Moyenne) ; UX-052 (UX, Majeur).
- **Preuve** : `ux/captures/saspay/saspay-checkout-desktop.png` (Country, Payment method, Total due ; bascule FR | EN, EN actif) ; `creerSession` n'envoie ni `locale` ni `language`.
- **Impact** : public francophone non technique face à un écran en anglais au moment de payer.
- **Correctif** : demander à SasPay un paramètre de langue ; d'ici là, indiquer sur `/deployer` que la page propose le français.
- **Contradiction** : UX conseille « passer `locale=fr` » ; Paiement établit que l'API SasPay ne propose pas ce paramètre (0 occurrence dans l'OpenAPI SasPay). C'est l'analyse Paiement qui est retenue.

#### SOUK-027 — Aucune relance pour une première facture impayée avant l'annulation à J+7
- **Sources** : PAY-15 (Paiement, Moyenne).
- **Preuve** : `Facturation::commander` (`Facturation.php:26-59`) émet la 1re facture sans notification ; `relancer` (`CycleFacturation.php:93-128`) exige un abonnement `actif`/`en_retard` (`Abonnement.php:20`) ; seul e-mail : `CopieResiliee` à l'annulation (`CycleFacturation.php:273`). Observé sur SD-2026-000003 : aucune notification (`paiement-captures/04-notifications.png`).
- **Impact** : le client parti de SasPay n'est jamais relancé ; ventes perdues.
- **Atténuation constatée (UX, 12:56)** : `/store/1/deployer` affiche désormais « Une commande attend déjà votre paiement… Sans paiement, elle s'annule d'elle-même au bout de 7 jours » (`ux/captures/clair/deployer-clair.png`). Le client revenu sur la page est donc informé ; aucun e-mail ni notification n'est envoyé pour autant.
- **Correctif** : envoyer « paiement en attente » à la commande et/ou une relance à J+3 même en `en_attente`.

#### SOUK-028 — Ni acceptation des CGV ni lien d'annulation dans le tunnel de paiement
- **Sources** : UX-041 (UX, Majeur) ; PAY-16 (Paiement, Basse) ; UX-053 (UX, Mineur).
- **Description** : aucune case ni mention « En payant, vous acceptez… » sur `/deployer` ; chez SasPay, pas de bouton Annuler, pas de retour vers Souk, pas de CGV ni de remboursement ; `return_url` ne sert qu'après un succès.
- **Preuve** : `ux/captures/client/deployer-desktop-sombre.png`, `ux/captures/saspay/saspay-checkout-desktop.png` ; OpenAPI SasPay sans `cancel_url` ; `Encaissement.php:103`.
- **Impact** : aucune preuve d'acceptation en cas de litige ; client bloqué s'il abandonne.
- **Atténuation constatée (UX, 12:56)** : pour une commande en attente, `/store/1/deployer` propose un lien « Annuler cette commande » (non cliqué) (`ux/captures/clair/deployer-clair.png`). Il n'existe toujours ni acceptation des CGV ni retour depuis la page SasPay.
- **Correctif** : mention/case CGV avec version enregistrée sur la commande ; lien « Annuler et revenir » côté Souk avant la redirection ; « fermez l'onglet pour abandonner ».
- **Désaccord / contradiction** : UX Majeur/Mineur, Paiement Basse → retenu Moyenne. UX propose de « renseigner l'URL d'annulation » ; Paiement indique que l'API SasPay n'en a pas.

#### SOUK-029 — Le sort des données en cas d'impayé ou d'arrêt n'est pas dit à la commande
- **Sources** : UX-042 (UX, Majeur).
- **Preuve** : `ux/captures/client/deployer-desktop-sombre.png` (« Vos données gardées tant que l'abonnement est réglé ») ; `ux/captures/connecte/copies-390.png` (« Arrêtée. Ses données ont été supprimées. ») ; CGV §3 (suppression à 30 jours).
- **Impact** : perte de données non anticipée par un client non technique.
- **Correctif** : ligne explicite (7 jours de grâce, suspension, suppression ; arrêter supprime les données), lien export, confirmation forte avant l'arrêt.

#### SOUK-030 — « Gratuit » affiché en titre alors que le client paie 3 500 F/mois
- **Sources** : UX-003 (UX, Majeur).
- **Preuve** : `ux/captures/zooms/fiche-appli-360-p0.png`, `fiche-appli-768-p0.png`, `store-360-p0.png`.
- **Impact** : découverte de l'abonnement au moment de commander.
- **Correctif** : titre = total mensuel, « Appli gratuite + hébergement » en sous-titre ; filtres et tri de prix sur le total.

#### SOUK-031 — Formule d'hébergement imposée par l'auteur, pas choisie par le client
- **Sources** : PAY-06 (Paiement, Moyenne) ; QA-006 (QA, Majeur à confirmer) ; UX-044 (UX, Mineur).
- **Preuve** : `DeploiementController::taille` et `Facturation::commander` lisent `$appli->taille` ; `Commande.tsx` sans sélecteur ; `qa/client/07-deployer-avant-paiement.png`, `ux/captures/client/deployer-desktop-sombre.png`.
- **Impact** : écart avec « choisir sa formule » (CARTE, CGV, `/publier`).
- **Correctif** : clarifier le texte, ou proposer un choix validé côté serveur.
- **Note** : le « à confirmer » de QA-006 est levé par la lecture du code (PAY-06).

#### SOUK-032 — « 0 % de commission » à préciser
- **Sources** : PAY-07 (Paiement, Moyenne).
- **Preuve** : accueil « 0 % de commission » ; `GrandLivre::encaisser` (part appli → dev intégrale, hébergement → revenu Souk).
- **Impact** : promesse vraie sur le prix de l'appli mais pas sur le total payé.
- **Correctif** : « 0 % sur le prix de l'appli ».

#### SOUK-033 — Tarifs en double : `formules.ts` (front) et `config/facturation.php` (serveur)
- **Sources** : PAY-05 (Paiement, Moyenne).
- **Impact** : l'affichage peut diverger de la facture (qui reste exacte).
- **Correctif** : source unique (endpoint public ou génération) + test de non-régression.

#### SOUK-034 — Aucune alerte si le scheduler ou le worker `paiements` s'arrête
- **Sources** : DEP-12 (Déploiement, Moyenne) ; `paiement.md` « Scheduler en prod (risque résiduel) ».
- **Preuve** : `docker-compose.prod.yml:224-232` (`scheduler`) et `:132-134` (`worker`), `restart: unless-stopped` ; `/up` ne couvre que l'API web.
- **Impact** : un arrêt silencieux bloque l'expiration des factures impayées (SD-2026-000003 resterait `a_payer`), les relances et renouvellements.
- **Correctif** : heartbeat du planificateur et âge du plus ancien job `paiements` exposés à une sonde/alerte.

#### SOUK-035 — Erreurs de build opaques pour l'auteur
- **Sources** : DEP-03 (Déploiement, Moyenne).
- **Preuve** : `LanceurCompose::echouerSiComposeRate` (`:372-385`) jette un message générique sans la sortie.
- **Correctif** : journaliser côté serveur, extrait redacté pour l'auteur, message générique pour le client.

#### SOUK-036 — Conteneurs générés exécutés en root
- **Sources** : DEP-04 (Déploiement, Moyenne).
- **Preuve** : Dockerfiles de `EcrivainDocker.php` sans `USER` ; mitigé par `cap_drop: ALL` + `no-new-privileges`.
- **Correctif** : `USER` non-root quand la pile le permet.

#### SOUK-037 — Contrôle `IsolementCopies` non exécuté dans les workers console
- **Sources** : DEP-05 (Déploiement, Moyenne).
- **Preuve** : `AppServiceProvider.php:122-134` (garde seulement si `!runningInConsole()`).
- **Impact** : une mauvaise config (copies sous le domaine des cookies) ne serait pas bloquée par le moteur → vol de session possible (lien SOUK-022).
- **Correctif** : même contrôle, fail-closed, au boot des workers et dans `LancerDeploiement`.

#### SOUK-038 — Socket Docker monté sur 4 services plateforme
- **Sources** : DEP-06 (Déploiement, Moyenne).
- **Preuve** : `docker-compose.prod.yml` l.149, 164, 180, 196 (`moteur`, `sondes`, `analyse`, `analyse-secrets`).
- **Impact** : une RCE dans l'un d'eux = contrôle du démon Docker hôte.
- **Correctif** : réduire au `moteur`, proxy d'API Docker filtrée, Docker rootless.

#### SOUK-039 — DinD `privileged: true` (profil `machines`)
- **Sources** : DEP-07 (Déploiement, Moyenne).
- **Preuve** : `docker-compose.yml:279-289`.
- **Correctif** : réservé au labo, jamais sur le VPS de prod.

#### SOUK-040 — Prix négatif accepté à la publication (-100 → 100 F)
- **Sources** : QA-023 (QA, Majeur).
- **Reproduction** : `/publier` → prix `-100` → 100 F affiché sans erreur ; `abc` → champ vide sans message.
- **Preuve** : `qa/dev/34-publier-prix-invalide.png`. Validation serveur non vérifiée.
- **Correctif** : refuser négatif/non numérique avec message ; valider aussi côté API.
- **Harmonisation** : Majeur → Moyenne (pas de perte d'argent démontrée).

#### SOUK-041 — Formulaire `/publier` difficile pour un débutant (prérequis, récap, simulation de prix)
- **Sources** : UX-022, UX-024, UX-025 (UX, Majeur) ; QA-027 (QA, Mineur) ; QA-026 (QA, Cosmétique).
- **Description** : URL de dépôt à taper, pas de lien vers la doc `soukdev.json`, « Souk.dev les écrit pour vous » ambigu ; récap sous le bouton sur mobile ; placeholder « 15 000 » pris pour une valeur ; aucune simulation du prix client ni de la part nette du dev ; message « Dépôt valide » sans port ni fichiers confirmés.
- **Preuve** : `ux/captures/connecte/zooms/publier-360-p0.png`, `publier-360-p1.png`, `publier-360-p2.png`, `publier-desktop-p1.png` ; `qa/dev/32-publier-depot-verifie.png`, `35-publier-prix-15000.png`.
- **Correctif** : sélecteur de dépôts publics, guide `soukdev.json`, récap au-dessus du bouton, erreurs en ligne, simulateur « le client paie / vous recevez ».

#### SOUK-042 — « Mes applis » ouvre le formulaire de publication ; pas de liste ni de gestion des applis
- **Sources** : UX-023 (UX, Majeur) ; QA-013 (QA, Mineur) ; API-12 (API, Faible).
- **Preuve** : `ux/captures/connecte/publier-desktop.png`, `menu-compte-desktop.png` ; `qa/dev/13-apps.png`, `14-apps-verification.png`, `15-soukdev-json.png` (404) ; aucun appel de liste côté réseau.
- **Correctif** : page `/apps` listant les applis (statut, badge, actions), « Mes applis » pointe dessus (lien SOUK-015).

#### SOUK-043 — Parcours « Publier » en invité : mur sans explication, CTA et recherche absents du menu mobile
- **Sources** : UX-008, UX-009 (UX, Majeur).
- **Preuve** : `ux/captures/publier-360.png`, `menu-ouvert-360.png`, `menu-ouvert-390-sombre.png`, `zooms/accueil-768-sombre-p0.png`.
- **Correctif** : `/publier` lisible sans compte (étapes, prérequis, règles d'analyse) ; CTA et recherche dans le menu mobile et à 768 px.

#### SOUK-044 — Navigation du compte sur mobile : onglets coupés, menu avatar incomplet
- **Sources** : UX-028 (UX, Majeur) ; UX-027, UX-029 (UX, Mineur).
- **Preuve** : `ux/captures/connecte/profil-390.png`, `tableau-360.png`, `copies-390.png`, `menu-compte-390.png`, `copies-desktop.png`, `notifications-desktop.png`.
- **Correctif** : sélecteur « Mon espace » ou page grille ; menu avatar aligné sur la barre latérale (Revenus, Réglages) ; barres de défilement masquées.

#### SOUK-045 — L'acheteur invité perd sa commande à la connexion
- **Sources** : UX-047 (UX, Majeur) ; UX-011 (UX, Mineur).
- **Description** : « Se connecter » depuis le mur de `/store/1/deployer` mène à `/connexion` sans paramètre de retour, onglet « Développeur » présélectionné ; le mur ne rappelle ni l'appli ni le prix.
- **Preuve** : `ux/captures/client/invite-clic-deployer-390.png`, `invite-gate-vers-connexion-390.png`, `deployer-390-clair-ecran1.png`, `ux/captures/deployer-360.png`.
- **Correctif** : `?retour=…&profil=entreprise`, retour encodé dans le lien magique, formulaire e-mail directement sur le mur.

#### SOUK-046 — Place de marché vide mise en avant
- **Sources** : UX-012 (UX, Majeur).
- **Preuve** : `ux/captures/zooms/accueil-360-p1.png`, `zooms/devs-360-p0.png`, `echange-360.png`, `evenements-360.png`.
- **Correctif** : masquer les sections vides sous un seuil, amorcer du contenu propre (applis de démo, discussions de bienvenue).

#### SOUK-047 — Le tableau de bord d'un client affiche des métriques d'auteur
- **Sources** : QA-008 (QA, Majeur).
- **Preuve** : `qa/client/15-tableau.png` (vues, applis publiées, encaissé, CTA « Publier une appli »).
- **Correctif** : tableau selon le profil.
- **Harmonisation** : Majeur → Moyenne.

#### SOUK-048 — Captures PNG lourdes et sans cache HTTP
- **Sources** : PERF-02, PERF-03 (Perf, Haute).
- **Reproduction** : `curl -sI https://api.soukdev.shop/storage/captures/1/1.png` → pas de `Cache-Control`.
- **Preuve** : ~590 KiB d'images sur `/store/1`, ~464 KiB économisables en WebP/AVIF ; `cacheLifetimeMs: 0`.
- **Correctif** : variantes WebP/AVIF + `srcset` ; `Cache-Control: public, max-age=604800`.
- **Harmonisation** : Haute → Moyenne (couvert en partie par SOUK-016).

#### SOUK-049 — ~270 KiB de JavaScript inutilisé
- **Sources** : PERF-04 (Perf, Haute).
- **Preuve** : `unused-javascript` : `index-CLTRcOvM.js` ~120 KiB, `titre-CpeQ2xLE.js` ~85 KiB, `fonctionsAnimation-*.js` ~43 KiB.
- **Correctif** : code-splitting, chargement différé des animations.

#### SOUK-050 — Bloc de code `git clone` non focusable au clavier
- **Sources** : A11Y-01 (Perf, Haute — axe « serious »).
- **Preuve** : axe `scrollable-region-focusable` sur `pre.overflow-x-auto` (`/store/1`, `axe-results.json`).
- **Correctif** : `tabIndex={0}` et nom accessible.
- **Harmonisation** : Haute → Moyenne (élément isolé).

#### SOUK-051 — Petits textes et contrastes à vérifier (mobile, thèmes sombre et clair)
- **Sources** : A11Y-03 (Perf, Moyenne) ; UX-014, UX-039 (UX, Mineur) ; UX-062 (UX, Cosmétique : bordures fines et textes d'aide pâles en thème clair, `ux/captures/clair/`).
- **Preuve** : axe `color-contrast` incomplet (6 nœuds accueil, 4 store) ; 11-13 px très courants à 360 px (`ux/mesures.json`) ; aides de `/publier` peu contrastées (`ux/captures/connecte/zooms/publier-desktop-p0.png`).
- **Correctif** : 14 px minimum pour l'informatif, contraste AA vérifié à la pipette.

#### SOUK-052 — Fiche appli de 14 429 px sur mobile (61 failles dépliées)
- **Sources** : UX-002 (UX, Majeur).
- **Preuve** : `ux/captures/fiche-appli-360.png`, `zooms/fiche-appli-360-fin.png`.
- **Correctif** : résumé + accordéon fermé, regroupement par paquet, section après les avis.

#### SOUK-053 — Contrat OpenAPI incomplet ou faux pour certaines routes
- **Sources** : API-02 (API, Moyenne) ; API-11 (API, Faible).
- **Preuve** : `servers: /api` alors que `/sanctum`, `/auth/*`, `/logout`, `/broadcasting/auth` sont à la racine (`/api/sanctum/csrf-cookie` → 404, `/sanctum/csrf-cookie` → 204) ; `GET /api/me/deployments`, `GET /api/me/missions` appelés par le front, absents d'`openapi.yaml`.
- **Correctif** : deux serveurs dans le contrat, documenter les routes `/me/*`.

#### SOUK-054 — Validation incohérente des paramètres et des corps
- **Sources** : API-03 (API, Moyenne) ; API-04 (API, Basse à moyenne) ; API-10 (API, Basse).
- **Preuve** : `/api/apps?page=0` et `/api/missions?page=-1` → 200 (coercition) vs `/api/devs?page=0` → 422 ; `securite=ok` → 200 ; `PATCH /api/me` ignore les champs inconnus.
- **Correctif** : règles communes (`page|integer|min:1`, booléens stricts, 422 sur champs inconnus ou doc explicite).

#### SOUK-072 — Moyens de paiement annoncés sur `/deployer` différents de ceux réellement proposés par SasPay
- **Sources** : UX-057 (UX, Majeur) ; UX-054, UX-055 (UX, Mineur) ; UX-040 (partie « logos décoratifs »).
- **Description** : sous le bouton Payer, `/store/1/deployer` affiche MTN MoMo, Moov, Orange Money, Wave, Celtiis et la carte. La page SasPay ne propose que Moov Money Bénin (présélectionné), Celtiis Cash Bénin et MTN MoMo Bénin ; la carte y est affichée mais désactivée (« Contact us to enable this payment method ») et une option crypto est facturée en USD.
- **Reproduction** : connecté, `/store/1/deployer` (logos), puis la page SasPay ouverte le 10/11 à 11:30 sans rien saisir.
- **Preuve** : `ux/captures/clair/deployer-clair.png`, `ux/captures/client/deployer-desktop-sombre.png`, `ux/captures/saspay/saspay-checkout-desktop.png`.
- **Impact** : un client attiré par Orange Money, Wave ou la carte ne peut pas payer avec, et le découvre chez SasPay ; abandon et perte de confiance au moment de payer.
- **Correctif** : n'afficher que les moyens actifs pour le pays du client, synchronisés avec le compte marchand SasPay (ou `GET /api/reseaux-mobile-money` filtré) ; dans le tableau de bord SasPay, masquer les moyens non activés et la crypto ; pas de présélection d'opérateur.
- **Harmonisation** : UX-057 Majeur → Moyenne (pas de débit erroné ; parcours bloqué pour une partie des clients). Ce constat remplace l'ancienne fiche SOUK-072 (Basse), dont il reprend UX-054 et UX-055.

### 4.4 Basse

#### SOUK-055 — Routes front mortes (`/factures`, `/logout`, `/trouver-un-dev`, `/apps*`)
- **Sources** : QA-007 (QA, Majeur) ; QA-011 (QA, Faible) ; QA-014 (QA, Mineur) ; QA-013 (partie routes).
- **Reproduction** : ouvrir directement ces URL → « Cette page n'existe pas ». `/factures` est référencée dans le bundle ; la vraie page est `/paiements`.
- **Preuve** : `qa/client/10-factures-404.png`, `qa/dev/00-logout-route-404.png`, `qa/dev/24-trouver-un-dev.png`.
- **Impact** : lien mort si un e-mail ou un menu y renvoie. La déconnexion du menu fonctionne.
- **Correctif** : redirections (`/factures` → `/paiements`, `/trouver-un-dev` → `/devs`, `/logout` → action de déconnexion).
- **Harmonisation** : QA-007 Majeur → Basse (aucun lien interne cassé constaté).

#### SOUK-056 — Interface admin chargée pour un non-admin (l'API refuse bien)
- **Sources** : SEC-012 (Sécurité, Faible) ; SEC-016 (formulaire « Ajouter un serveur » rendu après 403) ; QA-015 (QA, Majeur à confirmer).
- **Reproduction** : compte client B → `/admin/finances`, `/admin/moderation` → l'UI se charge, l'API répond 403.
- **Preuve** : `securite.md` SEC-012/016 ; `qa/dev/10-menu-compte.png`.
- **Impact** : fuite de structure de l'admin, aucune donnée exposée.
- **Correctif** : garde de route front sur `est_admin`, ne pas charger les chunks admin, masquer le formulaire après 403.
- **Note** : QA-015 est levé : le compte qui voyait les liens Finances/Serveurs/Modération est l'admin réel (SEC-018).

#### SOUK-057 — Lien de démo non contrôlé (HTTP accepté, n'importe quelle URL)
- **Sources** : QA-024, QA-025 (QA, Mineur).
- **Preuve** : `qa/dev/33-publier-demo-http.png`, `39-fiche-appli-test.png`.
- **Correctif** : n'accepter que HTTPS et vérifier que l'URL répond.

#### SOUK-058 — Réputation incohérente après acceptation ; absente de `/profil`
- **Sources** : QA-032, QA-016 (QA, Mineur).
- **Preuve** : `qa/dev/60-correctif-accepte.png` (« 0 bug résolu », badge non obtenu malgré « 1 correctif accepté ») ; `qa/dev/22-profil.png`, `23-devs-public.png`.
- **Correctif** : recalcul des compteurs/badges à l'acceptation ; Souk Score visible sur `/profil`.

#### SOUK-059 — Notifications absentes pour l'Échange ; e-mail seul canal, sans retour d'enregistrement
- **Sources** : QA-033 (QA, Mineur) ; UX-038 (UX, Mineur).
- **Preuve** : `qa/dev/62-notifications.png` ; `ux/captures/connecte/notifications-reglages-desktop.png`.
- **Note** : QA-033 est peut-être lié à l'auto-proposition ; à revérifier avec deux comptes dev.
- **Correctif** : notifications à la proposition/acceptation ; toast d'enregistrement ; à terme push/WhatsApp.

#### SOUK-060 — Création de canal public par tout dev, sans modération
- **Sources** : QA-034 (QA, Cosmétique).
- **Preuve** : `qa/dev/53-creer-canal.png`, `54-canal-cree.png`.
- **Correctif** : validation admin ou limite de création.

#### SOUK-061 — Listes de pays différentes selon l'écran
- **Sources** : QA-018 (QA, Mineur).
- **Preuve** : 17 pays sur `/profil`, 7 sur `/revenus`, 5 sur `/devs` (`qa/dev/20-revenus.png`, `22-profil.png`, `24-trouver-un-dev.png`).
- **Correctif** : référentiel unique.

#### SOUK-062 — Images plateforme à tags flottants
- **Sources** : DEP-08 (Déploiement, Basse).
- **Preuve** : `postgres:16-alpine` (`docker-compose.prod.yml:85`), `node:24-alpine`.
- **Correctif** : épingler version patch ou digest.

#### SOUK-063 — Noms de copie prévisibles `d{id}`
- **Sources** : DEP-09 (Déploiement, Basse).
- **Preuve** : `LancerDeploiement.php:63` ; ex. `d4.souk-apps.duckdns.org`.
- **Correctif** : suffixe aléatoire (`MoteurDeploiement::nouveauId`).

#### SOUK-064 — Divulgation de la stack (`Server`, page `/up` Laravel)
- **Sources** : SEC-003 (Sécurité, Info) ; F-01 (recon, Faible) ; I-04 (recon, Info).
- **Reproduction** : `curl -sI https://api.soukdev.shop/` (`Server: FrankenPHP Caddy`) ; `https://api.soukdev.shop/up` sans `Accept` → page HTML Laravel.
- **Correctif** : `Server` générique ; `/up` en JSON minimal ou réseau interne.

#### SOUK-065 — Pas de `security.txt`
- **Sources** : F-03 (recon, Faible).
- **Preuve** : `/.well-known/security.txt` → 404 (API) / SPA (front).
- **Correctif** : publier un `security.txt` (contact, politique).

#### SOUK-066 — Messages 405 en anglais listant les méthodes
- **Sources** : API-05 (API, Basse).
- **Reproduction** : `GET /auth/demo`, `GET /logout`.
- **Correctif** : gestionnaire d'erreurs JSON unifié en français, message générique.

#### SOUK-067 — `GET /api/me/coordonnees-reversement` renvoie `{}` au lieu de `null`
- **Sources** : API-09 (API, Basse).
- **Correctif** : sérialiser `null` ou documenter l'objet vide.

#### SOUK-068 — Erreur OAuth `github_deja_lie` affichée comme erreur générique
- **Sources** : API-13 (API, Faible).
- **Preuve** : redirection `/connexion?erreur=github_deja_lie` → « Réessayez dans un instant ».
- **Correctif** : message dédié.

#### SOUK-069 — 401 sur `/api/me` dans la console à chaque page anonyme
- **Sources** : PERF-07 (Perf, Basse) ; UX rapport public (mesures « Console »).
- **Correctif** : ne pas traiter cette réponse attendue comme une erreur, ou endpoint de session optionnelle.

#### SOUK-070 — Cibles tactiles < 44 px ; barre basse qui masque du contenu
- **Sources** : UX-013, UX-033 (à confirmer), UX-048 (UX, Mineur).
- **Preuve** : `ux/mesures.json`, `ux/mesures-client.json` ; `ux/captures/connecte/copies-360.png` ; `ux/captures/client/fiche-1-360-clair-ecran1.png` (CTA « Déployer ma copie » à moitié sous la barre à 360×800).
- **Correctif** : `min-height: 44px`, `padding-bottom` = hauteur de barre + safe-area, barre d'action collante sur la fiche.

#### SOUK-071 — Captures et avatars en `alt=""`
- **Sources** : A11Y-02 (Perf, Moyenne).
- **Correctif** : `alt` descriptif pour les captures d'applis.
- **Harmonisation** : Moyenne → Basse.

#### SOUK-073 — Espace compte : copies indistinctes, « Commander à nouveau » ambigu, tableau de bord peu expliqué, détails de `/revenus`
- **Sources** : UX-030, UX-032 (UX, Mineur) ; UX-036, UX-037 (UX, Cosmétique) ; UX-059, UX-061 (UX, Mineur).
- **Description** : cartes de copies arrêtées identiques, sans date ni motif ; « Commander à nouveau » ne dit pas qu'il crée une nouvelle commande payante ; sur `/tableau`, « Souk Score 205/1000 » et l'XP ne sont pas expliqués, « 3 déploiements » côtoie « 0 copie active », une carte a un contour plus marqué sans raison ; profil sans incitation ; CTA et `select` de `/revenus`.
- **Preuve** : `ux/captures/connecte/copies-390.png`, `profil-390.png`, `revenus-desktop.png` ; `ux/captures/clair/copies-clair.png`, `tableau-clair.png`.
- **Impact** : risque de commande et de facture créées par erreur ; indicateurs difficiles à interpréter.
- **Correctif** : date et motif d'arrêt ; « Recommander (nouvelle copie, 3 500 F/mois) » ou confirmation ; info-bulle « Comment c'est calculé », distinguer déploiements tentés et copies actives ; jauge de complétude du profil ; CTA contextuel ; correction du `select`.

#### SOUK-074 — Commande : étapes « à venir » ambiguës, cas d'échec absent, pas d'identité de facturation
- **Sources** : UX-043, UX-049, UX-058 (UX, Mineur).
- **Description** : « Comment ça se passe » présente le paiement SasPay comme une étape « à venir » alors que le bouton Payer est actif et qu'une commande attend déjà ; rien sur l'échec de construction ; aucun champ de facturation.
- **Preuve** : `ux/captures/client/deployer-desktop-sombre.png`, `ux/captures/clair/deployer-clair.png`.
- **Note** : UX-043 supposait la mention « à venir » réservée aux lecteurs d'écran ; UX-058 la décrit comme visible en thème clair.
- **Correctif** : stepper explicite, « si la mise en ligne échoue… », bloc « Facturer à » et adresse prévue de la copie.

#### SOUK-075 — Jargon et promesse orientés dev sur le parcours client
- **Sources** : UX-010 (UX, Majeur) ; UX-015, UX-017, UX-018 (UX, Mineur).
- **Preuve** : `ux/captures/zooms/fiche-appli-360-p0.png`, `zooms/accueil-360-p0.png`, `zooms/devs-360-p0.png`, `copies-360.png`.
- **Correctif** : vocabulaire client (« votre version privée », « Obtenir cette appli »), phrase de valeur pour les entreprises, murs « Accès réservé » contextualisés, bouton secondaire sur les devs « Pas disponible ».
- **Harmonisation** : UX-010 Majeur → Basse (rédactionnel).

#### SOUK-076 — `/publier` sur mobile : marges asymétriques (360 px) et en-tête « invité » (390 px)
- **Sources** : UX-034 (à confirmer), UX-035 (UX, Mineur).
- **Preuve** : `ux/captures/connecte/zooms/publier-360-p0.png`, `publier-390.png` vs `echange-390.png`.
- **Correctif** : mesurer `scrollWidth`, `min-width: 0` ; squelette d'en-tête tant que la session n'est pas résolue.

#### SOUK-077 — Finitions de contenu et de langue
- **Sources** : QA-002, QA-003, QA-021, QA-028 (QA, Mineur) ; QA-004, QA-017, QA-020 (QA, Cosmétique) ; UX-019, UX-020, UX-021, UX-046 (UX, Cosmétique).
- **Description** : faute « portoflio » (contenu auteur), « Badge Security Checked » en anglais, « Discussions0 », @username absent du menu, pied de page manquant sur `/tableau`, `/missions`, `/notifications`, « Réessayer » sur un profil inexistant, recherche du bandeau d'Échange qui mène au Store, illustrations claires en thème sombre, apostrophes et espaces insécables, unités « F »/« FCFA ».
- **Preuve** : `qa/visiteur/01-accueil.png`, `05-filtres-categorie.png`, `06-fiche-appli.png`, `qa/dev/10-menu-compte.png`, `11-tableau.png`, `25-dev-inexistant.png`, `48-echange-filtres.webp` ; `ux/captures/404-360.png`, `zooms/accueil-360-sombre-p0.png`, `ux/captures/client/zoom-store-360-sombre-cartes.png`.
- **Correctif** : passe de relecture et fichier de traduction centralisé.

#### SOUK-086 — `/missions` : les deux options ne sont pas expliquées
- **Sources** : UX-060 (UX, Mineur).
- **Description** : l'état vide est clair, mais rien ne distingue « Personnaliser une appli » de « Recruter un dev », ni le coût ou le délai.
- **Preuve** : `ux/captures/clair/missions-clair.png`.
- **Impact** : un client non technique ne sait pas quoi choisir.
- **Correctif** : une phrase et une fourchette de prix ou de délai sous chaque option.

#### SOUK-087 — Contenu essentiel du hero dépendant d'une animation qui part d'une opacité nulle
- **Sources** : UX-056 (UX, signalé Bloquant puis **retiré** par UX après revérification).
- **Description** : le titre, l'accroche et les boutons du hero apparaissent par des animations d'entrée (`apparition`, `apparition-fondu`) qui partent d'une opacité 0, avec `animation-fill-mode: both` et des délais de 80 à 320 ms. Une capture prise avant la fin des animations les montre absents, d'où le signalement initial. Après rechargement complet en thème clair, le hero est lisible : il n'y a pas de défaut de contraste (texte `#ffffff` sur fond `bg-nuit` dans les deux thèmes).
- **Reproduction** : `/` en thème clair ; capturer immédiatement après le chargement, puis après 1 s.
- **Preuve** : `ux/captures/clair/accueil-hero-clair.png` (capture prématurée) et `ux/captures/clair/accueil-hero-clair-reverif.png` (revérification, hero lisible) ; `frontend/src/features/accueil/Accueil.tsx` l.63-83, `frontend/src/index.css` l.304-345 (`main` @ `624431c`).
- **Impact** : faible. Si les animations sont suspendues ou retardées (onglet en arrière-plan, appareil lent), la promesse et les boutons « Je suis dev » / « Je cherche une appli » peuvent rester invisibles un moment.
- **Correctif** : ne pas faire dépendre un contenu essentiel d'une animation qui part d'une opacité nulle : animer seulement `transform`, ou partir d'une opacité visible, ou réserver l'animation aux éléments décoratifs ; ajouter un test visuel des deux thèmes.
- **Sévérité** : UX Bloquant, puis retiré → retenu **Basse**.

### 4.5 Info

#### SOUK-078 — Le compte GitHub utilisé pour l'audit Dev est l'admin réel (id 1)
- **Sources** : SEC-018 ; UX connecté dev (« Particularité du compte ») ; `paiement.md` (SD-2026-000003).
- **Description** : `GET /api/me` → id 1, profil `dev`, `est_admin: true`. Il a servi en lecture seule pour Sécurité et API, mais QA y a publié `/store/2`, créé le canal et accepté un correctif, et le clic SasPay d'UX a créé SD-2026-000003 sur ce compte (Souk.dev ne permet la connexion dev que par GitHub, avec l'accord d'Octave).
- **Conséquence** : tests IDOR dev → dev et vue d'un dev non admin non faits ; nettoyage nécessaire (section 7).

#### SOUK-079 — 401 transitoire sur `/api/me` juste après un lien magique (non reproduit)
- **Sources** : SEC-015. Retest : `/api/me` 200, `/sanctum/csrf-cookie` 204. À surveiller.

#### SOUK-080 — Labels Compose autorisés, sans effet sur Traefik
- **Sources** : DEP-10. Traefik n'utilise que le provider fichier (`infra/proxy/traefik.yml:1-17`). Option : retirer les `labels`.

#### SOUK-081 — Catégories codées en dur dans le front alors que `GET /api/categories` existe
- **Sources** : API-06. Risque de dérive si l'API évolue.

#### SOUK-082 — `Permissions-Policy: payment=()`
- **Sources** : I-05 (recon). Sans effet tant que le paiement est hébergé chez SasPay.

#### SOUK-083 — Sandbox SasPay à manier avec prudence
- **Sources** : PAY-11. Sans clé, passerelle `simulee` (`/simulateur/saspay/{session}` → 404 en prod) ; en prod `SASPAY_SECRET_KEY` obligatoire ; isolation de `sk_test` à confirmer avant tout test avec argent.

#### SOUK-084 — `/connexion` affiche le formulaire à un utilisateur déjà connecté
- **Sources** : API-14. Rediriger vers `/tableau` ou `/echange`.

#### SOUK-085 — Scopes OAuth minimaux ; texte « dépôts publics » à expliciter
- **Sources** : SEC-001 ; QA-012. Scopes demandés : `user:email`, `read:user` uniquement. Documenter dans l'UI ce que le jeton permet réellement.

### 4.6 Tableau des sévérités et désaccords

| Sévérité | Nombre | Identifiants |
|---|---:|---|
| Critique | 2 | SOUK-001, 002 |
| Haute | 14 | SOUK-003 à 016 |
| Moyenne | 39 | SOUK-017 à 054, 072 |
| Basse | 24 | SOUK-055 à 071, 073 à 077, 086, 087 |
| Info | 8 | SOUK-078 à 085 |
| **Total** | **87** | (à partir de 195 constats sources) |

**Désaccords de sévérité entre bots (et arbitrage retenu)**

| Sujet | Positions des bots | Retenu |
|---|---|---|
| HTTP → 500 (SOUK-006) | Sécurité Élevée ; Perf et recon Moyenne | Haute |
| Frais non affichés (SOUK-010) | Paiement Moyenne ; UX Majeur (×4) | Haute |
| « Gentube » (SOUK-011) | Paiement Moyenne ; UX Majeur | Haute |
| Lien magique en spam (SOUK-012) | Sécurité Moyenne ; QA Majeur | Haute |
| Appli à failles en vitrine / Trivy (SOUK-013) | QA Info (fiche QA) puis Majeur (`qa/client/rapport.md`) ; Sécurité Moyenne ; UX Majeur | Haute |
| Compression (SOUK-016) | Perf Critique | Haute |
| robots/sitemap (SOUK-017) | Perf Critique ; Paiement Basse ; API Info ; recon Faible | Moyenne |
| Meta/OG (SOUK-018) | Perf Critique | Moyenne |
| CSP (SOUK-021) | Sécurité Moyenne ; recon Faible | Moyenne |
| CGV/annulation au paiement (SOUK-028) | UX Majeur ; Paiement Basse | Moyenne |
| Formule imposée (SOUK-031) | QA Majeur (à confirmer) ; Paiement Moyenne ; UX Mineur | Moyenne |
| Liens admin visibles (SOUK-056) | QA Majeur (à confirmer) ; Sécurité Faible | Basse (compte admin réel) |
| `/factures` 404 (SOUK-055) | QA Majeur | Basse |
| QA-019 Échange (SOUK-002) | QA Bloquant ; UX Majeur | Critique |
| Hero en thème clair (SOUK-087) | UX Bloquant, puis retiré par UX après revérification | Basse (résolu) |
| Moyens de paiement affichés (SOUK-072) | UX Majeur (UX-057) ; UX Mineur (UX-054, UX-055) | Moyenne |

**Contradictions factuelles entre rapports**

1. **Langue et annulation SasPay** : UX (UX-052, UX-053) recommande de passer `locale=fr` et une URL d'annulation ; Paiement (PAY-14, PAY-16) montre que l'API SasPay n'offre ni l'un ni l'autre. Retenu : Paiement.
2. **Hôtes HTTP en 500** : Sécurité (SEC-006) et `CARTE.md` citent apex et www ; la recon passive (M-02) cite aussi `http://api.soukdev.shop/`. À revérifier pour l'API.
3. **Limite de débit** : Sécurité (SEC-003) relève `x-ratelimit-limit: 60` sur la redirection OAuth ; API relève 300 sur `/api/*`. Probablement deux limiteurs différents (web/API), non contradictoire mais à documenter.
4. **Lignes de code PAY-01** : `paiement.md` cite l.215-245 puis l.216-245 ; la relecture du commit `624431c` place la fonction l.213-246. Le constat est identique.
5. **Exemple de frais UX** : UX-040 illustre « Frais MTN MoMo : 53 F » ; le montant réel observé est 123 F (UX-051, PAY-04).
6. **QA-006 « à confirmer »** et **QA-015 « à confirmer »** : levés respectivement par PAY-06 (formule fixée par l'auteur, code) et SEC-018 (compte admin).
7. **QA-009** est classé Info dans `qa/RAPPORT-QA.md` mais Majeur dans `qa/client/rapport.md`.
8. **`qa/dev/rapport.md`** dit que l'écran de consentement OAuth n'a pas été atteint ; la phase 3 de `qa/RAPPORT-QA.md` (QA-012) et SEC-018 montrent une connexion réussie ensuite. Le premier fichier est obsolète.
9. **Hero en thème clair (UX-056) — résolu** : le volet thème clair le signalait comme invisible, en contradiction avec le rapport public d'UX (captures `accueil-390.png`, `accueil-1440.png`) et avec le code (texte blanc sur fond sombre dans les deux thèmes). UX l'a revérifié après rechargement complet : hero lisible, la première capture avait été prise avant la fin des animations (`ux/captures/clair/accueil-hero-clair-reverif.png`). UX a retiré le constat ; il reste une recommandation en Basse (SOUK-087).
10. **Mention « à venir » sur `/deployer`** : UX-043 la croyait réservée aux lecteurs d'écran ; UX-058 la décrit comme visible.

---

## 5. Ce qui a été testé et tient bon

**Contrôle d'accès et données**
- Routes privées sans session → 401 (`/api/me*`, `/api/missions`, `/api/deployments`, `/api/factures`, `/api/admin/*`) (API passe 1).
- `/api/admin/*` → **403** pour un client non admin (8 routes, comptes Sécurité B et API A) ; `est_admin` hors `Fillable` (SEC-016, SEC-S08, API §8.1).
- **Pas d'IDOR** : factures, missions, déploiements, sauvegardes d'autrui → 404/403 sans corps ; événement de test A non lisible (participants), ni modifiable ni supprimable par B ; sessions A/B bien séparées (SEC-017, API passe 3).
- Profils publics sans e-mail ni téléphone ; `/api/discussions` et `/api/canaux` publics par conception (API).
- Canaux Reverb privés liés à la session et au propriétaire, comptes suspendus refusés (SEC-S07, lecture de code).
- CORS : origine figée `https://soukdev.shop`, pas de reflet (`evil.example`, `null`, `evil.soukdev.shop`) (SEC-008, I-01).
- Cookies de session Secure + HttpOnly + SameSite=Lax (SEC-002) ; CSRF Sanctum ; CSP de l'API `default-src 'none'`, `X-Frame-Options: DENY`, `nosniff` ; TLS 1.3 Let's Encrypt valide (I-03).

**Argent**
- **Montants calculés côté serveur** : aucun montant ni plan accepté du navigateur ; facture = `config/facturation.php` (PAY-09).
- **Webhook SasPay** : HMAC-SHA256 de `{timestamp}.{corps brut}`, `hash_equals`, fenêtre 300 s, empreinte anti-rejeu, secret vide refusé, et **re-vérification via l'API SasPay** (le webhook seul ne paie pas) (PAY-10).
- Statut de `/paiement/retour` jamais lu dans l'URL (PAY, synthèse) ; `Idempotency-Key` côté front.
- **Aucune copie déployée sans paiement** : SD-2026-000003 reste « À payer », copie « En attente du paiement », aucune URL (PAY-17, `paiement-captures/01-04`).
- 0 % de commission respecté au grand livre (part appli intégralement au dev).

**Secrets**
- Aucun secret dans le dépôt public (`.env*.example` vides, `.env` et `.env.prod` ignorés, raw → 404), ni dans le bundle front (pas de `sk_`, `AIza`, secret GitHub/SasPay, clé privée) (SEC-S01, S02, S06, PAY-12, I-02).
- **Gitleaks bloque bien les secrets** à la publication (422), fail-closed si l'analyse est indisponible (503), contournements d'allowlist neutralisés (SEC-S04).
- OAuth GitHub : scopes `user:email` + `read:user` seulement (SEC-001, QA-012).

**Moteur de copies (code)**
- Traefik en provider fichier uniquement ; refus de `privileged`, ports publiés, bind mounts, réseaux externes, `network_mode` host ; `cap_drop: ALL`, `no-new-privileges`, `pids_limit` imposés ; environnement Docker vidé (pas d'interpolation `${SASPAY_*}`) ; `DOMAINE_COPIES` distinct exigé ; arrêt `down -v --rmi local` ; sauvegardes `--network none` (DEP-11).

**Front et parcours**
- Aucun débordement horizontal (19 pages × 4 largeurs × 2 thèmes), aucune image cassée, thème sombre réussi (UX).
- Lighthouse Accessibilité 100, lien d'évitement, focus visible, `lang="fr"`, zoom non bloqué (A11Y-04, SEO-07).
- Messages d'erreur clairs à la publication ; badge d'analyse < 1 min ; `/paiement/retour` direct → « Lien de retour incomplet » (QA-010) ; acceptation de correctif claire, sans fusion GitHub (QA phase 5) ; protection du numéro de reversement par confirmation e-mail (UX connecté).

---

## 6. Limites de l'audit

**Générales**
- Aucun paiement réel ni sandbox SasPay : **l'exploitabilité de PAY-01 n'est pas confirmée**.
- **Fonctionnement réel du scheduler et du worker `paiements` en prod non vérifié** (pas d'accès serveur ; `/up` ne couvre que l'API web). L'annulation automatique de SD-2026-000003 le 17 nov. à 07:00 en dépend.
- Un seul compte Dev disponible, qui est l'admin réel (id 1) : pas de vue « dev débutant non admin », pas d'IDOR dev → dev, notifications d'Échange non testées à deux comptes.
- Catalogue de 1 appli réelle (+ 1 appli de test) au moment des mesures.

**Sécurité (non couvert, d'après `securite.md`)** : tests actifs XSS/SQLi/CSRF sur les mutateurs ; rate limiting au-delà de l'en-tête ; IDOR en écriture et dev → dev ; preuve dynamique « dépôt piégé » (SEC-013 tiré du code) ; auth des canaux privés Reverb.

**Paiement (non couvert, d'après `paiement.md`)** : tunnel complet avec un compte audit dédié, double clic sur Payer, reçu `frais_client`, `/revenus` avec reversements actifs, rejeu de webhook en sandbox ; tarif réel 123 F à lire dans le compte marchand SasPay.

**Déploiement (partiel)** : **aucun test en production** (T1 à T13 non réalisés, aucun dépôt public créé, rien déployé sur soukdev.shop) ; **DEP-01 et DEP-02 confirmés par exécution locale du code de la plateforme** (`/workspace/souk-deploiement/verif-locale/sortie.txt`), **non observés en production**. Les dépôts de test `audit-extra-hosts` et `audit-amp-limites` sont prêts dans `/workspace/souk-deploiement/repos/` si Octave veut les créer lui-même sur GitHub et lancer les copies de test ; isolation réseau A↔B, fuite d'environnement, labels Traefik, build cassé, expiration, mise à jour/rollback, sauvegardes, `DOMAINE_COPIES ≠ SESSION_DOMAIN` en prod non vérifiés.

**API (non couvert, d'après `api.md`)** : paiement et webhook (laissés à Paiement), publication Store, envoi de messages, contournement d'auth, charge ; 429 non déclenché.

**Perf / SEO / a11y** : pas de données terrain CrUX (quota PageSpeed) ; pages connectées non mesurées ; labo ≠ terrain ; axe automatique ≠ audit WCAG manuel.

**UX / mobile** : thème clair des pages connectées et `/missions` couverts depuis 12:56 (bureau 1280 px) ; espace dev et commande connectée jugés sur captures statiques (pas de mesures DOM) ; commande connectée non vue en mobile (360/390/768) ; UX-056 retiré après revérification (SOUK-087) ; parcours complet avec un compte Entreprise de test (retour après lien magique, `/paiement/retour`, copie en construction puis en ligne), états d'erreur, appli payante ou à variables non audités.

**QA** : parcours terminés ; QA-033 à revérifier avec deux comptes dev.

---

## 7. Nettoyage après l'audit (à faire par Octave)

L'interface ne permet pas de tout retirer ; ces actions demandent un accès admin ou base de données. Aucun bot n'a rien supprimé.

| # | Élément | Où | Action |
|---|---|---|---|
| 1 | Appli de test publique `/store/2` (`audit-qa-souk-todo`), en tête du Store | Base / admin | Dépublier ou supprimer (pas d'action dans l'UI, SOUK-015) |
| 2 | Canal Échange `audit-qa` | https://soukdev.shop/echange?canal=audit-qa | Supprimer |
| 3 | Discussion `/echange/1` (résolue) et son correctif accepté | https://soukdev.shop/echange/1 | Supprimer |
| 4 | Copie de test encore en ligne | https://d4.souk-apps.duckdns.org | Arrêter (expiration prévue ~2 h d'après la carte, à confirmer) |
| 5 | Dépôt public `octavebahoun/audit-qa-souk-todo` et branche `fix-tache-vide` (commit `c6e144d`, aucune PR) | GitHub | Supprimer le dépôt |
| 6 | +140 points de Souk Score sur `octavebahoun` (65 → 205, auto-acceptation) | Base | Corriger le score et les XP |
| 7 | Facture SD-2026-000003 (3 500 F, impayée) sur le vrai compte d'Octave, copie `portfolio-open` en attente de paiement | `/paiements`, `/copies` | Annulation automatique prévue le **17 nov. 2026 à 07:00 (heure de Paris)** si scheduler et worker tournent ; sinon annuler à la main avec le lien « Annuler cette commande » de `/store/1/deployer` (non cliqué par les bots, décision d'Octave). Un e-mail « Commande annulée » est attendu ce jour-là |
| 8 | Compte marchand SasPay nommé « Gentube » | Tableau de bord SasPay | Renommer en « Souk.dev » (et logo) |
| 9 | Comptes de test clients créés par magic link (`+audit-sec-a/b`, `+audit-api`, `+audit-api-b` ; ids 7, 8, 9 cités) | Base / admin | Supprimer si souhaité (aucune donnée sensible ; bios déjà restaurées, événement de test déjà supprimé par API) |

---

## 8. Annexe : index des fichiers sources et des captures

**Rapports (sous `/workspace/soukdev-audit/` sauf mention)**

| Fichier | Contenu |
|---|---|
| `CARTE.md` | Carte de reconnaissance, rôles, répartition des 7 bots |
| `/workspace/souk-audit/RAPPORT-RECON-PASSIVE.md` (lien `RAPPORT-RECON-PASSIVE.md`) | Recon passive sécurité (M-01 à I-06) |
| `securite.md` | SEC-001 à SEC-018, statut final |
| `notes-secrets-verif.md` | SEC-S01 à SEC-S08 |
| `paiement.md` | PAY-01 à PAY-17, cycle de vie de SD-2026-000003 |
| `deploiement.md` | DEP-01 à DEP-12, plan de test restant, statut final |
| `api.md` | API-01 à API-14, tableaux route par route (passes 1 à 4) |
| `perf-seo-a11y.md` | PERF-01 à 07, SEO-01 à 07, A11Y-01 à 04 |
| `qa/RAPPORT-QA.md` (+ `qa/client/rapport.md`, `qa/dev/rapport.md`) | QA-001 à QA-034 |
| `ux/rapport-public-v1.md` | UX-001 à UX-021 |
| `ux/rapport-connecte-dev-v1.md` | UX-022 à UX-039 |
| `ux/rapport-client-deployer-v1.md` | UX-040 à UX-055 (dont complément SasPay) |
| `ux/rapport-theme-clair-v1.md` | UX-056 à UX-062 (thème clair connecté, `/missions`) ; UX-056 retiré après revérification (total UX : 61 constats, 0 bloquant, 27 majeurs) |
| Page Perf SEO | https://cursor.com/canvas/store-1d9d4551-d9f3-4ea6-8ce8-28792bef26f9/3b51de27-d280-474d-9c6c-3ead49da80cc |

**Données brutes et captures**

| Chemin | Contenu |
|---|---|
| `qa/visiteur/` | 19 captures visiteur (accueil, catalogue, légal 16 à 19…) |
| `qa/client/` | 15 captures client (01 à 15) |
| `qa/dev/` | 51 captures dev (00 à 62, dont Échange 52b-62) |
| `qa/depot-audit-qa-souk-todo/` | Fichiers du dépôt de test |
| `ux/captures/` | 110 captures pleine page publiques + `zooms/` |
| `ux/captures/connecte/` | 30 captures de l'espace dev + `zooms/` |
| `ux/captures/client/` | Store, fiche, déployer en invité (360/390/768, clair/sombre) et connecté |
| `ux/captures/saspay/` | `saspay-checkout-desktop.png`, `deployer-avant-clic.png` |
| `ux/captures/clair/` | 8 captures en thème clair : `accueil-hero-clair.png`, `accueil-hero-clair-reverif.png`, `copies-clair.png`, `deployer-clair.png`, `missions-clair.png`, `publier-clair.png`, `revenus-clair.png`, `tableau-clair.png` |
| `ux/mesures.json`, `ux/mesures-client.json` | Mesures Playwright (cibles, tailles de texte) |
| `paiement-captures/` | `01-paiements.png`, `02-facture.png`, `03-copies.png`, `04-notifications.png` (SD-2026-000003) |
| `raw-lighthouse/`, `lh-summary.json`, `psi-home-mobile.json` | Lighthouse |
| `raw-axe/`, `axe-results.json` | axe-core |
| `seo-static-meta.json`, `seo-rendered-meta.json` | Meta brutes et rendues |
| `headers-front.txt`, `oauth-github-headers.txt` | En-têtes (valeurs sensibles non reproduites ici) |
| `/workspace/souk-api/` | OpenAPI, inventaire des routes, sondes (peuvent contenir des Set-Cookie : ne pas republier) |
| `/workspace/souk-paiement/repo`, `/workspace/souk-deploiement/src` | Clones en lecture seule de `main` @ `624431c` |

*Aucun secret, jeton ou valeur de cookie n'est reproduit dans ce rapport.*

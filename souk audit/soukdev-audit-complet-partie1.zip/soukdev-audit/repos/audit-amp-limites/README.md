# audit-amp-limites

Dépôt **public d'audit inoffensif** pour Souk.dev (constat DEP-02).

Ce n'est **pas** une application de production. Il sert uniquement à vérifier si les plafonds mémoire et CPU d'une formule (par ex. « Petite », 512 Mo) s'appliquent **à chaque conteneur** ou à la copie entière, lorsqu'une copie déclare le maximum de 6 services.

## Contenu

- `soukdev.json` — manifeste valide (`backend: propre`, service `web` sur le port 80).
- `docker-compose.yml` — 6 services `nginx:1.27-alpine` (le maximum accepté), **sans** `mem_limit` côté auteur :
  - `web` — page statique
  - `idle1` à `idle5` — nginx au repos, sans charge mémoire ni CPU
- Au démarrage, le service `web` lit `/sys/fs/cgroup/memory.max` (cgroup v2) ou `/sys/fs/cgroup/memory/memory.limit_in_bytes` (cgroup v1) et l'affiche sur la page, ainsi que dans `/memory.txt`.

Aucune charge mémoire ou processeur n'est générée.

## Après déploiement

Ouvrir `https://<url-de-la-copie>/` et `https://<url-de-la-copie>/memory.txt`.

- Si la formule est « Petite » (512 Mo) et que `memory.max` (ou `memory.limit_in_bytes`) vaut 512 MiB **sur le seul service web**, cela confirme que le plafond est appliqué par conteneur. Les 5 services idle reçoivent le même plafond : la copie peut alors réserver jusqu'à 6 × 512 Mo.
- Comparer, côté opérateur si disponible, `docker stats` sur les 6 conteneurs de la copie.
- Si le dépôt est refusé pour un autre motif que le nombre de services, noter le message de vérification.

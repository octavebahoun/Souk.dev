# audit-extra-hosts

Dépôt **public d'audit inoffensif** pour Souk.dev (constat DEP-01).

Ce n'est **pas** une application de production. Il sert uniquement à vérifier si la plateforme accepte, dans le `docker-compose.yml` d'une copie, les clés `extra_hosts` et `dns`, et ce que le conteneur web en déduit une fois lancé.

## Contenu

- `soukdev.json` — manifeste valide (`backend: propre`, service `web` sur le port 80).
- `docker-compose.yml` — un seul service `web` (image construite à partir de `nginx:1.27-alpine`) avec :
  - `extra_hosts: ["host.docker.internal:host-gateway"]`
  - `dns: ["1.1.1.1"]` (résolveur public anodin, pas d'adresse hostile)
- Au démarrage, un script unique écrit `/probe.txt` avec :
  1. le contenu de `/etc/hosts`
  2. le contenu de `/etc/resolv.conf`
  3. **une seule** requête HTTP `GET http://host.docker.internal:80/` (délai 2 s), en n'enregistrant que le code de statut ou le message d'erreur, jamais le corps

Aucune boucle, aucun scan de ports, aucune autre requête.

## Après déploiement

Ouvrir `https://<url-de-la-copie>/probe.txt` (et la page d'accueil, qui pointe vers ce fichier).

- Si la vérification Souk.dev **refuse** le dépôt à cause de `extra_hosts` ou `dns`, le correctif DEP-01 est en place.
- Si la copie démarre, lire `/probe.txt` : présence de `host.docker.internal`, serveur DNS `1.1.1.1`, et résultat de l'unique tentative HTTP (succès, refus, ou délai dépassé).

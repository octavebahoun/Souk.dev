# Audit Déploiement — Souk.dev

- **Date** : 10 novembre 2026 (Europe/Paris, UTC+1)
- **Cible** : https://soukdev.shop + dépôt public [octavebahoun/Souk.dev](https://github.com/octavebahoun/Souk.dev) (`main` @ `624431c`)
- **Clone local** : `/workspace/souk-deploiement/src` (lecture seule, aucun push)
- **Périmètre (MA ZONE)** : publication GitHub / `soukdev.json` / builds / logs ; copies isolées Docker+Traefik ; sauvegardes ; arrêt ; formules & démarrage facturation hébergement ; robustesse infra compose plateforme
- **Hors zone** : tunnel SasPay, en-têtes HTTP/TLS (autres auditeurs)
- **Secrets** : aucune valeur secrète reproduite (type + fichier:ligne uniquement)

---

## Alerte — constats Critique / Haute

| ID | Sévérité | Titre | Statut |
|---|---|---|---|
| **DEP-01** | **Haute** | `extra_hosts` / `dns` / `dns_search` autorisés sans filtre dans le compose auteur → accès passerelle hôte / résolution hostile depuis une copie | **Confirmé par exécution du vérificateur** (pas encore observé en production) |
| **DEP-02** | **Haute** | Plafonds mémoire/CPU de la formule appliqués **par conteneur**, pas par projet (jusqu’à 6× la formule) → épuisement machine / écart facturation | **Confirmé par exécution de LimitesTaille** (pas encore observé en production) |

Aucun constat **Critique** d’isolation croisée (copie A → données/réseau interne de copie B, ou lecture directe de l’API/DB plateforme via labels Traefik) n’a été **prouvé** en lecture seule : les contrôles Traefik file-provider, refus `privileged` / bind mounts / réseaux externes, durcissement imposé et `IsolementCopies` (domaine cookies) sont présents. **DEP-01** reste le principal risque d’évasion résiduelle à confirmer en dynamique.

---

## Synthèse

Le moteur de copies est globalement **pensé pour l’isolation** : Traefik ne lit **jamais** les labels Docker (routes YAML écrites par `RouteurCopies`) ; `VerificateurCompose` refuse privileged, ports publiés, bind mounts, réseaux externes, `network_mode` host/bridge/container ; `LimitesTaille` impose `cap_drop: ALL`, `no-new-privileges`, `pids_limit`, réseau `soukdev-copie` préfixé par projet ; l’env des commandes Docker est vidé (`EnvironnementProcessus`) pour empêcher l’interpolation `${SASPAY_*}` ; `IsolementCopies` exige un `DOMAINE_COPIES` distinct du domaine de session.

Les écarts majeurs côté déploiement : **(1)** clés Compose dangereuses encore acceptées sans validation fine (`extra_hosts`, `dns`) ; **(2)** multiplication des plafonds par service ; puis opacités d’erreurs de build, root dans les images générées, socket Docker monté sur plusieurs workers, DinD `privileged` (profil machines).

---

## Architecture (déduite code + prod)

```
soukdev.shop (SPA) ──► api.soukdev.shop (Laravel/FrankenPHP)
                              │
                    queue « moteur » + docker.sock
                              │
              clone GitHub → validate soukdev.json + compose
                              │
         docker-compose.yml + docker-compose.soukdev.yml (+ backend.yml)
                              │
              projet Compose « d{id} », réseau {copie}_soukdev-copie
                              │
         Traefik (file provider) ← {copie}.yml  → https://{copie}.$DOMAINE_COPIES
```

| Formule | Mémoire / conteneur | CPU / conteneur | pids |
|---|---|---|---|
| Petite | 512m | 0,5 | 256 |
| Moyenne | 1g | 1 | 512 |
| Grande | 2g | 2 | 1024 |

Prix hébergement (CGV / `formules`) : 3 500 / 7 000 / 13 500 F CFA / mois. Facturation créée à la commande (`attente_paiement`) ; démarrage Docker seulement après paiement confirmé (hors détail SasPay).

---

## Constats

### DEP-01 — `extra_hosts` / `dns` / `dns_search` non filtrés

- **Sévérité** : Haute  
- **Statut** : Confirmé par exécution du vérificateur (10/11/2026) ; **pas encore observé en production**  
- **Reproduction** :
  1. Publier un dépôt dont le `docker-compose.yml` contient sur le service web :
     ```yaml
     extra_hosts:
       - "host.docker.internal:host-gateway"
     dns:
       - 1.2.3.4
     ```
  2. Commander une copie (ou copie de test).
  3. Depuis le conteneur (ou via un endpoint debug de l’appli d’audit), joindre l’IP de la passerelle Docker / ports host.
- **Preuve** :
  - `backend/app/Moteur/VerificateurCompose.php:22-30` — `extra_hosts`, `dns`, `dns_search`, `labels`, `links` figurent dans `CLES_SERVICE` acceptées.
  - Aucune méthode `verifierExtraHosts` / `verifierDns` dans ce fichier (seules privileged, network_mode, ports, volumes, build, env_file, cap_*, security_opt, pids, deploy, réseaux réservés).
  - Les tests unitaires (`VerificateurComposeTest.php`) couvrent privileged / ports / binds / NET_RAW / seccomp, **pas** `extra_hosts` ni `dns`.
- **Impact** : une appli malveillante peut faciliter l’accès à la **passerelle hôte** (scan des ports publiés sur l’hôte, dont Traefik en `network_mode: host`), forcer une résolution DNS hostile (exfiltration / MITM du trafic sortant de la copie). N’ouvre pas à elle seule le socket Docker ni le réseau interne d’une autre copie (réseaux projet séparés), mais augmente la surface d’attaque depuis le code auteur.
- **Correctif** : refuser `extra_hosts`, `dns`, `dns_search`, `links` (et idéalement `hostname`/`domainname` non nécessaires) dans `VerificateurCompose` ; ajouter des tests de régression ; documenter dans `soukdev.schema` / docs auteur.
- **PoC inoffensif** : dépôt `audit-extra-hosts` — image `curlimages/curl`, `command` qui fait `getent hosts host.docker.internal` et `wget -qO- --timeout=2 http://172.17.0.1:8082/ping` (échec attendu si bien filtré) ; `soukdev.json` service_web → ce service. Observer logs plateforme / échec de vérification **avant** mise en ligne si correctif appliqué.

---

### DEP-02 — Limites de formule par conteneur (× jusqu’à 6)

- **Sévérité** : Haute (disponibilité / coût)  
- **Statut** : Confirmé par exécution de `LimitesTaille` (10/11/2026) ; **pas encore observé en production**  
- **Reproduction** : publier un compose avec 6 services (web + 5 workers) sans `mem_limit` auteur ; déployer en Petite ; chaque conteneur reçoit 512m + 0,5 CPU → jusqu’à ~3 Go / 3 CPU pour une « Petite ».
- **Preuve** :
  - `backend/app/Moteur/LimitesTaille.php:7-11` : « Compose ne sait pas limiter le projet entier : web, base et les autres services reçoivent la même formule. »
  - `LimitesTaille::ecrire` applique `mem_limit` / `cpus` à **chaque** nom de service (`:81-119`).
  - `VerificateurCompose::MAX_SERVICES = 6` (`:37`).
  - Backend intégré ajoute encore `soukdev-db` + `soukdev-api` hors compteur auteur (`LanceurCompose.php:101-108`, commentaire Verificateur `:76-77`).
- **Impact** : un auteur peut saturer un nœud avec une seule copie « Petite » facturée 3 500 F ; placement multi-VPS mitigé mais course possible avant sonde. Écart promesse commerciale « Petite = 512 Mo » vs réalité.
- **Correctif** : plafond projet (cgroup parent / limite globale), ou diviser la formule par le nombre de services, ou facturer/refuser au-delà d’un budget mémoire total mesuré ; afficher clairement le plafond **total** au client.
- **PoC inoffensif** : `audit-amp-limites` — 6 services `nginx:1.27-alpine` idle ; après déploiement, `docker stats` (côté opérateur) montre 6×512Mi ; pas besoin d’attaque.

---

### DEP-03 — Erreurs de build / compose opaques pour le client

- **Sévérité** : Moyenne  
- **Statut** : Confirmé par le code  
- **Reproduction** : déployer un dépôt dont le `Dockerfile` échoue (`RUN false`) ; observer le champ `erreur` de la copie.
- **Preuve** : `LanceurCompose::echouerSiComposeRate` (`:372-385`) lit stdout/stderr mais ne les inclut **pas** dans l’exception (sauf détection « docker not found ») : `throw new LancementEchoue($message);` avec message générique (« Le lancement Docker Compose a échoué. »).
- **Impact** : auteurs/clients ne peuvent pas corriger un build cassé ; charge support ; pas une fuite (volontairement générique — bon pour ne pas exposer chemins hôte), mais manque un canal **auteur** (logs redactés).
- **Correctif** : journaliser la sortie côté serveur ; exposer aux **auteurs** un extrait redacté (sans chemins hôte / secrets) sur l’échec ; garder message générique pour les clients.

---

### DEP-04 — Conteneurs de copies souvent root (images générées / défaut Docker)

- **Sévérité** : Moyenne  
- **Statut** : Confirmé par le code (génération)  
- **Reproduction** : publier via `EcrivainDocker` (SPA/Node) ; `docker compose exec` → uid 0.
- **Preuve** : Dockerfiles générés dans `EcrivainDocker.php` (`FROM nginx:…` / `node:…-slim`) **sans** directive `USER` ; `LimitesTaille` n’impose pas `user:`.
- **Impact** : en cas d’évasion de conteneur, privilèges root namespace ; mitigé par `cap_drop: ALL` + `no-new-privileges` (`Durcissement` / `LimitesTaille:100-117`).
- **Correctif** : générer un `USER` non-root quand la pile le permet ; option `user:` imposé dans `docker-compose.soukdev.yml` pour les images connues.

---

### DEP-05 — Contrôle `IsolementCopies` absent des workers console

- **Sévérité** : Moyenne  
- **Statut** : Confirmé par le code  
- **Reproduction** : en théorie, `APP_ENV=production` avec `MOTEUR_URL_COPIE` sous le même domaine que `SESSION_DOMAIN` : les requêtes HTTP API lèvent `RuntimeException`, mais `php artisan queue:work` (`runningInConsole()===true`) **ne vérifie pas** et peut quand même lancer des copies.
- **Preuve** : `AppServiceProvider.php:122-134` — garde seulement `isProduction() && !runningInConsole()`.
- **Impact** : mauvaise config ops → copies servies sous le domaine du cookie de session → vol de session par le code auteur (scénario décrit dans `IsolementCopies.php:5-8`). En prod correctement configurée (`DOMAINE_COPIES` obligatoire dans `docker-compose.prod.yml:59`), risque faible.
- **Correctif** : exécuter le même contrôle au boot des workers moteur / dans `LancerDeploiement` avant clone ; fail-closed.
- **PoC** : config de staging volontairement mauvaise + job moteur (environnement de lab, pas prod).

---

### DEP-06 — Socket Docker monté sur 4 services plateforme

- **Sévérité** : Moyenne (surface interne)  
- **Statut** : Confirmé  
- **Preuve** : `docker-compose.prod.yml` lignes **149, 164, 180, 196** — `moteur`, `sondes`, `analyse`, `analyse-secrets` montent `/var/run/docker.sock`.
- **Impact** : toute RCE dans l’un de ces workers = contrôle du démon Docker hôte (breakout classique). L’API web elle-même n’a pas le socket (bon).
- **Correctif** : réduire au service `moteur` (+ éventuellement `sondes` en lecture limitée via proxy Docker) ; analyses gitleaks/Trivy via jobs déjà isolés sans sock permanent si possible ; rootless Docker / proxy d’API Docker filtrée.

---

### DEP-07 — DinD `privileged: true` (profil machines)

- **Sévérité** : Moyenne (dev / lab)  
- **Statut** : Confirmé  
- **Preuve** : `docker-compose.yml:279-289` service `dind`, `privileged: true`, image `docker:28-dind`.
- **Impact** : attendu pour DinD ; dangereux si le profil `machines` est activé sur un hôte partagé sans isolation forte.
- **Correctif** : documenter « lab only » ; jamais sur le VPS prod ; préférer machines distantes TLS (`DOCKER_HOST`) déjà prévues.

---

### DEP-08 — Tags d’images flottants (plateforme)

- **Sévérité** : Basse  
- **Statut** : Confirmé  
- **Preuve** : `postgres:16-alpine` (`docker-compose.prod.yml:85`), `node:24-alpine` (front build), vs Traefik **épiné** `traefik:v3.3.4`, FrankenPHP `dunglas/frankenphp:1.13.3-php8.4-alpine`, sonde `curlimages/curl:8.11.1`.
- **Impact** : rebuilds non reproductibles ; régression silencieuse.
- **Correctif** : épingler digests ou versions patch.

---

### DEP-09 — Noms de copie prévisibles `d{id}`

- **Sévérité** : Basse  
- **Statut** : Confirmé  
- **Preuve** : `LancerDeploiement.php:63` — `'d'.$deploiement->id` ; URL publique `{copie}.$DOMAINE_COPIES`.
- **Impact** : énumération des copies (reconnaissance) ; pas d’accès aux données sans auth appli.
- **Correctif** : suffixe aléatoire (déjà disponible via `MoteurDeploiement::nouveauId`) tout en gardant unicité DB.

---

### DEP-10 — Labels Compose autorisés (mitigé Traefik)

- **Sévérité** : Info  
- **Statut** : Confirmé / mitigé  
- **Preuve** : `labels` dans `CLES_SERVICE` ; `infra/proxy/traefik.yml:1-17` et `RouteurCopies` : **pas** de provider Docker, routes fichier uniquement.
- **Impact** : un label `traefik.*` malveillant **ne** prend **pas** le proxy ; résidu cosmétique / confusion outillage.
- **Correctif** : optionnel — strip/refuse `labels` / `annotations` au verify.

---

### DEP-11 — Contrôles d’isolation positifs (référence)

- **Sévérité** : Info  
- **Preuves** (non exhaustif) :
  - Traefik file-only : `RouteurCopies.php:7-13`, `infra/proxy/traefik.yml:13-17`
  - Refus privileged / host net / ports / binds / external networks : `VerificateurCompose` + tests
  - Durcissement imposé : `LimitesTaille.php:100-124`, `Durcissement.php`
  - Env Docker sans secrets plateforme : `EnvironnementProcessus.php:5-8` + `EnvironnementIsoleTest.php`
  - Domaine cookies : `IsolementCopies.php`, `.env.prod.example:10-13`, `docker-compose.prod.yml:41,59`
  - Arrêt libère volumes+images : `LanceurCompose::arreter` `down -v --rmi local` (`:172-176`) ; dossier cloné : `NettoyeurCopie`
  - Sauvegardes : `SauvegardeVolumes` (tar via conteneur `--network none`)
  - Pas de `.env` / secrets externes commités (volume `secrets` + `.env.prod` gitignored) ; `PROGRESS.md` mentionne la **présence** de clés locales sans coller de valeurs

---

## Plan de test restant

| # | Test | Besoin | Navigateur ? |
|---|---|---|---|
| T1 | DEP-01 dynamique : `audit-extra-hosts` publie + copie de test ; vérifier refus **ou** mesure de ce qui est joignable depuis la copie (passerelle, ping Traefik) | 1 compte GitHub, dépôt `audit-extra-hosts`, 1 copie test (gratuit) | Oui (publier / lancer copie test) |
| T2 | DEP-02 : `audit-amp-limites` 6 services ; relever `docker stats` sur la machine | Compte + accès opérateur machine **ou** admin `/admin/serveurs` | Partiel |
| T3 | Isolation réseau A↔B : deux copies, depuis A tenter IP privée de B (via appli audit) | 2 comptes clients **ou** 2 copies test, ~7 000 F si client payant | Oui |
| T4 | Isolation env : compose `${APP_KEY}` / `${SASPAY_SECRET_KEY}` sans valeur → doit rester vide (régression EnvironnementIsole) | Dépôt `audit-env-leak` + copie test | Oui |
| T5 | Labels Traefik injectés dans compose → sous-domaine autre copie **non** pris | `audit-traefik-labels` | Oui |
| T6 | Collision / cert : sous-domaine inventé → `/tls/copie` 404 (déjà test unitaire) ; confirmer en prod | curl | Non |
| T7 | Build fail : Dockerfile `RUN false` → message d’erreur + absence de conteneurs orphelins | Dépôt `audit-build-fail` | Oui |
| T8 | Arrêt / expiration copie test : après `expire_le`, plus de route ni volumes | Attente 120 min ou config lab réduite | Non / cron |
| T9 | Mise à jour + rollback : version cassée puis OK | Appli + 2 commits | Oui |
| T10 | Sauvegarde manuelle + liste + rétention | Copie client payante | Oui |
| T11 | Facturation : appli 0 F → hébergement facturé avant démarrage ; auteur de l’appli → `prix_appli=0` | Compte client + SasPay **sandbox** (bot Paiement) | Oui |
| T12 | Backend `integre` : `service_web` ne peut pas être `soukdev-api` ; PostgREST non exposé hors service_web | Dépôt integre d’audit | Oui |
| T13 | DOMAINE_COPIES prod ≠ SESSION_DOMAIN (vérif config, pas d’attaque) | Accès ops / lecture env (sans coller secrets) | Non |

---

## PoC dépôts suggérés (inoffensifs)

1. **audit-extra-hosts** — DEP-01  
2. **audit-amp-limites** — DEP-02 (6× nginx)  
3. **audit-env-leak** — interpolation secrets (doit échouer / valeurs vides)  
4. **audit-traefik-labels** — labels `traefik.http.routers…`  
5. **audit-build-fail** — build volontairement cassé  
6. **audit-isolation-canary** — écrit un token dans sa DB / fichier et expose un endpoint lecture ; servir à T3 (copie B ne doit pas lire le token de A)

Chacun : GitHub public, `soukdev.json` + `docker-compose.yml` minimaux, **aucune** charge réseau, **aucun** scan agressif (une requête HTTP locale max).

---

## Piste d’amélioration priorisée

1. Refuser `extra_hosts` / `dns` / `dns_search` / `links` (+ tests) — **DEP-01**  
2. Plafond mémoire **projet** ou communication tarifaire alignée — **DEP-02**  
3. Fail-closed IsolementCopies dans le worker moteur — **DEP-05**  
4. Réduire les montages `docker.sock` — **DEP-06**  
5. Logs de build redactés pour auteurs — **DEP-03**

---

*Fin du rapport déploiement. Fichier sœur reconnaissance : `/workspace/souk-deploiement/01-reconnaissance.md`.*

## Statut final (10/11/2026, 13:19 heure de Paris)

- **Tests dynamiques en production non réalisés.** Aucun dépôt public n'a été créé sur GitHub et rien n'a été déployé sur soukdev.shop. DEP-01 et DEP-02 restent **non observés en production**. Leur sévérité Haute est maintenue.
- **Scheduler et worker paiements en production : non vérifiables de l'extérieur.** Le code les définit correctement dans `docker-compose.prod.yml` : `worker` (`queue:work --queue=paiements,default`, healthcheck `docker/sante.php worker`) et `scheduler` (`schedule:work`, healthcheck `docker/sante.php planificateur`), tous deux en `restart: unless-stopped` (ancre `x-php`). Le seul indicateur public est `https://api.soukdev.shop/up`, qui répond 200, mais il ne concerne que l'API web, pas les files d'attente ni le planificateur. Pour confirmer, il faut un accès au serveur : `docker compose -f docker-compose.prod.yml ps worker scheduler` (statut `healthy` attendu) et `php artisan schedule:list` / la date du dernier passage.
- **Recommandation (DEP-12, Moyenne) :** exposer une sonde de santé interne ou une alerte (heartbeat du scheduler, âge du plus ancien job `paiements`), pour qu'un arrêt silencieux, qui empêche l'expiration des factures impayées, soit détecté.
- **Vérification locale du moteur réalisée** le 10/11/2026 à 13:19 (Europe/Paris, UTC+1) : le code de `VerificateurCompose`, `ValidateurSoukdev` et `LimitesTaille` (commit `624431c`) a été exécuté sur cette machine, dans une copie `/workspace/souk-deploiement/src-run` (PHP 8.4.27, Composer 2.8.8). Script conservé : `/workspace/souk-deploiement/verif-locale/verif-dep.php`. Les `docker-compose.yml` de test ont été acceptés tels quels (`tmpfs` et `command` n'ont pas entraîné de refus).

### Vérification par exécution locale du code de la plateforme (10/11/2026)

Commande lancée :

```bash
php /workspace/souk-deploiement/verif-locale/verif-dep.php
```

**DEP-01** — sortie exacte (extrait) :

```
- extra_hosts host.docker.internal:host-gateway : ACCEPTÉ
- dns 10.0.0.1 (IP privée) : ACCEPTÉ
- dns_search : ACCEPTÉ
- links : ACCEPTÉ
- dépôt audit-extra-hosts (exemple-audit.local:127.0.0.1 + dns 1.1.1.1) : ACCEPTÉ
- témoin sans clé réseau (doit être accepté) : ACCEPTÉ
- témoin privileged: true (doit être refusé) : REFUSÉ — docker-compose.yml est dangereux : | Le service « web » est privileged.
```

Conclusion DEP-01 : **confirmé par exécution du vérificateur, pas encore observé en production.** `VerificateurCompose::verifier()` accepte `extra_hosts` (y compris `host.docker.internal:host-gateway`), `dns` vers une IP privée `10.0.0.1`, `dns_search` et `links`. Le témoin `privileged: true` est bien refusé, donc le vérificateur tourne et filtre d'autres clés dangereuses.

**DEP-02** — sortie exacte (extrait) :

```
Services du compose (6) : web, repos1, repos2, repos3, repos4, repos5
MAX_SERVICES = 6
Formule Petite : memoire=512 Mo / service, cpus=0.5 / service
  web: mem_limit=512m  cpus=0.5
  repos1: mem_limit=512m  cpus=0.5
  repos2: mem_limit=512m  cpus=0.5
  repos3: mem_limit=512m  cpus=0.5
  repos4: mem_limit=512m  cpus=0.5
  repos5: mem_limit=512m  cpus=0.5
Total projet : 3072 Mo (3 Gi) et 3 CPU pour une formule Petite annoncée à 512 Mo / 0.5 CPU.
Facteur : ×6 (un plafond identique appliqué à chaque service).
```

Conclusion DEP-02 : **confirmé par exécution du vérificateur, pas encore observé en production.** `LimitesTaille::ecrire($repertoire, $services, 'petite')` applique `mem_limit: 512m` et `cpus: 0.5` à chacun des 6 services. Total projet : 3072 Mo et 3 CPU, soit six fois la formule Petite.

Les deux `soukdev.json` de test sont ACCEPTÉS par `ValidateurSoukdev`. Sortie complète : `/workspace/souk-deploiement/verif-locale/sortie.txt`.

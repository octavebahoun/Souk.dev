# Carte de reconnaissance — Souk.dev (pré-prod)

- **Cible** : https://soukdev.shop  
- **Date** : 10 nov. 2026 (Europe/Paris, UTC+1)  
- **Méthode** : recon **passive** lecture seule (curl + connecteur GitHub). Aucun compte créé, aucun paiement, aucun formulaire soumis, pas de fuzzing / brute force.  
- **Budget requêtes** : largement sous 60.  
- **Secrets** : si un cookie / token a été vu en transit, seule sa **nature** et son **emplacement** sont notés ; **aucune valeur** n’est reproduite ici.  
- **Livrable final prévu** : `/workspace/soukdev-audit/RAPPORT.md`

---

## 1. Stack observée

| Couche | Technologie (preuves) |
|---|---|
| Frontend | SPA **React 19** + **Vite** / **Rolldown**, TypeScript, Tailwind CSS 4 — shell `#root`, chunks `/assets/*`, preload de routes dans le HTML |
| Backend API | **Laravel** (README : Laravel 13 / PHP 8.4) derrière **FrankenPHP + Caddy** (`server: FrankenPHP Caddy` sur `api.soukdev.shop`) |
| Auth session | **Laravel Sanctum** cookie SPA : `/sanctum/csrf-cookie` → 204 ; cookies `XSRF-TOKEN` + `laravel-session` domaine `.soukdev.shop` ; client Axios `withCredentials` + `withXSRFToken` |
| Auth identité | Connexion via **GitHub** (parcours `/connexion`, champs `github_url` sur les profils `/api/devs`) |
| Temps réel | **Laravel Reverb** + client **Pusher/Echo** — CSP `connect-src` → `wss://reverb.soukdev.shop` |
| Base | **PostgreSQL 16** (README / stack repo) |
| Hébergement copies | Docker / Traefik (README) ; déploiement « en un clic » ; formules Petite / Moyenne / Grande |
| Paiement | **SasPay** (Mobile Money + carte, FCFA/XOF) ; réseaux listés via `/api/reseaux-mobile-money` |
| Front hébergeur | `server: Caddy` + `server: nginx` sur `soukdev.shop` ; HTTP/2 + HTTP/3 (`alt-svc: h3`) |
| Edge HTTP | Sur le port 80 clair : réponse **500** `Server: Pingora` (pas de redirection HTTPS) |
| Pas de | Supabase / Firebase côté plateforme (README : applis liées à un compte cloud auteur = hors scope actuel) |

**Hôtes** :
- App : `https://soukdev.shop` (www → apex en 301 HTTPS)
- API : `https://api.soukdev.shop` (préfixe JSON `/api/...`)
- WS : `wss://reverb.soukdev.shop`

---

## 2. Pages / routes front (visibles)

### 2.1 Preload HTML (routes « chaudes »)
Extraites du script de préchargement Vite (`vite.precharger.ts` / HTML prod) :

| Motif | Page |
|---|---|
| `/` | Accueil |
| `/store` | Catalogue Store |
| `/store/:id` | Fiche appli |
| `/store/:id/deployer` | Commande / déploiement |
| `/copies` | Mes copies (client) |
| `/paiements` | Mes paiements (client) |

### 2.2 Routes SPA découvertes dans le bundle JS
(SPA catch-all : presque tous les chemins renvoient le même HTML 200 — la vraie route est côté client.)

**Publiques / produit**
- `/` — Accueil  
- `/store`, `/store/:id`, `/store/:id/deployer`  
- `/connexion` (+ modale connexion)  
- `/profil`, `/devs`, `/devs/:username`  
- `/echange`, `/echange/:id` — fil / discussion  
- `/canaux`, `/etiquettes`  
- `/evenements` / `/events`  
- `/missions`  
- `/publier`, `/apps`, `/apps/verification`, `/apps/soukdev-json`  
- `/copies`, `/paiements`, `/paiements/:id`, `/paiement/retour`, `/factures`  
- `/revenus` (+ API `/me/revenus…`)  
- `/notifications`, `/notifications/reglages`  
- `/tableau`  
- `/legal/cgu`, `/legal/cgv`, `/legal/confidentialite`, `/legal/abus`  
- `/logout`

**Admin (présentes dans le JS — accès à verrouiller côté API)**
- `/admin/finances`, `/admin/factures`, `/admin/rapprochements`, `/admin/reversements`, `/admin/moderation`, `/admin/serveurs`

### 2.3 robots / sitemap
- `https://soukdev.shop/robots.txt` → **HTML SPA** (pas de robots.txt réel)  
- `https://soukdev.shop/sitemap.xml` (et `_index`) → **HTML SPA**  
- `/.well-known/security.txt` → HTML SPA  

### 2.4 Assets JS notables
`/assets/index-*.js`, `Accueil`, `Store`, `Fiche`, `Commande`, `MesCopies`, `MesPaiements`, `Signaler`, `ModaleConnexion`, `Publier`, `Profil`, `Fil` / Échange, `Evenements`, `Missions`, `MesRevenus`, `FacturePage`, `RetourPaiement`, chunks `api-*`, `preparerCsrf`, `reseaux`, `formules`, `pusher` / temps réel.

---

## 3. API publique (lecture seule, préfixe `/api`)

Base : `https://api.soukdev.shop` + helper front qui préfixe `/api`.

| Endpoint | Statut observé | Notes |
|---|---|---|
| `GET /sanctum/csrf-cookie` | 204 | Pose cookies session / XSRF |
| `GET /api/apps` | 200 | Catalogue paginé (`data`/`meta`/`links`) — 1 appli visible (« portfolio-open », prix 0) |
| `GET /api/devs` | 200 | Profils publics (username, souk_score, github_url…) |
| `GET /api/events` | 200 | Liste vide au moment de la recon |
| `GET /api/reseaux-mobile-money` | 200 | 17 réseaux (MTN, Moov, Orange, Wave, etc.) |
| `GET /api/me` | 401 | « Non connecté. » |
| `GET /api/missions` | 401 | Auth requise |
| `GET /api/store` | 404 | Pas de ressource à ce chemin |

**Autres chemins référencés dans le JS client** (non exercés en écriture) :  
`/api/apps/{id}`, `/avis`, `/versions`, `/missions`, `/deployments`, `/deployments/{id}/mise-a-jour`, `/sauvegardes`, `/factures/{id}/paiement` (+ `Idempotency-Key`), `/factures/{id}/verification`, `/me/revenus`, `/me/revenus/reversements`, `/me/coordonnees-reversement`, `/apps/soukdev-json`, `/apps/verification`, `/discussions`, `/broadcasting/auth`, routes `/api/admin/*`.

---

## 4. Deux rôles produit (pages + fonctionnalités)

### 4.1 Rôle A — Dev (vendeur / correcteur / auteur)

**Intention** : publier des applis, gagner en réputation via l’Échange, suivre revenus / reversements Mobile Money. Les clients sont un débouché ; le cœur reste les devs.

| Zone | Pages | Fonctionnalités |
|---|---|---|
| Compte | `/connexion`, `/profil`, édition profil | Auth GitHub / session Sanctum ; profil public `/devs/:username` (bio, compétences, Souk Score) |
| Publication Store | `/publier`, `/apps`, `/apps/verification`, `/apps/soukdev-json` | Lier un dépôt GitHub public ; vérif secrets (gitleaks) / failles (Trivy) ; génération `soukdev.json` / Docker assistée |
| Fiche vendeur | `/store/:id` (vue auteur) | Prix (gratuit / unique / mensuel), badge sécurité, versions |
| Échange (entraide) | `/echange`, `/echange/:id`, canaux, étiquettes | Poster bug/question/tuto ; proposer correctif (branche/fork) ; copie de test gratuite ~2 h ; accepter correctif (merge côté GitHub auteur) ; XP / badges |
| Missions | `/missions` | Missions privées client↔dev ; messages ; notation |
| Événements | `/evenements` | Organiser / s’inscrire ; avis |
| Revenus | `/revenus` (+ API `/me/revenus*`) | Mouvements, demande de reversement, coordonnées Mobile Money |
| Signalement | modale Signaler sur contenus | Motifs : spam, abus, hameçonnage, minage, contenu illégal, autre |
| Notifications | `/notifications`, réglages | Préférences |

### 4.2 Rôle B — Client acheteur (déploie une copie)

**Intention** : trouver une appli, commander **sa propre copie** isolée, payer en FCFA (Mobile Money / carte), gérer hébergement et factures.

| Zone | Pages | Fonctionnalités |
|---|---|---|
| Découverte | `/`, `/store`, `/store/:id` | Recherche / catégories ; prix ; 0 % commission annoncée ; badge sécurité ; avis |
| Commande | `/store/:id/deployer` | Choisir formule (Petite 3 500 F / Moyenne 7 000 F / Grande 13 500 F) ; renseigner variables client ; lancer déploiement |
| Paiement | redirection SasPay, `/paiement/retour`, `/paiements`, `/factures` | Mobile Money (17 réseaux) ou carte ; clé d’idempotence côté client ; vérification facture |
| Copies | `/copies` | État de chaque copie, URL, prochaine facture ; maj / sauvegarde / suppression (API) |
| Suivi | notifications | Rappels d’échéance ; suspension si impayé (données conservées) |
| Recrutement (optionnel) | espace entreprises / missions | Trouver un dev (compétences, pays, Souk Score) ; mission sur mesure |

### 4.3 Parcours transverses (les deux rôles)
1. **Inscription / connexion** → `/connexion` → Sanctum CSRF → OAuth GitHub.  
2. **Publier depuis GitHub** (dev) → vérif → fiche Store.  
3. **Signaler / corriger un bug** (dev) → Échange → correctif → acceptation.  
4. **Déployer** (client) → `/store/:id/deployer` → moteur Docker.  
5. **Acheter / payer** → facture → SasPay → retour.  
6. **Profil** → `/profil` / `/devs/:username`.

---

## 5. En-têtes de sécurité, TLS, redirections

### 5.1 Accueil `https://soukdev.shop` (HTTP/2 200)
| En-tête | Valeur / constat |
|---|---|
| Content-Security-Policy | Présente : `default-src 'self'` ; `script-src 'self' + 2 hashes` ; `style-src 'self' 'unsafe-inline'` ; `connect-src 'self' https://api.soukdev.shop wss://reverb.soukdev.shop` ; `frame-ancestors 'none'` ; `object-src 'none'` ; `frame-src https:` (large) ; `form-action 'self' https://api.soukdev.shop` |
| X-Frame-Options | `DENY` |
| X-Content-Type-Options | `nosniff` |
| Referrer-Policy | `strict-origin-when-cross-origin` |
| Permissions-Policy | `camera=(), microphone=(), geolocation=(), payment=()` |
| **Strict-Transport-Security** | **Absent** |
| Set-Cookie (front) | Aucun cookie posé par le HTML statique seul |

### 5.2 API `https://api.soukdev.shop`
- CSP stricte `default-src 'none'` (+ style/img limités)  
- CORS : `Access-Control-Allow-Origin: https://soukdev.shop` + credentials  
- Cookies (valeurs **masquées**) :  
  - `XSRF-TOKEN` — `Secure; SameSite=Lax` ; **pas** HttpOnly (attendu Sanctum) ; path=/ ; domain=`.soukdev.shop`  
  - `laravel-session` — `Secure; HttpOnly; SameSite=Lax` ; même domaine  

### 5.3 TLS
- Certificat Let’s Encrypt, CN=`soukdev.shop`  
- SAN : **uniquement** `soukdev.shop` (pas `www`, pas `api`/`reverb` dans ce cert — API/Reverb ont vraisemblablement leurs propres certs)  
- Validité observée : 9 nov. 2026 → 7 fév. 2027 (UTC)  

### 5.4 Redirections
| Test | Résultat |
|---|---|
| `https://www.soukdev.shop` | **301** → `https://soukdev.shop/` |
| `http://soukdev.shop` | **500** Pingora, pas de redirect HTTPS |
| `http://www.soukdev.shop` | **500** Pingora, pas de redirect HTTPS |

---

## 6. Repo GitHub

| Champ | Valeur |
|---|---|
| Repo | [octavebahoun/Souk.dev](https://github.com/octavebahoun/Souk.dev) |
| Visibilité | Public |
| Branche par défaut | `main` |
| Langage principal | PHP |
| Dernier push observé | 9 nov. 2026 ~23:52 Europe/Paris |
| Issues ouvertes | 3 |

**Structure haut niveau** :
```
Souk.dev/
├── backend/          # Laravel API, schema soukdev.json, tests PHPUnit
├── frontend/         # React/Vite (features: accueil, catalogue, echange,
│                     #   deploiements, paiements, revenus, comptes, admin…)
├── docs/             # architecture, paiement, exploitation, modération…
├── infra/
├── scripts/
├── openapi.yaml      # contrat API (~169 Ko)
├── docker-compose*.yml
├── DECISIONS.md, PROGRESS.md, REVERB.md, README.md, …
└── .github/
```

**Lecture seule uniquement** — rien n’a été modifié sur le dépôt.

---

## 7. Premiers signaux d’alerte (non exploités)

1. **Pas de HSTS** sur l’accueil (ni observé sur les réponses API sondées).  
2. **HTTP clair → 500 Pingora** au lieu d’un 301/308 vers HTTPS (apex et www).  
3. **Certificat apex** sans SAN `www` (mitigé par redirect HTTPS www→apex, fragile si le redirect HTTP échoue).  
4. **Pas de `robots.txt` / `sitemap.xml` réels** (SPA HTML) — SEO + crawl.  
5. **Catch-all SPA 200** sur `/admin`, `/login`, chemins inventés — surface de confusion / SEO soft-404 ; l’auth doit être **strictement** côté API.  
6. CSP : `style-src 'unsafe-inline'` ; `frame-src https:` très permissif.  
7. `Permissions-Policy: payment=()` — peut bloquer l’API Payment Request navigateur (peut être volontaire si tout passe par SasPay).  
8. Cookie `XSRF-TOKEN` lisible en JS (normal Sanctum) — à croiser avec origin/CORS stricts (OK pour le moment : origin verrouillée).  
9. Session posée dès un simple `GET` sur l’API racine — surface cookie / CSRF à valider dans les parcours mutateurs.  
10. OpenAPI + repo public = bonne doc pour l’audit, mais **carte d’attaque complète** aussi pour un tiers.  
11. Paiement réel SasPay + webhooks / idempotence : zone critique (à tester avec simulateur / sandbox, pas de vrai argent dans l’audit).  
12. Reverb / broadcasting auth : surface WebSocket à contrôler (auth canal privé).

---

## 8. Répartition proposée — 7 bots (sans chevauchement)

Frontières explicites : chaque bot a un **périmètre inclus** et un **hors-scope** vers les autres.

### Bot 1 — Sécurité
- **Inclus** : en-têtes (HSTS, CSP, cookies, CORS), TLS/redirects HTTP, authN/Z (Sanctum, OAuth GitHub, sessions), CSRF, isolation admin, surface Reverb/broadcasting, fuite d’info (erreurs, chemins), secrets dans le front/build, politique signalements/suspensions côté sécurité.  
- **Hors-scope** : scénarios métier bout-en-bout (→ QA) ; montants/webhooks SasPay (→ Paiement) ; perf Lighthouse (→ Perf SEO) ; layout mobile (→ UX Mobile) ; contrat OpenAPI exhaustif (→ API) ; pipeline Docker moteur (→ Déploiement).

### Bot 2 — QA Parcours
- **Inclus** : parcours fonctionnels des **deux rôles** (connexion, publier, Échange bug→correctif, fiche Store, profil, notifications, pages légales) en conditions nominales + erreurs UX métier.  
- **Hors-scope** : ne ne valide pas la sécurité crypto/headers (→ Sécurité) ; ne lance pas de paiement réel ni ne vérifie le grand livre (→ Paiement) ; ne mesure pas les Core Web Vitals (→ Perf SEO) ; ne juge pas le responsive pixel-perfect (→ UX Mobile) ; ne mappe pas toutes les routes OpenAPI (→ API) ; ne teste pas l’isolation conteneur/runtime (→ Déploiement) sauf smoke « copie démarrée ».

### Bot 3 — Paiement
- **Inclus** : SasPay (checkout_url, retour `/paiement/retour`), Mobile Money (17 réseaux), factures, `Idempotency-Key`, vérification, abonnements mensuels, suspension / reprise, 0 % commission (part appli → dev), reversements `/me/revenus*`, avoirs/remboursements admin **côté flux argent**.  
- **Hors-scope** : UI catalogue / copy (→ QA / UX) ; headers TLS (→ Sécurité) ; perf checkout page (→ Perf SEO) ; provisioning machine (→ Déploiement) ; schema JSON général hors endpoints facture/paiement (→ API).

### Bot 4 — Déploiement
- **Inclus** : publication GitHub → `soukdev.json` / compose ; formules ressources ; création copie isolée ; sous-domaine copie ; mises à jour / rollback ; sauvegardes / export ; limites (1 service web, ≤6 services, ≤2 Go) ; multi-serveurs / placement.  
- **Hors-scope** : paiement de la commande (→ Paiement) ; auth (→ Sécurité) ; parcours UI hors écran déployer/copies (→ QA) ; SEO (→ Perf SEO) ; mobile CSS (→ UX Mobile) ; liste OpenAPI hors `/deployments*` et publication (→ API).

### Bot 5 — API
- **Inclus** : conformité `openapi.yaml` ↔ prod ; codes HTTP ; pagination ; validation 422 ; auth 401/403 ; rate-limit 429 ; idempotence HTTP ; versioning ; absence de fuite de champs sensibles dans les JSON publics.  
- **Hors-scope** : UX des écrans (→ QA / UX) ; config TLS serveur (→ Sécurité) ; moteur Docker (→ Déploiement) ; règles métier argent détaillées au-delà du contrat (→ Paiement) ; métriques perf navigateur (→ Perf SEO).

### Bot 6 — Perf SEO
- **Inclus** : Lighthouse / CWV (LCP, INP, CLS) sur routes preloadées ; poids bundles ; robots/sitemap/meta/OG ; soft-404 SPA ; indexabilité Store/fiches ; HTTP cache assets.  
- **Hors-scope** : bugs fonctionnels (→ QA) ; vulns (→ Sécurité) ; paiements (→ Paiement) ; runtime copies (→ Déploiement) ; exactitude OpenAPI (→ API) ; gestes tactiles / accessibilité fine mobile (→ UX Mobile, avec partage possible des scores a11y Lighthouse en lecture seule).

### Bot 7 — UX Mobile
- **Inclus** : responsive & thème clair/sombre ; navigation mobile Store / fiche / déployer / Échange / copies ; accessibilité (focus, contrastes, cibles tactiles) ; messages d’erreur lisibles ; friction formulaire commande.  
- **Hors-scope** : scores perf chiffrés (→ Perf SEO) ; sécurité (→ Sécurité) ; exactitude flux paiement (→ Paiement) ; logique déploiement serveur (→ Déploiement) ; couverture API (→ API) ; scénarios E2E desktop complets (→ QA, qui reste owner des parcours ; UX Mobile se concentre sur rendu & interaction petit écran).

### Matrice rapide « qui touche quoi »

| Zone | Sécu | QA | Paiement | Déploiement | API | Perf SEO | UX Mobile |
|---|---|---|---|---|---|---|---|
| Headers / TLS / auth | ■ | | | | □ contrat | | |
| Parcours rôles A/B | | ■ | | | | | □ mobile |
| SasPay / factures / reversements | | | ■ | | □ | | |
| Moteur copies / Docker | | □ smoke | | ■ | □ | | |
| OpenAPI / status codes | | | | | ■ | | |
| CWV / robots / SEO | | | | | | ■ | □ a11y scores |
| UI petit écran / thème | | | | | | | ■ |

■ = propriétaire □ = consultation limitée / frontière

---

## 9. Notes méthodo pour la suite

- Continuer en **sandbox / comptes de démo** (README : Awa Dossou, Pharmacie du Port, admin) — pas de production argent réel.  
- Préférer le **simulateur SasPay** documenté.  
- Ne jamais coller de secrets (`.env`, cookies, tokens) dans `RAPPORT.md`.  
- Ancrer chaque finding à une URL, un en-tête, un extrait OpenAPI ou un chemin de fichier repo.

---

*Fin de la carte de reconnaissance passive.*

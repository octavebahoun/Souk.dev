# Audit UX / UI / mobile : parcours DÉVELOPPEUR CONNECTÉ (v1)

- **Cible** : https://soukdev.shop, compte GitHub `octavebahoun`, en observation seule (captures fournies par l'opérateur, rien n'a été soumis de mon côté)
- **Date** : 10 nov. 2026, vers 03:30 (Europe/Paris, UTC+1)
- **Source** : 30 captures dans `/workspace/soukdev-audit/ux/captures/connecte/`, renommées `<écran>-<desktop|360|390>.png` (les 3 fichiers WebP ont été convertis en PNG) ; zooms de lecture dans `captures/connecte/zooms/`
- **Thème observé** : sombre (le compte est en thème sombre). Certaines captures « 360/390 » montrent DevTools autour du rendu (`notifications-360.png`, `menu-compte-desktop.png`) : seul le contenu du viewport a été jugé
- **Limites** : ce sont des captures statiques, sans DOM, donc sans mesure automatique des cibles tactiles ni des débordements. Les captures pleine page font apparaître la barre de navigation basse au milieu de la page, ce qui est un artefact de capture et pas un défaut. Les constats marqués « à confirmer » doivent être revérifiés en direct
- **Particularité du compte** : la barre latérale affiche aussi **Finances, Serveurs, Modération** (entrées d'administration). Le compte est donc vraisemblablement admin, même si le menu l'étiquette « Dev ». La vue d'un dev débutant non admin reste à confirmer

## Synthèse (4 lignes)

1. L'espace dev est propre et cohérent : thème sombre soigné, états vides illustrés, réglages de notifications clairs (« Toujours envoyé » expliqué), message de sécurité sur le changement de numéro Mobile Money.
2. Le parcours principal « publier » freine le débutant : on saisit l'URL du dépôt à la main, on doit fournir `docker-compose.yml` et `soukdev.json` sans lien vers une doc, le prix « 15 000 » ressemble à une valeur pré-remplie, et le bouton reste désactivé derrière une explication générique. « Mes applis » ne liste même pas les applis déjà publiées.
3. Sur mobile, la navigation du compte est une barre d'onglets horizontale coupée de plus de 10 entrées, et le menu avatar ne propose ni Revenus ni Paiements ni Réglages : on se perd vite.
4. Côté argent, `/revenus` se contredit : un « reversement automatique le 1er décembre 2026 » y côtoie « les reversements ouvrent bientôt », au-dessus d'un formulaire MTN/Moov/Celtiis actif.

## Vérification des observations de l'opérateur

| Observation rapportée | Vérifiée sur capture ? |
|---|---|
| `/publier` en 4 étapes, dépôt saisi par URL (pas de sélecteur), `docker-compose.yml` + `soukdev.json` exigés à la racine | **Oui**. Il existe toutefois une aide « Il manque soukdev.json ou docker-compose.yml ? **Souk.dev les écrit pour vous** » |
| Prix par défaut 15 000 F, « 0 si gratuite », mensuel ou unique | **En partie** : « 15 000 » s'affiche en gris comme un placeholder, et aucune option de paiement n'est présélectionnée. Ambigu (voir UX-025) |
| Hébergement à 3 500 / 7 000 / 13 500 F/mois payé par le client | **Oui** (« le client paie en plus l'hébergement de sa copie ») |
| Bouton « Publier » désactivé sans explication | **En partie** : une ligne dit « Complétez les quatre étapes pour publier : le récapitulatif dit ce qui manque », mais le récap reste vague et, sur mobile, se trouve **sous** le bouton (UX-024) |
| Menu compte sans Revenus ni Réglages | **Oui** (UX-027) |
| `/tableau` : chiffres qui changent (25→26 vues, 1→2 applis) | **Oui** : on voit aussi le Souk Score passer de 65 à 205 et le niveau de « Débutant » à « Contributeur ». C'est fonctionnel, à transmettre à QA |
| `/profil` : onglets coupés et défilants sur mobile | **Oui**, et c'est systémique sur tout l'espace (UX-028) |
| `/revenus` : 0 F, « pas de commission » + frais de reversement, « ouvre bientôt » malgré le formulaire visible | **Oui**, et la page annonce en plus une date de reversement automatique (UX-026) |
| `/copies` : 2 copies portfolio-open arrêtées, données supprimées, onglets qui débordent | **Oui** (UX-029, UX-030) |
| Barre basse fixe qui masque du contenu | **Probable, à confirmer** (UX-033) |
| Notifications : états vides corrects, e-mail de suspension « Toujours envoyé » | **Oui** (positif) |
| Formulaire de discussion : bouton désactivé sans message, dépôt GitHub facultatif alors que l'accroche parle de dépôt | **Oui** (UX-031) |

---

## Constats

### UX-022 · Publier, étape 1 : URL à taper, prérequis techniques sans documentation
- **Sévérité** : Majeur
- **Repro** : `/publier`, 360 et 390 px (et desktop), connecté en dev. L'étape 1 « Le dépôt GitHub » demande « Un dépôt public, avec un docker-compose.yml et un soukdev.json à la racine » et propose un champ texte « https://github.com/orga/appli » avec un bouton « Vérifier le dépôt ». Il n'y a ni liste des dépôts du compte GitHub déjà lié, ni lien vers la doc de `soukdev.json` ou un modèle de `docker-compose.yml`. Le bouton « Souk.dev les écrit pour vous » ne dit pas où il écrit.
- **Preuve** : `captures/connecte/publier-390.png`, `captures/connecte/zooms/publier-360-p0.png`, `captures/connecte/zooms/publier-desktop-p0.png`
- **Impact** : le dev débutant sur un mobile moyen doit copier-coller une URL (risque de faute, aller-retour vers l'appli GitHub) et découvre une exigence Docker qu'il ne maîtrise peut-être pas. « Souk.dev les écrit pour vous » inquiète, alors que la connexion promettait de ne jamais toucher aux dépôts : va-t-on pousser dans son dépôt ?
- **Correctif** : proposer un sélecteur de ses dépôts publics (recherche + liste, le compte est déjà lié via GitHub) en gardant l'URL en option. Ajouter un lien « Qu'est-ce que soukdev.json ? » vers un guide avec un exemple par stack (Laravel, Node, React statique). Renommer l'aide en « Générer les fichiers à ajouter à mon dépôt », avec un aperçu, un bouton « Copier » et un téléchargement, et préciser « nous n'écrivons rien dans votre dépôt » (ou « nous ouvrons une pull request » si c'est le cas).

### UX-023 · « Mes applis » ouvre le formulaire de publication, sans la liste des applis déjà publiées
- **Sévérité** : Majeur
- **Repro** : barre latérale ou menu avatar → « Mes applis » : l'entrée active est « Mes applis », mais la page est le formulaire « Publier une appli », et aucune des applis du compte n'y figure. Le tableau de bord, lui, en liste deux (`portfolio-open`, `audit-qa-souk-todo`).
- **Preuve** : `captures/connecte/publier-desktop.png`, `captures/connecte/menu-compte-desktop.png`, `captures/connecte/zooms/tableau-390-p0.png`
- **Impact** : le dev ne sait pas où voir le statut de son appli (analyse, badge sécurité), où la modifier, en publier une nouvelle version ou corriger ses failles (lien direct avec UX-001 du rapport public). Il risque de republier en double.
- **Correctif** : faire de `/apps` (« Mes applis ») une liste de cartes (nom, statut, badge de sécurité, vues, copies, actions Modifier / Nouvelle version / Voir la fiche), avec un bouton « Publier une appli » qui mène au formulaire. Pointer « Mes applis » vers cette liste.

### UX-024 · Publication bloquée : le récapitulatif ne dit pas quoi corriger, et il est sous le bouton sur mobile
- **Sévérité** : Majeur
- **Repro** : `/publier`, 360 px, formulaire vide. Le bouton « Publier l'appli » est désactivé, et la légende dit « Complétez les quatre étapes pour publier : le récapitulatif dit ce qui manque ». Le « Récapitulatif » (4 cercles vides, « À renseigner / À choisir ») est placé **après** le bouton et la légende. « Vérifier le dépôt » est lui aussi désactivé sans raison donnée. Sur desktop, le récap est à droite et reste visible.
- **Preuve** : `captures/connecte/zooms/publier-360-p1.png`, `captures/connecte/zooms/publier-360-p2.png`, `captures/connecte/zooms/publier-desktop-p1.png`
- **Impact** : sur mobile, le débutant voit un bouton grisé, cherche « le récapitulatif » sans savoir qu'il est plus bas, puis n'y trouve que des libellés génériques. La frustration est forte au moment le plus important.
- **Correctif** : sur mobile, placer un récap compact (stepper « 2/4 ») au-dessus du bouton, ou en barre fixe. Laisser le bouton actif et, au clic, faire défiler jusqu'au premier champ manquant avec un message en ligne (« Ajoutez une description d'au moins 80 caractères »). Rendre chaque ligne du récap cliquable vers son étape, et indiquer sous « Vérifier le dépôt » : « Collez l'adresse du dépôt pour lancer la vérification ».

### UX-025 · Prix et hébergement : placeholder pris pour une valeur, aucune simulation pour le client
- **Sévérité** : Majeur
- **Repro** : `/publier`, étape 3, 360 px. « Prix de l'appli » affiche « 15 000 F » en gris (placeholder), avec l'aide « 0 si elle est gratuite ». « Paiement » propose Mensuel / Une fois, rien n'étant sélectionné. Le titre « Taille d'hébergement recommandée » ne met en avant aucune recommandation. Rien n'indique ce que paiera le client au total ni ce que touchera le dev, et les frais de paiement ne sont pas mentionnés.
- **Preuve** : `captures/connecte/zooms/publier-360-p1.png`, `captures/connecte/zooms/publier-desktop-p1.png`
- **Impact** : le débutant croit que le prix est déjà rempli à 15 000 F, ou s'en sert comme ancre sans connaître son marché. Il ne comprend pas qu'un client paiera au minimum prix + 3 500 F/mois, et ne sait pas quelle taille choisir avant la mesure de mémoire (faite après la publication, d'après la fiche publique).
- **Correctif** : proposer un interrupteur « Gratuite / Payante » plutôt que « tapez 0 ». Supprimer le placeholder chiffré, ou l'écrire « ex. 15 000 ». Ajouter un simulateur en direct : « Le client paiera 15 000 F + 3 500 F d'hébergement (+ frais de paiement) = 18 500 F/mois ; vous recevez 15 000 F ». Présélectionner la taille « Petite (recommandée) », avec « ajustée après mesure » en aide.

### UX-026 · `/revenus` : messages contradictoires sur les reversements
- **Sévérité** : Majeur
- **Repro** : `/revenus`, 390 px et desktop. Dans le bloc « Solde à recevoir 0 F », on lit à la fois « Reversement automatique le 1er décembre 2026 » et « Les reversements sur Mobile Money ouvrent bientôt : votre solde vous attend ». Juste en dessous, le formulaire « Où recevoir vos revenus » (Bénin, MTN MoMo / Moov Money / Celtiis Cash, numéro ×2, « Enregistrer et recevoir le lien ») est actif. Le seuil de 5 000 F des CGV (reversement sur demande) n'apparaît pas.
- **Preuve** : `captures/connecte/revenus-desktop.png`, `captures/connecte/zooms/revenus-390-p0.png`, `captures/connecte/zooms/revenus-390-p1.png`
- **Impact** : le dev ne sait pas s'il sera payé le 1er décembre ou « un jour », ni si l'enregistrement de son numéro sert déjà à quelque chose. Le doute porte sur l'argent, ce qui en fait un point de confiance critique.
- **Correctif** : choisir un seul état et l'écrire clairement. Par exemple : « Reversements Mobile Money : ouverture prévue le 1er décembre 2026. Enregistrez votre numéro dès maintenant pour être payé automatiquement », ou bien masquer la date tant que le service est fermé. Préciser le rythme (mensuel, ou à la demande au-delà de 5 000 F), rappeler que les frais de reversement sont à la charge de Souk.dev, et expliquer « recevoir le lien » (« un lien de confirmation par e-mail »).

### UX-027 · Le menu avatar est incomplet et ordonné autrement que la barre latérale
- **Sévérité** : Mineur
- **Repro** : clic sur l'avatar (360 / 390 / desktop) : Mon profil, Tableau de bord, Mes copies, Mes applis, Se déconnecter. Il manque Mes revenus, Mes paiements, Missions, Notifications et Réglages. Le nom est tronqué en « Octave BAHOUN-HO… ».
- **Preuve** : `captures/connecte/menu-compte-390.png`, `captures/connecte/menu-compte-360.png`, `captures/connecte/menu-compte-desktop.png`
- **Impact** : sur mobile, ce menu est le raccourci naturel, et la page « Revenus », qui intéresse le plus un dev qui vend, n'y figure pas.
- **Correctif** : reprendre les entrées de la barre latérale dans le même ordre (Tableau de bord en premier), en ajoutant Mes revenus et Réglages. Afficher le nom sur deux lignes, ou le prénom seul.

### UX-028 · Navigation du compte sur mobile : barre d'onglets horizontale coupée de 10+ entrées
- **Sévérité** : Majeur
- **Repro** : à 360 et 390 px, sur toutes les pages de « Mon espace » (`/tableau`, `/profil`, `/copies`, `/revenus`, `/notifications`) : la barre d'onglets du haut est coupée des deux côtés (« Tableau de bord » amputé à gauche, « Mes ap… » ou « Mes paiem… » à droite). La barre de défilement native, avec ses flèches, est visible, sans dégradé ni indicateur de suite.
- **Preuve** : `captures/connecte/profil-390.png`, `captures/connecte/zooms/profil-360-p0.png`, `captures/connecte/tableau-360.png`, `captures/connecte/copies-390.png`, `captures/connecte/zooms/revenus-390-p0.png`
- **Impact** : le dev ne voit pas tout ce qui existe dans son espace (Revenus, Missions, Notifications), et le geste de défilement horizontal est peu découvrable. L'ensemble paraît bricolé.
- **Correctif** : sur mobile, remplacer la barre par un sélecteur « Mon espace ▾ : Tableau de bord » ouvrant une feuille avec toutes les entrées, ou par une page d'accueil « Mon espace » en grille, accessible depuis l'onglet « Mon espace » de la barre basse. Au minimum : masquer la barre de défilement, ajouter des dégradés sur les bords et faire défiler l'onglet actif jusqu'au centre.

### UX-029 · Onglets de filtre avec barres de défilement natives, même sur desktop
- **Sévérité** : Mineur
- **Repro** : `/copies` (Toutes / En ligne / En cours / À payer / Arrêtées) et `/notifications` (Toutes / Non lues), desktop et 390 px : de petites flèches de défilement ▲▼ apparaissent à droite de la barre, même avec 2 onglets. À 360 et 390 px, « À payer » est coupé.
- **Preuve** : `captures/connecte/copies-desktop.png`, `captures/connecte/notifications-desktop.png`, `captures/connecte/copies-390.png`
- **Impact** : défaut visuel visible partout, qui fait penser à un bug d'affichage.
- **Correctif** : passer la liste d'onglets en `overflow-x: auto` avec la barre masquée (`scrollbar-width: none`) et sans `overflow-y`, retirer la hauteur fixe à l'origine du défilement vertical, et sur mobile autoriser le retour à la ligne ou un sélecteur.

### UX-030 · `/copies` : deux cartes identiques, sans date ni raison de l'arrêt
- **Sévérité** : Mineur
- **Repro** : `/copies`, 360 / 390 / desktop : deux cartes « portfolio-open · Arrêtée · Petite · Arrêtée. Ses données ont été supprimées. Version 1. », avec le bouton « Commander à nouveau ».
- **Preuve** : `captures/connecte/copies-390.png`, `captures/connecte/copies-360.png`, `captures/connecte/copies-desktop.png`
- **Impact** : impossible de distinguer les deux copies ou de savoir pourquoi elles ont été arrêtées (impayé ? arrêt manuel ? échec ?). « Données supprimées », sans date, inquiète.
- **Correctif** : afficher sur chaque carte la date de création et d'arrêt, l'adresse (sous-domaine) et le motif (« Arrêtée par vous le … », « Arrêtée après 30 jours d'impayé le … »). Regrouper les copies arrêtées dans un historique replié, et pouvoir les retirer de la liste.

### UX-031 · Nouvelle discussion : bouton désactivé sans dire ce qui manque, dépôt « facultatif » à contre-emploi
- **Sévérité** : Majeur
- **Repro** : `/echange` → « Nouvelle discussion », desktop et 390 px. « Publier la discussion » est désactivé, aucun champ n'est marqué obligatoire (seuls « Dépôt GitHub » et « Lien de démo » portent « (facultatif) ») et aucune indication n'est donnée. L'en-tête dit « avec votre dépôt, d'autres devs peuvent proposer un correctif », alors que le dépôt est facultatif. À 390 px, le bouton d'envoi est hors écran dans la feuille et le placeholder du titre est tronqué. Pas d'aperçu Markdown.
- **Preuve** : `captures/connecte/nouvelle-discussion-desktop.png`, `captures/connecte/nouvelle-discussion-390.png`
- **Impact** : c'est l'action cœur de l'Échange (« postez un bug, un autre dev le corrige »). Le débutant ne sait pas pourquoi il ne peut pas publier, et poste sans dépôt alors que ce lien conditionne la possibilité d'un correctif.
- **Correctif** : marquer les champs obligatoires (Titre, Texte, Canal) ou valider au clic avec des messages en ligne. Afficher sous le bouton « Il manque : un canal ». Si l'étiquette « bug » est choisie, mettre en avant le champ Dépôt (« Sans dépôt, personne ne pourra proposer de correctif »). Fixer le pied de la feuille (Annuler / Publier) sur mobile et ajouter un onglet « Aperçu ».

### UX-032 · Profil : aucune incitation à le compléter, disponibilité désactivée par défaut
- **Sévérité** : Mineur
- **Repro** : `/profil`, 360 / 390 / desktop. Pays, Bio, Compétences (« 0 choisie »), Spécialités et l'interrupteur « Disponible pour une mission » (désactivé) sont tous facultatifs. Pas de jauge de complétude, pas de champ de contact (WhatsApp, téléphone), et le bouton « Enregistrer mon profil » est tout en bas.
- **Preuve** : `captures/connecte/profil-390.png`, `captures/connecte/profil-desktop.png`, `captures/connecte/zooms/profil-360-p0.png`
- **Impact** : c'est ce qui produit les profils publics « Pas disponible · Compétences non renseignées » (constat UX-012 du rapport public). Le dev débutant ne comprend pas que ces champs nourrissent sa visibilité et son Souk Score.
- **Correctif** : ajouter une jauge « Profil complété à 20 % : ajoutez 3 compétences pour apparaître dans Trouver un dev », un aperçu en direct de la carte publique, une barre d'enregistrement fixe sur mobile et un rappel au premier login.

### UX-033 · La barre de navigation basse recouvre probablement la fin du contenu
- **Sévérité** : Mineur (à confirmer)
- **Repro** : `/copies`, 360 px : le bouton « Commander à nouveau » de la 2e carte disparaît sous la barre basse (Store / Échange / Mon espace / Menu). Ailleurs, les captures pleine page ne permettent pas de trancher.
- **Preuve** : `captures/connecte/copies-360.png`
- **Impact** : le dernier bouton d'une page peut devenir intouchable sur un téléphone à petit écran ou avec une barre gestuelle.
- **Correctif** : ajouter au conteneur principal `padding-bottom: calc(hauteur de la barre + env(safe-area-inset-bottom) + 16px)` sur mobile, puis vérifier en faisant défiler jusqu'en bas chaque page de l'espace.

### UX-034 · `/publier` à 360 px : marges asymétriques, probable débordement horizontal
- **Sévérité** : Mineur (à confirmer)
- **Repro** : `/publier`, 360 px. Les cartes d'étapes et le récapitulatif ont environ 15 px de marge à gauche et environ 3 px à droite. La capture fait 345 px de large (viewport réduit par la barre de défilement).
- **Preuve** : `captures/connecte/zooms/publier-360-p0.png`, `captures/connecte/zooms/publier-360-p2.png`
- **Impact** : contenu collé au bord, voire coupé, et risque de défilement horizontal parasite pendant la saisie.
- **Correctif** : mesurer `scrollWidth` contre `innerWidth` sur `/publier` en connecté, et repérer l'élément trop large (puces de stack, champ prix + unité, cartes d'hébergement). Ajouter `min-width: 0` aux enfants de grille et flex.

### UX-035 · `/publier` à 390 px : en-tête et barre basse en version « invité »
- **Sévérité** : Mineur
- **Repro** : `/publier`, 390 px, connecté. L'en-tête n'a ni cloche ni avatar, et la barre basse affiche « Accueil / Store / Échange / Menu » au lieu de « Store / Échange / Mon espace / Menu », contrairement à `/echange` à la même largeur.
- **Preuve** : `captures/connecte/publier-390.png`, à comparer avec `captures/connecte/echange-390.png`
- **Impact** : le dev se demande s'il est déconnecté au moment de publier, et l'accès à « Mon espace » disparaît.
- **Correctif** : afficher un squelette de chargement de l'en-tête connecté tant que la session n'est pas résolue, au lieu de la variante invité. La cause est à transmettre à QA (état de session au chargement direct de `/publier`).

### UX-036 · `/revenus` desktop : liste « Pays » tronquée, chevron détaché
- **Sévérité** : Cosmétique
- **Repro** : `/revenus`, desktop : le champ « Bénin » occupe environ la moitié de la largeur, et sa flèche ▾ flotte à l'extrême droite de la carte.
- **Preuve** : `captures/connecte/revenus-desktop.png`
- **Impact** : effet de champ cassé.
- **Correctif** : donner au `select` et à son icône un même conteneur en `width: 100%`, ou une largeur fixe commune.

### UX-037 · État vide de `/revenus` : CTA « Publier une appli » alors que le dev a déjà des applis
- **Sévérité** : Cosmétique
- **Repro** : `/revenus`, état vide « Pas encore de revenus… », CTA « Publier une appli », alors que le compte a déjà des applis publiées.
- **Preuve** : `captures/connecte/zooms/revenus-390-p1.png`, `captures/connecte/revenus-desktop.png`
- **Impact** : conseil hors sujet, qui ne l'aide pas à obtenir un premier client.
- **Correctif** : adapter le CTA au contexte. Avec une appli publiée : « Partager ma fiche » ou « Passer mon appli en payant ». Sans appli : « Publier une appli ».

### UX-038 · Notifications : canal e-mail uniquement, sans retour d'enregistrement visible
- **Sévérité** : Mineur
- **Repro** : `/notifications/reglages`, desktop et 390 px : pour chaque type, deux interrupteurs (« Dans Souk.dev », « Par e-mail »). Pas de canal WhatsApp, SMS ou notification push, pas de bouton Enregistrer ni de toast visible.
- **Preuve** : `captures/connecte/notifications-reglages-desktop.png`, `captures/connecte/zooms/notifications-reglages-390-p0.png`
- **Impact** : pour un dev africain sur mobile, l'e-mail est souvent lu tard, alors qu'un correctif proposé ou un reversement refusé mérite un signal immédiat. Sans retour visuel, il doute que ses choix soient enregistrés.
- **Correctif** : ajouter un toast « Préférence enregistrée » à chaque bascule, et proposer à terme les notifications push (PWA) et/ou WhatsApp pour Correctifs, Missions et Reversements.

### UX-039 · Texte secondaire gris très petit en thème sombre
- **Sévérité** : Mineur
- **Repro** : desktop et mobile, thème sombre : les aides sous les champs de `/publier` (« Ce que fait l'appli, pour qui… », « Sa démo, en HTTPS », « 1 à 5 images… »), le sur-titre « MON ESPACE » et les légendes des cartes du tableau de bord sont en gris peu contrasté, d'environ 11–12 px à l'œil.
- **Preuve** : `captures/connecte/zooms/publier-desktop-p0.png`, `captures/connecte/zooms/publier-desktop-p1.png`, `captures/connecte/tableau-desktop.png`
- **Impact** : les consignes clés du formulaire sont les moins lisibles de l'écran, surtout sur un écran bas de gamme en extérieur.
- **Correctif** : passer les aides de champ à 13–14 px minimum, avec un contraste AA (≥ 4,5:1) en thème sombre, à vérifier à la pipette sur la couleur `--texte-secondaire`.

---

## Points positifs à préserver
- Réglages de notifications très clairs, type par type, avec « Toujours envoyé » expliqué pour les suspensions (« Il vous prévient avant la suppression des données »).
- Sur `/revenus`, la protection est bien expliquée : « Chaque changement se confirme par e-mail : une session volée ne peut pas détourner votre argent », et le numéro est saisi deux fois.
- États vides illustrés et rassurants (notifications, revenus, échange).
- Sur desktop, le récapitulatif de publication reste à droite, ce qui est un bon modèle à adapter au mobile.
- Le tableau de bord lisible : 4 indicateurs et un tableau par appli qui devient des cartes sur mobile.
- L'aide « Souk.dev les écrit pour vous » pour `soukdev.json` / `docker-compose.yml`, une très bonne idée pour un débutant à condition de la clarifier (UX-022).

## Top 5 des priorités
1. **Réparer « Mes applis » et l'entrée du parcours de publication** (UX-023 + UX-022) : une liste des applis, un sélecteur de dépôt et un guide `soukdev.json`. Preuves : `captures/connecte/publier-desktop.png`, `captures/connecte/zooms/publier-360-p0.png`
2. **Débloquer la publication sur mobile** (UX-024 + UX-025) : récap au-dessus du bouton, erreurs en ligne, interrupteur Gratuite/Payante et simulateur du prix client. Preuves : `captures/connecte/zooms/publier-360-p1.png`, `captures/connecte/zooms/publier-360-p2.png`
3. **Clarifier les reversements** (UX-026) : un seul message, une date fiable, le seuil et le rythme. Preuves : `captures/connecte/revenus-desktop.png`, `captures/connecte/zooms/revenus-390-p0.png`
4. **Refaire la navigation du compte sur mobile** (UX-028 + UX-027 + UX-029) : sélecteur ou page « Mon espace » à la place des onglets coupés, et un menu avatar complet. Preuves : `captures/connecte/profil-390.png`, `captures/connecte/menu-compte-390.png`, `captures/connecte/copies-390.png`
5. **Débloquer la création de discussion** (UX-031) : champs obligatoires signalés, dépôt mis en avant pour un bug, bouton fixe sur mobile. Preuves : `captures/connecte/nouvelle-discussion-desktop.png`, `captures/connecte/nouvelle-discussion-390.png`

## Compte par sévérité
- Bloquant : 0
- Majeur : 7 (UX-022, 023, 024, 025, 026, 028, 031)
- Mineur : 9 (UX-027, 029, 030, 032, 033, 034, 035, 038, 039)
- Cosmétique : 2 (UX-036, 037)
- **Total : 18**

## À transmettre (hors zone, une ligne chacun)
- **QA** : les chiffres de `/tableau` changent entre captures (vues 25→26, Souk Score 65→205, Débutant→Contributeur, applis 1→2 avec `audit-qa-souk-todo`), vraisemblablement à cause de l'activité concurrente des autres bots d'audit. À confirmer.
- **QA** : `/publier` à 390 px affiche l'en-tête et la barre basse « invité » alors que la session est ouverte (état de session au chargement direct).
- **Sécurité** : les entrées Finances / Serveurs / Modération sont visibles sur ce compte étiqueté « Dev ». Vérifier avec un compte dev non admin qu'elles sont masquées et protégées côté API.

## Ce qui reste non audité
- **Parcours client complet** : `/store/:id/deployer` (choix de formule, variables client, récapitulatif avec les frais de paiement), redirection SasPay (en sandbox ou simulateur), `/paiement/retour` (succès, échec, en attente), `/paiements`, `/factures` et le détail d'une facture.
- **Profil Entreprise / particulier** : connexion par lien magique (e-mail reçu, lien expiré), page d'arrivée sur le Store, son menu compte et sa navigation mobile, `/copies` avec une copie **active** (adresse, prochaine facture, mise à jour, sauvegarde), « Proposer une mission » vu côté client.
- **Côté dev, non capturé** : formulaire `/publier` rempli (états « Vérifier le dépôt » en cours, réussi ou refusé, rendu de « Souk.dev les écrit pour vous », erreurs d'analyse, secret détecté), fiche Store en vue auteur, `/missions`, « Mes paiements » côté dev, proposition d'un correctif dans une discussion, création de canal et d'événement, notifications **non vides**, thème **clair** des pages connectées, 768 px.
- **Mesures automatiques** (cibles tactiles, tailles de texte, débordements) sur les pages connectées : il faudrait une session Playwright avec un compte de test dédié.

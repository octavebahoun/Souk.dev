# Audit UX / UI / mobile : parcours CLIENT « déployer une appli » (v1)

- **Parcours** : Store → `/store/1` (portfolio-open) → `/store/1/deployer`, arrêté **avant** « Payer 3 500 F » (non cliqué, SasPay jamais atteint)
- **Date** : 10 nov. 2026, vers 03:30–03:45 (Europe/Paris, UTC+1)
- **Sources** :
  - Connecté (opérateur, desktop, thème sombre) : `captures/client/store-desktop-connecte.png`, `captures/client/fiche-1-desktop-connecte.png` (très réduite, non exploitable), `captures/client/deployer-desktop-sombre.png`, plus les textes relevés par l'opérateur.
  - Invité (mon script Playwright headless, navigateur séparé et sans cookies, celui du bureau n'a pas été touché) : `/store`, `/store/1`, `/store/1/deployer` en 360, 390 et 768, thèmes clair et sombre, en pleine page `captures/client/<page>-<largeur>-<thème>.png` et en premier écran `…-ecran1.png`. Flux invité « Déployer ma copie » → « Se connecter » : `captures/client/invite-*.png`. Mesures dans `mesures-client.json`. Aucun bouton « Payer » cliqué, aucune connexion.
- **Constats déjà faits, non répétés ici** : UX-001 (appli en vitrine avec failles), UX-002 (fiche de 14 429 px sur mobile), UX-003 (« Gratuit » en titre de prix), UX-004 (frais de paiement absents des récapitulatifs), UX-006 (CGV en brouillon), UX-007 (capture d'écran personnelle, qui sert aussi de vignette dans le récap de commande), UX-010 (jargon « copie / déployer »), UX-011 (mur de commande sans contexte).

## Synthèse (3 lignes)

1. La page de commande connectée est claire et rassurante : ce qu'on obtient, « À payer aujourd'hui 3 500 F », « puis le même montant chaque mois », « sans engagement », logos des réseaux Mobile Money.
2. Elle fait pourtant payer sans montant final (frais « affichés avant de valider », mais nulle part sur cette page), sans acceptation des CGV, sans dire qu'un impayé ou un arrêt supprime les données, et avec un palier d'hébergement imposé.
3. En invité, le parcours casse avant même la commande : « Se connecter » mène à `/connexion` sans paramètre de retour, sur l'onglet « Développeur » (GitHub). Le Store montre aussi publiquement une appli de test « Ne pas déployer ».

## Comportement de `/store/1/deployer` en invité (vérifié en headless)

| Étape | Résultat |
|---|---|
| Ouvrir `/store/1/deployer` directement | **Pas de redirection** : l'URL reste `/store/1/deployer` et la page affiche un mur « Accès réservé · Connectez-vous pour commander votre copie : elle sera à votre nom… » avec un bouton « Se connecter » (360, 390, 768, clair et sombre) |
| Sur `/store/1`, toucher « Déployer ma copie » | Lien `href="/store/1/deployer"` → même mur |
| Toucher « Se connecter » sur le mur | `href="/connexion"`, **sans paramètre de retour** (`?redirect=` ou équivalent). URL d'arrivée : `https://soukdev.shop/connexion`. Aucun élément dans `localStorage` ni `sessionStorage` |
| Page de connexion d'arrivée | Onglet **« Développeur » présélectionné** avec « Continuer avec GitHub », alors que le visiteur est en train d'acheter. Il doit lui-même passer sur « Entreprise ou particulier » |
| Retour sur la commande après connexion | **Non vérifiable sans compte.** Aucun indice côté client : à tester avec un compte Entreprise (lien magique ouvert depuis l'appli mail) |

## Mesures (invité)

| Mesure | Résultat |
|---|---|
| Débordement horizontal | **Aucun** sur les 18 rendus (3 pages × 3 largeurs × 2 thèmes) |
| CTA « Déployer ma copie » (fiche) | 48 px de haut, 17 px de texte. Haut du bouton à 695 px. **360×800** : le bas du bouton (743 px) passe sous la barre de navigation basse (64 px, qui commence à 736 px), donc il est partiellement masqué au premier écran. **390×844** et **768×1024** : visible au premier écran. « Essayer la démo » est sous la ligne de flottaison à 360 et 390 px |
| CTA « Se connecter » du mur | Au centre du premier écran, 44 px de haut environ : correct. Celui de l'en-tête fait 32 px de haut à 768 px |
| Cibles < 44 px (360) | 12 à 15 par page : liens du pied de page (16 px), fil d'Ariane (20 px), lien auteur (16 px), titres de cartes (23 px) |
| Texte < 14 px (360) | Fiche : 533 nœuds en 13 px (tableau des failles, détail du prix), badges en 12 px, barre basse en 11 px. Store : badges « Security Checked » et « Problèmes détectés » en 12 px |
| Bouton « Payer » | Absent en invité (mur), donc non mesuré en mobile |

---

## Constats

### UX-040 · « Payer 3 500 F » : le montant réellement débité est inconnu au moment du clic
- **Sévérité** : Majeur
- **Repro** : connecté, `/store/1/deployer`, desktop sombre. Le récapitulatif affiche « À payer aujourd'hui 3 500 F » et, en petit, « Frais Mobile Money ou carte en plus, affichés avant de valider ». L'étape 1 dit « les frais du moyen de paiement s'ajoutent au montant ». Le bouton s'intitule « **Payer 3 500 F** ». Aucun choix de moyen de paiement ni montant des frais sur la page : les logos (MTN MoMo, Moov, Orange Money, Wave, Celtiis, carte) sont décoratifs.
- **Preuve** : `captures/client/deployer-desktop-sombre.png`
- **Impact** : la pharmacie clique sur « Payer 3 500 F » et voit chez SasPay un autre montant, sans savoir combien ni pourquoi. Le bouton annonce un prix qui n'est pas celui qu'elle paiera, ce qui provoque abandons et réclamations. C'est le prolongement de UX-004, au moment le plus sensible.
- **Correctif** : soit choisir le moyen de paiement sur cette page et afficher « Frais MTN MoMo : 53 F · Total débité : 3 553 F », avec un bouton « Payer 3 553 F » ; soit renommer le bouton « Continuer vers le paiement » et afficher la fourchette (« frais opérateur de 1 à 3 %, environ 35 à 105 F ») juste au-dessus. Préciser aussi si les frais s'ajoutent chaque mois.

### UX-041 · Aucune acceptation des CGV avant de payer
- **Sévérité** : Majeur
- **Repro** : connecté, `/store/1/deployer`. Ni case à cocher ni mention « En payant, vous acceptez… » près du bouton. Le lien « Conditions de vente » n'est que dans le pied de page, et ces CGV sont marquées « Brouillon, pas de valeur contractuelle » (UX-006).
- **Preuve** : `captures/client/deployer-desktop-sombre.png`, `captures/cgv-360.png`
- **Impact** : le client s'engage sur un abonnement mensuel sans avoir vu les règles (facturation, impayé, suppression des données, remboursement). En cas de litige, rien ne prouve qu'il les a acceptées, et il n'a aucun moyen simple de les lire au bon moment.
- **Correctif** : sous le bouton, ajouter « En payant, vous acceptez les Conditions de vente et d'utilisation » (liens ouverts dans un panneau, sans quitter la page), ou une case obligatoire. Enregistrer la version acceptée avec la commande. Prérequis : des CGV validées (UX-006).

### UX-042 · Ce qui arrive aux données en cas d'impayé ou d'arrêt n'est pas dit
- **Sévérité** : Majeur
- **Repro** : connecté, `/store/1/deployer`, bloc « Ce que vous obtenez » : « Vos données gardées tant que l'abonnement est réglé » et « Arrêt à tout moment depuis « Mes copies », sans engagement ». Rien sur les 7 jours de grâce, la suspension, la **suppression définitive après 30 jours** (CGV §3), ni sur le fait qu'**arrêter supprime les données** (voir les copies arrêtées : « Arrêtée. Ses données ont été supprimées. »). Rien non plus sur l'export ou la sauvegarde.
- **Preuve** : `captures/client/deployer-desktop-sombre.png`, `captures/connecte/copies-390.png`, `captures/cgv-360.png`
- **Impact** : une association qui oublie un paiement, ou qui arrête pour « mettre en pause », peut perdre ses fichiers de membres ou son stock sans l'avoir compris. C'est le risque le plus grave pour un client non technique.
- **Correctif** : ajouter une ligne claire dans « Ce que vous obtenez » : « Si un paiement manque : 7 jours de grâce, puis copie suspendue (données gardées 30 jours), puis suppression. Arrêter la copie supprime ses données : exportez-les d'abord. » Ajouter un lien « Comment récupérer mes données ? » et, dans `/copies`, une confirmation forte avant l'arrêt.

### UX-043 · « Comment ça se passe » : étapes « à venir » ambiguës, cas d'échec absent
- **Sévérité** : Mineur
- **Repro** : connecté, `/store/1/deployer`, bloc « Comment ça se passe » : 1 « Vous payez chez SasPay », 2 « Nous construisons votre copie (quelques minutes) », 3 « Votre copie est en ligne… facture suivante un mois plus tard, rappel 3 jours avant ». L'opérateur relève la mention « — à venir » sur les 3 étapes. Elle n'est pas visible sur la capture desktop, donc probablement réservée aux lecteurs d'écran ; c'est à confirmer dans le DOM connecté.
- **Preuve** : `captures/client/deployer-desktop-sombre.png`
- **Impact** : « à venir » peut se lire « fonctionnalité pas encore disponible » (surtout à la synthèse vocale), ce qui fait douter que le service marche. Rien ne dit non plus ce qui se passe si la construction échoue après paiement (remboursement ? nouvel essai ?).
- **Correctif** : remplacer « à venir » par un stepper explicite (« Étape 1 sur 3 · Ensuite… »), avec un texte accessible du type « étape 1 sur 3, pas encore commencée ». Ajouter « Si la mise en ligne échoue, vous n'êtes pas facturé / vous êtes remboursé sous X jours » et « Nous vous prévenons par e-mail quand c'est prêt ».

### UX-044 · Palier d'hébergement imposé, sans explication ni évolution possible
- **Sévérité** : Mineur
- **Repro** : connecté, `/store/1/deployer`, récapitulatif : « Hébergement de votre copie · capacité petite (512 Mo de mémoire) · 3 500 F/mois », sans choix. Les CGV et `/publier` mentionnent pourtant trois formules (Petite, Moyenne, Grande).
- **Preuve** : `captures/client/deployer-desktop-sombre.png`
- **Impact** : le client ne sait pas si « 512 Mo » suffira pour ses 3 caisses ou ses 200 adhérents, ni s'il pourra monter en gamme sans tout perdre. Il hésite, ou il le découvre trop tard.
- **Correctif** : afficher la formule recommandée par l'auteur, avec le lien « Changer » vers Moyenne ou Grande et leurs prix. Traduire en usage (« Petite : idéal jusqu'à ~N utilisateurs simultanés ») et ajouter « Vous pourrez changer de formule plus tard depuis Mes copies » si c'est vrai.

### UX-045 · Une appli de test « Ne pas déployer » est publique et en tête du Store
- **Sévérité** : Majeur
- **Repro** : `/store` en invité (360 / 390 / 768, clair et sombre) et connecté (desktop). « 2 applis » : la première, triée par « Les plus récentes », est **audit-qa-souk-todo** (« Appli de test d'audit QA (todo-list). Ne pas déployer. », badge « Security Checked », « Gratuit »). Sa vignette est elle aussi une capture brute de navigateur.
- **Preuve** : `captures/client/zoom-store-360-sombre-cartes.png`, `captures/client/store-360-clair.png`, `captures/client/store-desktop-connecte.png`
- **Impact** : le client voit qu'une appli sur deux est un test interne qu'il ne faut pas acheter. Le Store paraît vide et amateur. S'il la commande quand même, il paiera 3 500 F/mois pour rien.
- **Correctif** : dépublier tout de suite cette appli, ou la passer en « non listée ». Pour les audits, prévoir un statut « brouillon / privé » ou un environnement de recette, et un drapeau `listed=false` exclu du Store, de la recherche et de l'accueil.

### UX-046 · Badge « Security Checked » en anglais, à côté de « Problèmes détectés »
- **Sévérité** : Cosmétique
- **Repro** : `/store`, toutes largeurs, carte audit-qa-souk-todo : « Security Checked » (vert, 12 px), alors que l'autre carte affiche « Problèmes détectés » et que tout le site est en français.
- **Preuve** : `captures/client/zoom-store-360-sombre-cartes.png`, `captures/client/store-desktop-connecte.png`
- **Impact** : incohérence de langue et de ton. Le client non technique ne comprend pas forcément le terme anglais.
- **Correctif** : traduire, par exemple « Analysée · aucun problème » ou « Sécurité vérifiée », et centraliser les libellés de badge dans le fichier de traduction.

### UX-047 · Invité : le retour vers la commande est perdu, et on arrive sur l'onglet « Développeur »
- **Sévérité** : Majeur
- **Repro** : invité, 390 px. Sur `/store/1`, toucher « Déployer ma copie » → mur « Accès réservé » sur `/store/1/deployer`. Toucher « Se connecter » → `/connexion` (lien sans paramètre de retour, rien en `localStorage` ni `sessionStorage`), avec l'onglet « Développeur · Continuer avec GitHub » présélectionné.
- **Preuve** : `captures/client/invite-clic-deployer-390.png`, `captures/client/invite-gate-vers-connexion-390.png`, `captures/client/deployer-390-clair-ecran1.png`
- **Impact** : la pharmacie qui veut acheter se voit proposer GitHub et doit deviner qu'il faut passer sur « Entreprise ou particulier ». Après le lien magique (ouvert depuis son appli mail, souvent dans un autre onglet), elle risque d'atterrir sur le Store au lieu de sa commande. L'élan d'achat se perd au pire moment.
- **Correctif** : passer `?retour=/store/1/deployer&profil=entreprise` au lien « Se connecter », présélectionner l'onglet « Entreprise ou particulier » quand on vient d'une commande, et encoder le retour dans le lien magique côté serveur pour qu'il survive au changement d'onglet ou d'appareil. Mieux : afficher directement le formulaire e-mail sur le mur de commande, sans détour par `/connexion`.

### UX-048 · À 360 px, le CTA « Déployer ma copie » est à moitié caché par la barre basse au premier écran
- **Sévérité** : Mineur
- **Repro** : invité, `/store/1`, 360×800, clair ou sombre. Le bouton occupe la zone de 695 à 743 px, et la barre basse fixe commence à 736 px. « Essayer la démo » est hors écran, et il n'y a pas de CTA collant au défilement. À 390 et 768 px, le CTA est visible.
- **Preuve** : `captures/client/fiche-1-360-clair-ecran1.png`, `captures/client/fiche-1-360-sombre-ecran1.png`, `captures/client/fiche-1-390-clair-ecran1.png`
- **Impact** : sur les petits Android courants, l'action principale n'est pas franchement visible à l'arrivée. Ensuite, elle disparaît pendant les ~13 écrans de la fiche (UX-002).
- **Correctif** : ajouter sur mobile une barre d'action collante au-dessus de la barre basse (« 3 500 F/mois · Obtenir cette appli »), ou remonter le bloc prix (réduire l'en-tête et les puces de stack). Garder « Essayer la démo » visible à côté.

### UX-049 · La commande ne recueille ni identité de facturation ni adresse de la copie
- **Sévérité** : Mineur
- **Repro** : connecté, `/store/1/deployer` : aucun champ pour le nom ou la raison sociale, l'IFU ou l'adresse de facturation. « Une adresse web à vous » est promise sans être montrée (sous-domaine imposé ou à choisir ?). Aucune variable client n'apparaît non plus, peut-être parce que cette appli n'en a pas.
- **Preuve** : `captures/client/deployer-desktop-sombre.png`
- **Impact** : une pharmacie ou une association a besoin d'une facture à son nom pour sa comptabilité, et veut savoir quelle adresse donner à son équipe. Elle doit demander après coup, ou ne commande pas.
- **Correctif** : ajouter un bloc « Facturer à » (nom ou structure, IFU facultatif), prérempli depuis le compte et modifiable. Afficher l'adresse prévue (« pharmacie-du-port.soukdev.shop », éventuellement modifiable) et, si l'appli a des variables, les demander ici avec une aide en langage simple.

---

## Points positifs à préserver
- Le récapitulatif de commande est net : appli « Gratuit », hébergement 3 500 F/mois, **« À payer aujourd'hui 3 500 F »**, « Puis le même montant chaque mois ».
- Le bloc « Ce que vous obtenez » est rassurant et concret : copie isolée, adresse web, sans engagement.
- La facture suivante et le rappel 3 jours avant sont annoncés dès la commande.
- La liste des moyens de paiement locaux (MTN, Moov, Orange, Wave, Celtiis, carte) avec leurs logos, et le rappel « Souk.dev ne prend aucun pourcentage ».
- Aucun débordement horizontal sur `/store`, `/store/1` et `/store/1/deployer`, à aucune largeur ni dans aucun thème.

## Top 3 des priorités
1. **Payer en connaissance de cause** (UX-040 + UX-041 + UX-042) : total frais inclus sur le bouton, acceptation des CGV, conséquences d'un impayé ou d'un arrêt sur les données. Preuve : `captures/client/deployer-desktop-sombre.png`
2. **Ne pas perdre l'acheteur à la connexion** (UX-047) : paramètre de retour, onglet Entreprise présélectionné, retour encodé dans le lien magique. Preuves : `captures/client/invite-gate-vers-connexion-390.png`, `captures/client/deployer-390-clair-ecran1.png`
3. **Nettoyer le Store** (UX-045 + UX-046) : dépublier l'appli de test et traduire le badge. Preuves : `captures/client/zoom-store-360-sombre-cartes.png`, `captures/client/store-desktop-connecte.png`

## Compte par sévérité
- Bloquant : 0
- Majeur : 5 (UX-040, 041, 042, 045, 047)
- Mineur : 4 (UX-043, 044, 048, 049)
- Cosmétique : 1 (UX-046)
- **Total : 10**

## À transmettre (hors zone)
- **Paiement** : vérifier chez SasPay (sandbox) le montant réellement débité par rapport au « 3 500 F » du bouton, et si les frais sont refacturés chaque mois.
- **QA** : l'appli `audit-qa-souk-todo` créée pendant l'audit est publique ; à retirer à la fin de l'audit, ou à créer en non listée.

## Ce qui reste non audité
- **Commande connectée sur mobile** (360 / 390 / 768) et en thème clair : position du bouton « Payer », ordre récap / étapes sur petit écran, tailles des cibles. Seul le desktop sombre a été observé.
- **Parcours complet avec un compte Entreprise de test** : lien magique, retour effectif sur `/store/1/deployer`, page SasPay en sandbox (affichage des frais, choix du réseau, saisie du numéro, code de confirmation), `/paiement/retour` (succès, échec, en attente, abandon), facture générée, puis `/copies` avec une copie **en construction** puis **en ligne**.
- **États d'erreur de la commande** : appli indisponible, construction échouée, paiement en double, session expirée pendant le paiement.
- **Une appli avec variables client** (champs de configuration à la commande) et une appli **payante** (prix mensuel ou unique + hébergement).

---

## Complément SasPay (10/11/2026, 11 h 30, accord d'Octave) : clic sur « Payer 3 500 F », arrêt sur SasPay sans rien saisir, puis retour

Constat factuel : redirection vers `checkout.saspay.me/<jeton masqué>` (titre « Paiement — SasPay »). La facture SD-2026-000003 a été créée (impayée). Montant affiché : 3 500 XOF + 123 XOF de frais = **3 623 XOF**. Moyens proposés : Moov Money Bénin (présélectionné), Celtiis Cash Bénin, MTN MoMo Bénin. Carte désactivée (« Contact us to enable this payment method »). Crypto/Stablecoin +0,20 USD. Page en anglais par défaut (FR disponible). Pas de lien d'annulation, pas de minuteur, pas de CGV ni de mention de remboursement. Libellé « to Gentube ». Capture : `captures/saspay/saspay-checkout-desktop.png`.

| ID | Sévérité | Constat | Impact | Correctif |
|---|---|---|---|---|
| UX-050 | Majeur | Le bénéficiaire affiché par SasPay est « Gentube », pas Souk.dev | Le client croit payer un autre site : abandon ou litige | Configurer le compte marchand SasPay au nom de Souk.dev (ou d'une entité clairement liée), avec logo |
| UX-051 | Majeur | Le total réel (3 623 XOF) n'apparaît qu'une fois chez SasPay. Le bouton Souk.dev dit 3 500 F | Écart de prix perçu comme des frais cachés (confirme UX-040) | Afficher « 3 500 F + 123 F de frais Mobile Money = 3 623 F » sur /deployer, avant le clic |
| UX-052 | Majeur | La page de paiement s'ouvre en anglais | Une pharmacie ou une association francophone ne comprend pas ce qu'elle valide | Passer `locale=fr` à la création du checkout SasPay |
| UX-053 | Mineur | Aucun lien d'annulation ni de retour vers Souk.dev, aucune mention de remboursement ni de CGV | Le client est bloqué, ne sait pas comment revenir et n'est pas rassuré | Renseigner l'URL d'annulation et l'URL de retour, et ajouter le lien vers les CGV de Souk.dev |
| UX-054 | Mineur | Carte affichée mais désactivée (« Contact us… ») ; crypto avec frais en USD à côté d'un total en XOF | Bruit et confusion, impression d'un service inachevé | Masquer les moyens non activés et la crypto pour le public cible, ou les expliquer en FCFA |
| UX-055 | Mineur | Moov Money est présélectionné | Le client paie peut-être avec un opérateur qu'il n'a pas choisi | Aucune présélection, ou présélection selon le préfixe du numéro |

Suivi hors de ma zone, pour Paiement/QA : la facture SD-2026-000003 reste en attente. Vérifier qu'elle expire ou s'annule et qu'aucune copie n'est déployée sans paiement.

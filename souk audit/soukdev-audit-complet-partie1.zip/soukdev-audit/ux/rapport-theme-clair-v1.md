# Souk.dev : audit UX en thème clair (pages connectées) et /missions, v1

Date : 10/11/2026, 12 h 56. Compte octavebahoun, avec l'accord d'Octave. Navigation en lecture seule : rien n'a été soumis ni payé. Bureau en 1280 px.

| ID | Sévérité | Page | Constat | Impact | Correctif |
|---|---|---|---|---|---|
| ~~UX-056~~ | **Retiré** | / | Non reproduit le 10/11 à 13 h 02 : hero lisible en thème clair (texte blanc sur fond sombre, capture `captures/clair/accueil-hero-clair-reverif.png`). La première capture avait été prise avant la fin des animations d'apparition (délai de 80 à 320 ms). | Aucun | Facultatif : afficher le texte même avant l'animation, pour les appareils lents |
| UX-057 | Majeur | /store/1/deployer | Les logos affichés sous le bouton Payer incluent Orange Money, Wave et la carte bancaire. Or SasPay ne proposait que Moov, Celtiis et MTN, avec la carte désactivée | Le client choisit Souk.dev pour Orange Money ou Wave et ne les trouve pas au moment de payer | N'afficher que les moyens réellement actifs pour le pays, en synchronisant cette liste avec SasPay |
| UX-058 | Mineur | /store/1/deployer | « Comment ça se passe » présente SasPay comme une étape « à venir », alors que le bouton Payer est actif et qu'une commande attend déjà | Il est difficile de savoir si le paiement marche déjà | Mettre l'étape au présent (« 1. Vous payez chez SasPay ») et retirer toute mention « à venir » |
| UX-059 | Mineur | /tableau | « Souk Score 205/1000 » et l'XP ne sont pas expliqués. « 3 déploiements » s'affiche à côté de « 0 copie active ». Une carte a un contour bleu plus marqué que les autres sans raison apparente | On ne comprend pas ce qui est mesuré, et l'état sélectionné de la carte est ambigu | Ajouter une info-bulle ou un lien « Comment c'est calculé », distinguer les déploiements tentés des copies actives, et uniformiser les contours |
| UX-060 | Mineur | /missions | L'état vide est clair, mais rien ne dit ce qui différencie « Personnaliser une appli » de « Recruter un dev », ni combien ça coûte | Un client non technique ne sait pas quoi choisir | Ajouter une phrase et une fourchette de prix ou de délai sous chaque option |
| UX-061 | Mineur | /copies | « Commander à nouveau » ne précise pas que l'action crée une nouvelle commande payante | Risque de commande ou de facture créée par erreur | Renommer en « Recommander (nouvelle copie, 3 500 F/mois) » ou ajouter une confirmation |
| UX-062 | Cosmétique | Toutes | En thème clair, les bordures sont fines et peu contrastées, et les textes d'aide en petite taille sont pâles | Lecture fatigante, surtout sur un téléphone en plein soleil | Renforcer le contraste des bordures et des textes secondaires (vérification réservée à Perf SEO) |

Déjà signalés et confirmés en thème clair : « Gratuit » face aux 3 500 F/mois (UX-003), « Security Checked » en anglais (UX-046), le « 15 000 » de /publier qu'on confond avec une valeur saisie (UX-024), le récapitulatif « À renseigner » sur /publier, et la contradiction sur la date de reversement dans /revenus.

Information utile pour Paiement : /store/1/deployer indique désormais « Une commande attend déjà votre paiement… Sans paiement, elle s'annule d'elle-même au bout de 7 jours », avec un lien « Annuler cette commande ». La facture SD-2026-000003 devrait donc expirer d'elle-même. L'annulation manuelle n'a pas été cliquée : la décision revient à Octave.

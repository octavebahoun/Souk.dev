# Audit UX / UI / mobile : pages publiques de Souk.dev (v1)

- **Cible** : https://soukdev.shop (sans compte, lecture seule : aucun compte créé, aucune connexion, y compris GitHub OAuth, aucun formulaire soumis, aucun paiement)
- **Date** : 10 nov. 2026, vers 01:30–02:00 (Europe/Paris, UTC+1)
- **Outil** : Playwright (Python) + Chromium sur le box, `is_mobile`/`has_touch` sous 768 px, locale fr-FR
- **Largeurs** : 360x800, 390x844, 768x1024 (prioritaires) + 1440x900 (en complément)
- **Thèmes** : clair sur toutes les pages ; sombre (`prefers-color-scheme: dark`, le site suit le thème « Système » par défaut, avec bascule Clair / Sombre / Système dans l'en-tête et le menu) sur les 8 pages clés (accueil, store, fiche, déployer, connexion, échange, devs, 404) en 360/390/768
- **Pages couvertes (d'après CARTE.md)** : `/`, `/store`, `/store/1`, `/store/1/deployer`, `/echange`, `/devs`, `/devs/octavebahoun`, `/evenements`, `/connexion`, `/connexion?profil=dev` (+ onglet « Entreprise ou particulier » affiché, rien soumis), `/publier`, `/copies`, `/paiements`, `/missions`, `/legal/cgu`, `/legal/cgv`, `/legal/confidentialite`, `/legal/abus`, URL bidon (404). `/canaux`, `/etiquettes`, `/apps` affichent la 404 en invité, `/profil` affiche le mur de connexion.
- **Captures** : `/workspace/soukdev-audit/ux/captures/<page>-<largeur>[-sombre].png` (110 captures pleine page), zooms de lecture dans `captures/zooms/`, mesures brutes dans `/workspace/soukdev-audit/ux/mesures.json`

## Synthèse

1. La base visuelle est **solide** : aucun débordement horizontal (0 sur 100 rendus), aucune image cassée, design system cohérent, thème sombre réussi, états vides soignés, français globalement excellent.
2. Côté **client**, la confiance s'effondre : la seule appli du Store est marquée « Problèmes détectés » (61 failles, dont 1 critique), elle est mise en vitrine et sa capture d'écran est une capture brute d'un navigateur personnel.
3. Le **« qui paie quoi »** est clair sur l'accueil, mais pas sur la fiche ni sur les cartes : le prix affiché est « Gratuit » alors que le total est de 3 500 F/mois, et les frais de paiement annoncés par les CGV n'apparaissent nulle part.
4. Il n'y a **ni contact, ni support, ni éditeur identifié**, et les 4 textes légaux portent la mention « Brouillon, pas de valeur contractuelle ».
5. Le **dev débutant** qui clique sur « Publier une appli » tombe sur un mur « Accès réservé », sans aucun guide des prérequis. Sur mobile et tablette, ce CTA et la recherche manquent dans la navigation.

## Mesures automatiques (résumé)

| Mesure | Résultat |
|---|---|
| Débordement horizontal (`scrollWidth > innerWidth`) | **Aucun** sur les 19 pages × 4 largeurs × 2 thèmes |
| Images cassées | **Aucune** (images en `loading=lazy`, elles se chargent bien au défilement) |
| Cibles tactiles < 44 px (360 px) | 12 à 23 par page : liens du pied de page (16 px de haut), fil d'Ariane (20 px), lien auteur (16 px), case « Disponibles seulement » (20×20), liens de dépôts sur un profil (24 px), carte Store (lien du titre, 23 px) |
| Texte < 14 px (360 px) | 13 px très courant (puces, méta, détail du prix, tableau des failles : 533 nœuds de texte sur la fiche), 12 px (sur-titres, badges), **11 px** (barre de navigation du bas, « Souk Score », badges de profil) |
| Console | Une erreur 401 par page en invité (appel de session `/api/me`) : à transmettre à QA/API, sans impact visible |
| Temps de chargement (box, bonne connexion) | événement `load` entre 0,8 et 1,7 s, réseau calme entre 2,4 et 4,9 s (la fiche est la plus lente). Ce n'est pas représentatif d'une 3G : le chiffrage revient au bot Perf |
| Accessibilité de base | `lang="fr"`, lien d'évitement « Aller au contenu », anneau de focus clavier bien visible (`captures/focus-clavier-360.png`), bouton de thème avec libellé accessible |
| Formulaire visible sans compte | Connexion « Entreprise » : champ `type=email`, `autocomplete=email`, 44 px de haut, police de 15 px (pas de zoom iOS) : correct |

**À transmettre (hors zone)** : la 404 renvoie HTTP 200 (soft-404 → Perf SEO) ; 401 sur `/api/me` à chaque page anonyme (→ QA/API).

---

## Constats

### UX-001 · L'unique appli en vitrine est marquée « Problèmes détectés » (61 failles, dont 1 critique)
- **Sévérité** : Majeur
- **Repro** : https://soukdev.shop/, `/store` et `/store/1`, 360 / 390 / 768 / 1440, thèmes clair et sombre. Ouvrir l'accueil et descendre jusqu'à « Dans le Store » : la seule carte affiche un badge orange « Problèmes détectés ». Sur la fiche, on lit « Sécurité : Problèmes détectés… 61 dépendances ont une faille connue », avec une gravité **Critique** en tête.
- **Preuve** : `captures/zooms/accueil-360-p1.png`, `captures/zooms/store-360-p0.png`, `captures/zooms/fiche-appli-360-p1.png`, `captures/fiche-appli-1440.png`
- **Impact** : pour le client non technique, la première (et unique) appli qu'on lui montre a l'air dangereuse : il en conclut que le Store n'est pas sûr. Pour le dev, c'est une sanction publique sans accompagnement.
- **Correctif** : ne pas mettre en vitrine sur l'accueil une appli avec des failles hautes ou critiques. Distinguer « Critique : correction requise » (masquée du Store ou non déployable) de « Mises à jour conseillées ». Côté client, reformuler en langage simple (« Des mises à jour de sécurité sont en attente chez l'auteur ») et donner un niveau de risque global plutôt qu'un badge alarmant. Côté dev, proposer un bouton « Corriger avec l'Échange » ou un guide `npm audit fix`.

### UX-002 · Fiche appli démesurée sur mobile : 14 429 px de haut, à cause du tableau des 61 failles déplié
- **Sévérité** : Majeur
- **Repro** : `/store/1`, 360 px, thème clair ou sombre. Faire défiler la page : 61 cartes CVE s'enchaînent (Version / Gravité / Faille / Corrigée en) avant « Mémoire mesurée », « Avis des clients », « Versions » et « Discussions ».
- **Preuve** : `captures/fiche-appli-360.png` (360×14 429), `captures/zooms/fiche-appli-360-sombre-p2.png`, `captures/zooms/fiche-appli-360-fin.png`
- **Impact** : sur un mobile moyen et une connexion lente, les infos utiles au client (avis, versions, questions) sont enfouies après environ 13 écrans de jargon. Le dev voit sa fiche dominée par ses défauts.
- **Correctif** : afficher un résumé (« 1 critique · 24 hautes · 36 moyennes ») et un accordéon fermé « Voir le détail (61) », regrouper par paquet (axios ×12 → une ligne « axios 1.14.0 → 1.20.0 »), placer la section après les avis, et réserver le détail CVE à la vue auteur ou à un lien « rapport complet ».

### UX-003 · « Gratuit » affiché comme prix alors que le client paiera 3 500 F/mois
- **Sévérité** : Majeur
- **Repro** : `/store` et `/` (carte : « Gratuit »), puis `/store/1`, 360 px : le gros titre du bloc prix dit « Gratuit », et le total en petit dit « Total par mois 3 500 F ».
- **Preuve** : `captures/zooms/fiche-appli-360-p0.png`, `captures/zooms/fiche-appli-768-p0.png`, `captures/zooms/store-360-p0.png`
- **Impact** : le client (une pharmacie, par exemple) croit que c'est gratuit et découvre l'abonnement au moment de commander, ce qui coûte en confiance et en abandons. Le détail du bloc prix est pourtant exemplaire : c'est la hiérarchie qui trompe.
- **Correctif** : mettre en titre le **total** (« 3 500 FCFA / mois ») et la mention « Appli gratuite + hébergement » en sous-titre. Sur les cartes du Store, afficher « Dès 3 500 FCFA/mois » (ou « Appli gratuite · hébergement dès 3 500 F/mois »). Le tri « Prix croissant » et le filtre « Prix maximum » doivent porter sur le total mensuel, ou le préciser.

### UX-004 · Les frais de paiement Mobile Money ne figurent dans aucun récapitulatif
- **Sévérité** : Majeur
- **Repro** : `/legal/cgv`, article 1 : « Les frais de paiement s'ajoutent au total payé par le client ». Or `/store/1` affiche « Commission Souk.dev 0 F · Total par mois 3 500 F », sans ligne de frais, et l'accueil (« Qui paie quoi ? ») n'en parle pas non plus.
- **Preuve** : `captures/cgv-360.png`, `captures/zooms/fiche-appli-360-p0.png`, `captures/zooms/accueil-360-p2.png`
- **Impact** : le client paie plus que le « total » annoncé, ce qui fait douter de l'argument « transparent, 0 % ». C'est un risque de litige.
- **Correctif** : ajouter dans le bloc prix la ligne « Frais de paiement (Mobile Money/carte) : ~x % » ou « + frais de l'opérateur », et l'ajouter aussi à la carte « Qui paie quoi ? » de l'accueil. À vérifier ensuite sur l'écran de commande connecté.

### UX-005 · Aucun moyen de contacter Souk.dev, aucun éditeur identifié
- **Sévérité** : Majeur
- **Repro** : pied de page de toutes les pages (360 → 1440) : rubriques Produit / Communauté / Légal, sans aucune entrée Contact, Support, À propos, FAQ ni mentions légales. Sur `/legal/confidentialite` §5, on lit « écrivez à l'équipe depuis votre adresse de compte », mais aucune adresse n'est donnée.
- **Preuve** : `captures/zooms/accueil-360-p2.png`, `captures/confidentialite-360.png`, `captures/echange-1440.png`
- **Impact** : un client qui va payer chaque mois ne sait ni qui est derrière le service ni qui appeler en cas de panne. Un dev ne sait pas à qui écrire pour une question sur un reversement. C'est un frein majeur à l'achat.
- **Correctif** : ajouter une page Contact (e-mail de support, WhatsApp, délai de réponse) et une page Mentions légales/À propos (éditeur, pays, n° RCCM/IFU, hébergeur), avec des liens dans le pied de page et le menu mobile. Mentionner aussi le support dans le bloc prix de la fiche.

### UX-006 · Les 4 textes légaux portent le bandeau « Brouillon, pas de valeur contractuelle »
- **Sévérité** : Majeur
- **Repro** : `/legal/cgu`, `/legal/cgv`, `/legal/confidentialite` et `/legal/abus`, toutes largeurs : encadré « Brouillon à faire valider par un juriste ».
- **Preuve** : `captures/cgu-360.png`, `captures/cgv-360.png`, `captures/cgu-1440.png`
- **Impact** : le client et le dev qui lisent les conditions avant de payer ou de vendre comprennent que rien ne les protège.
- **Correctif** : faire valider les textes, puis retirer le bandeau et dater la version (« En vigueur au … »). D'ici là, éviter d'ouvrir les paiements réels, ou ajouter une mention de bêta avec un engagement explicite (remboursement, contact).

### UX-007 · La capture de l'appli est une capture brute d'un navigateur personnel, sans rapport avec l'appli
- **Sévérité** : Majeur
- **Repro** : `/store/1` (et vignettes sur `/store` et `/`), toutes largeurs. La première capture montre la barre d'onglets personnelle (messagerie, réseaux…), une URL de site tiers contenant un paramètre e-mail (tronqué) et une page de commande d'un service tiers, au lieu du portfolio.
- **Preuve** : `captures/zooms/capture-appli-1-haut.png`, `captures/zooms/fiche-appli-768-p0.png`, `captures/zooms/store-360-p0.png`
- **Impact** : il y a une fuite d'informations personnelles de l'auteur. Le client ne voit pas à quoi ressemble l'appli, et l'ensemble paraît amateur.
- **Correctif** : remplacer immédiatement la capture. Côté produit, publier un guide des captures (format, sans barre de navigateur), proposer un recadrage et un aperçu à l'envoi avec l'avertissement « vérifiez qu'aucune donnée personnelle n'apparaît », voire générer les captures automatiquement depuis la démo.

### UX-008 · Parcours du dev débutant : « Publier une appli » mène à un mur sans explication
- **Sévérité** : Majeur
- **Repro** : en invité, à 360 px, cliquer sur « Publier une appli » (en-tête desktop ou pied de page) → `/publier` affiche « Accès réservé · Cet espace est celui de votre compte… ». « Je suis dev » mène directement à `/connexion`. Le bloc du Store dit « ajoutez un soukdev.json » sans lien.
- **Preuve** : `captures/publier-360.png`, `captures/publier-1440.png`, `captures/zooms/store-360-p0.png`
- **Impact** : le débutant ne sait pas ce qu'il lui faut avant de se connecter (dépôt public, `soukdev.json`, Docker, limite d'un service web et de 2 Go, prix). Il se connecte « à l'aveugle » ou abandonne. Le terme « MON ESPACE » le désoriente aussi.
- **Correctif** : rendre `/publier` lisible sans compte, avec les étapes, une checklist des prérequis, un exemple de `soukdev.json` téléchargeable, les règles de l'analyse (secret = refus, failles = badge), une FAQ « combien je gagne » et, en bas, « Continuer avec GitHub ». Ajouter un lien « Qu'est-ce que soukdev.json ? » sur le Store.

### UX-009 · Sur mobile et tablette, « Publier une appli » et la recherche disparaissent de la navigation
- **Sévérité** : Majeur
- **Repro** : à 360 et 390 px, ouvrir « Menu » (barre du bas) : on y trouve Store, Échange, Trouver un dev, Événements, Thème et Se connecter, mais **pas** « Publier une appli » ni « Rechercher ». À 768 px, l'en-tête n'a ni recherche ni « Publier une appli », et il n'y a pas de menu.
- **Preuve** : `captures/menu-ouvert-360.png`, `captures/menu-ouvert-390-sombre.png`, `captures/zooms/accueil-768-sombre-p0.png`, à comparer avec `captures/zooms/accueil-1440-p0.png`
- **Impact** : le dev sur mobile (cas majoritaire) perd le CTA principal du produit. Le client ne peut chercher qu'en passant par la page Store.
- **Correctif** : ajouter « Publier une appli » (CTA en évidence) et la recherche dans le menu mobile. À 768 px, garder la recherche (icône) et le CTA, quitte à replier les liens secondaires dans un menu.

### UX-010 · Jargon technique sur le parcours d'achat du client non technique
- **Sévérité** : Majeur
- **Repro** : `/`, `/store`, `/store/1`, 360 px : « une entreprise la **déploie** en un clic », « chaque client a sa **copie isolée** », « **Déployer ma copie** », « Hébergement Petite (**512 Mo**) », « Mémoire mesurée · Pic de mémoire 4 Mo ». Dans les CGV : « conteneurs arrêtés, page neutre sur le **sous-domaine** ».
- **Preuve** : `captures/zooms/fiche-appli-360-p0.png`, `captures/zooms/fiche-appli-360-fin.png`, `captures/zooms/accueil-360-p0.png`
- **Impact** : une pharmacie ou une association ne comprend pas ce qu'elle achète (« une copie ? », « 512 Mo, c'est assez ? ») et hésite à commander.
- **Correctif** : côté client, parler de « votre version privée de l'appli », utiliser le bouton « Obtenir cette appli » ou « Commander », et traduire les formules en usages (« Petite : jusqu'à ~X utilisateurs »). Garder le vocabulaire technique pour la vue dev ou dans une infobulle « Comment ça marche ? ».

### UX-011 · Mur de connexion de la commande : le contexte est perdu
- **Sévérité** : Mineur
- **Repro** : sur `/store/1`, cliquer sur « Déployer ma copie » en invité (ou ouvrir `/store/1/deployer`), 360 px, en clair ou en sombre : la page « Accès réservé » ne rappelle ni l'appli ni le prix, n'a pas de lien retour vers la fiche, et son titre n'est pas un `<h1>` (aucun h1 détecté).
- **Preuve** : `captures/deployer-360.png`, `captures/deployer-360-sombre.png`
- **Impact** : le client doute (« c'était bien la bonne appli ? ») et perd son élan d'achat.
- **Correctif** : afficher un récapitulatif compact (nom, total mensuel), un lien « ← Retour à la fiche » et un titre en h1. Ramener sur la commande après connexion, ce qui reste à vérifier en parcours connecté.

### UX-012 · La place de marché paraît vide, et les sections vides sont mises en avant
- **Sévérité** : Majeur
- **Repro** : `/` (« Dans le Store » : 1 carte ; « Aucune discussion publique publiée pour le moment »), `/echange` (0 discussion), `/evenements` (aucun événement), `/devs` (3 devs, tous « Pas disponible · Débutant · Compétences non renseignées · 0 bug résolu »). 360 px.
- **Preuve** : `captures/zooms/accueil-360-p1.png`, `captures/zooms/devs-360-p0.png`, `captures/echange-360.png`, `captures/evenements-360.png`
- **Impact** : il n'y a aucune preuve sociale. Le client doute de la pérennité, et le dev ne voit ni communauté ni demande.
- **Correctif** : tant qu'il y a moins de N éléments, masquer ou remplacer ces sections sur l'accueil (bloc « Soyez parmi les premiers » + bénéfices + témoignages d'early adopters). Amorcer le contenu (3 à 5 applis de démo propres, quelques discussions de bienvenue, un événement de lancement). Masquer les badges « Débutant » et « Pas disponible » tant que le profil n'est pas rempli, et inciter à compléter le profil.

### UX-013 · Cibles tactiles sous 44 px sur mobile
- **Sévérité** : Mineur
- **Repro** : à 360 px, liens du pied de page (16 px de haut, 15 liens empilés), fil d'Ariane « Store » sur la fiche (31×20), lien auteur sur la fiche (185×16), case « Disponibles seulement » sur `/devs` (20×20), liens de dépôts sur `/devs/octavebahoun` (294×24), « Parcourir le Store » sur `/connexion` (119×20).
- **Preuve** : `captures/zooms/accueil-360-p2.png`, `captures/zooms/fiche-appli-360-p0.png`, `captures/zooms/devs-360-p0.png`, `mesures.json`
- **Impact** : des taps ratés sur des téléphones d'entrée de gamme, surtout dans le pied de page, où les liens sont serrés.
- **Correctif** : prévoir un `min-height: 44px` (ou du padding vertical) sur les liens de liste et de pied de page, une zone cliquable étendue sur la case à cocher (label en `display:flex` de 44 px) et un padding sur le fil d'Ariane.

### UX-014 · Beaucoup de texte à 11–13 px sur mobile
- **Sévérité** : Mineur
- **Repro** : à 360 px, barre de navigation basse en 11 px, « Souk Score » et badges de profil en 11 px, sur-titres et badges en 12 px, puces de filtres, méta, détail du prix, chips de besoins et tableau des failles en 13 px. Le placeholder de la recherche du Store est aussi en 13 px.
- **Preuve** : `captures/zooms/fiche-appli-360-p0.png`, `captures/zooms/dev-profil-360-p0.png`, `captures/zooms/devs-360-p0.png`, `mesures.json`
- **Impact** : fatigue de lecture en plein soleil ou sur un écran bas de gamme, en particulier pour le client non technique.
- **Correctif** : 14 px minimum pour tout texte informatif (prix, méta, descriptions), 12 px minimum pour les libellés de navigation, 12 px uniquement pour les sur-titres en capitales. Vérifier le contraste du gris secondaire en clair.

### UX-015 · « Proposer une mission » proposé sur des devs « Pas disponible »
- **Sévérité** : Mineur
- **Repro** : `/devs` et `/devs/octavebahoun`, 360 px : badge « Pas disponible » à côté d'un bouton primaire « Proposer une mission ».
- **Preuve** : `captures/zooms/devs-360-p0.png`, `captures/zooms/dev-profil-360-p0.png`
- **Impact** : le client envoie une demande vouée à l'échec, d'où frustration et image d'une plateforme peu fiable.
- **Correctif** : bouton secondaire « Prévenir quand disponible », ou mention « répond rarement en ce moment ». Trier les devs disponibles en premier par défaut.

### UX-016 · Échange : groupes de canaux vides et actions réservées aux membres non signalées
- **Sévérité** : Mineur
- **Repro** : `/echange`, 1440 px : la colonne gauche affiche les titres « GÉNÉRAUX » et « PAR PAYS » sans aucun canal dessous. « Nouvelle discussion » et « Créer un canal » apparaissent comme des actions disponibles en invité. À 360 px, la liste devient un `<select>` « Tous les canaux ».
- **Preuve** : `captures/echange-1440.png`, `captures/zooms/echange-360-p0.png`
- **Impact** : l'interface paraît cassée ou vide. Le dev clique sur « Nouvelle discussion » sans savoir qu'il faut un compte.
- **Correctif** : masquer les groupes vides, ou créer des canaux par défaut (Bénin, Sénégal…). En invité, ajouter « (connexion requise) » ou une icône de cadenas, ou ouvrir directement la modale de connexion en expliquant pourquoi.

### UX-017 · Murs « Accès réservé » incohérents entre eux
- **Sévérité** : Mineur
- **Repro** : `/publier`, `/copies`, `/paiements` et `/missions`, 360 px : sur-titre « MON ESPACE », pas de pied de page et même texte générique pour tous. `/store/1/deployer` a un message spécifique et un pied de page.
- **Preuve** : `captures/publier-360.png`, `captures/copies-360.png`, `captures/deployer-360.png`
- **Impact** : l'expérience paraît décousue, et le message ne dit pas ce qu'on trouvera après connexion (« Mes copies » ≠ « Publier »).
- **Correctif** : un seul composant, avec un titre et un texte propres à chaque page (« Connectez-vous pour publier votre appli », « Retrouvez vos copies et factures »…), le même pied de page partout et un lien secondaire vers une page publique d'explication.

### UX-018 · La promesse en 5 s parle aux devs, pas aux clients
- **Sévérité** : Mineur
- **Repro** : `/`, 360 px, premier écran. Le H1 « Le marché des devs africains. » et le sous-titre « Postez un bug, un autre dev le corrige… » visent les devs. La valeur pour le client (« une entreprise la déploie en un clic ») arrive au milieu de la 2e phrase. Le bouton « Je cherche une appli » est bien présent.
- **Preuve** : `captures/zooms/accueil-360-p0.png`, `captures/zooms/accueil-1440-p0.png`
- **Impact** : le dev comprend en 5 s, mais la pharmacie ne se reconnaît pas et peut partir.
- **Correctif** : ajouter une phrase pour le client (« Des applis prêtes à l'emploi pour votre commerce, payées en Mobile Money »), ou un sous-titre à deux colonnes « Vous êtes dev / Vous êtes une entreprise ». Les réassurances (« 0 % de commission ») parlent aux devs : ajouter « Sans serveur à gérer » pour les clients.

### UX-019 · Thème sombre : les illustrations de l'accueil gardent des fonds clairs
- **Sévérité** : Cosmétique
- **Repro** : `/`, 360 et 768 px, thème sombre : les 3 cartes « Comment ça marche » montrent des panneaux bleu très clair dans un environnement sombre.
- **Preuve** : `captures/zooms/accueil-360-sombre-p0.png`, `captures/zooms/accueil-768-sombre-p0.png`
- **Impact** : effet d'éblouissement et rupture de cohérence (le reste du thème sombre est réussi).
- **Correctif** : prévoir des variantes sombres des illustrations (`<picture>` + `prefers-color-scheme`, ou la classe du thème) ou des fonds transparents.

### UX-020 · Typographie française et unités incohérentes
- **Sévérité** : Cosmétique
- **Repro** : 404 (`/page-qui-nexiste-pas-xyz`) : apostrophes droites (« n'existe », « l'accueil », « l'adresse »), alors que le reste du site utilise des apostrophes typographiques. `/publier` à 360 px : le deux-points est rejeté en début de ligne (« compte / : connectez-vous »), faute d'espace insécable. Les montants sont écrits tantôt « 3 500 F », tantôt « FCFA ».
- **Preuve** : `captures/404-360.png`, `captures/publier-360.png`, `captures/zooms/fiche-appli-360-p0.png`
- **Impact** : petits accrocs de finition dans un français par ailleurs très soigné.
- **Correctif** : utiliser des espaces insécables fines avant `: ; ? !` (un utilitaire de formatage), l'apostrophe typographique partout, et une unité unique (« 3 500 FCFA », ou « F CFA » expliqué une fois).

### UX-021 · Qualité du contenu de la fiche (titre technique, faute, description pauvre)
- **Sévérité** : Cosmétique
- **Repro** : `/store/1` et ses cartes : le titre est le slug du dépôt « portfolio-open » et la description, de 3 mots, contient une faute (« port**of**lio open source »). La section « À propos » reprend la même phrase.
- **Preuve** : `captures/zooms/fiche-appli-360-p0.png`, `captures/zooms/store-360-p0.png`
- **Impact** : le client ne sait pas à quoi sert l'appli, et le Store paraît peu soigné.
- **Correctif** : à la publication, demander un nom lisible, une description de 80 caractères minimum (problème résolu, pour qui) et 3 bénéfices, avec un aperçu de la carte et un correcteur orthographique. Ce contenu est à corriger par l'auteur.

---

## Points positifs à préserver
- Aucun débordement horizontal, sur aucune page, aucune largeur ni aucun thème.
- Bloc prix de la fiche très lisible (Appli / Hébergement / Commission 0 F / Total) : il ne reste qu'à corriger la hiérarchie (UX-003).
- La section « Qui paie quoi ? » de l'accueil est claire et honnête.
- États vides soignés, avec illustration et CTA (Échange, recherche du Store : « Aucune appli ne correspond à ces filtres · Réinitialiser les filtres », voir `captures/store-recherche-vide-360.png`), et une 404 personnalisée avec deux sorties.
- Thème sombre réussi (contrastes, champs, puces), bascule Clair / Sombre / Système accessible depuis le menu mobile.
- Connexion simple, avec deux portes claires (GitHub pour les devs, lien par e-mail pour les entreprises), la mention rassurante « Dépôts publics uniquement » et un champ e-mail bien typé.
- Barre de navigation basse sur mobile, anneau de focus visible, lien d'évitement.

## Top 5 des priorités
1. **Sécuriser la vitrine** (UX-001 + UX-002) : ne plus montrer d'appli critique sur l'accueil, résumer et replier le rapport de failles sur la fiche. Preuves : `captures/zooms/fiche-appli-360-p1.png`, `captures/fiche-appli-360.png`
2. **Rendre le prix honnête au premier regard** (UX-003 + UX-004) : afficher le total mensuel en titre et les frais de paiement dans le récapitulatif. Preuves : `captures/zooms/fiche-appli-360-p0.png`, `captures/cgv-360.png`
3. **Installer la confiance** (UX-005 + UX-006) : Contact / support / mentions légales, et textes légaux validés sans bandeau « brouillon ». Preuves : `captures/zooms/accueil-360-p2.png`, `captures/cgu-360.png`
4. **Ouvrir le parcours « publier » au dev mobile** (UX-008 + UX-009) : page `/publier` publique et pédagogique, CTA et recherche dans le menu mobile et à 768 px. Preuves : `captures/publier-360.png`, `captures/menu-ouvert-360.png`
5. **Remplacer la capture d'écran personnelle et cadrer l'envoi des captures** (UX-007). Preuve : `captures/zooms/capture-appli-1-haut.png`

## Ce qui nécessite un compte de test (parcours connectés, à auditer séparément)
- **Dev** (compte GitHub de test) : formulaire `/publier` (liaison du dépôt, `soukdev.json`, choix du prix, messages d'erreur de l'analyse), `/apps` et `/apps/verification`, édition de `/profil`, création d'une discussion et proposition de correctif dans l'Échange, création de canal et d'événement, `/revenus` (saisie du numéro Mobile Money de reversement), `/notifications` et ses réglages, `/tableau`, `/missions`.
- **Client** (compte e-mail de test, lien magique) : `/store/1/deployer` (choix de formule, variables, récapitulatif, présence des frais de paiement), redirection SasPay (en sandbox ou simulateur), `/paiement/retour` (succès, échec, en attente), `/paiements`, `/factures` et une facture, `/copies` (états : en cours, active, suspendue, erreur ; mise à jour, sauvegarde), signalement d'une appli, dépôt d'un avis.
- **Transverses** : retour à la page d'origine après connexion, modale de connexion (`ModaleConnexion`), états de chargement et d'erreur réseau sur les pages connectées, déconnexion, notifications temps réel, thème sombre sur toutes ces pages.

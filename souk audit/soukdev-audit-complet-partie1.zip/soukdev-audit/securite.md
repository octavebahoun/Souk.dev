# Audit sécurité — Souk.dev

Cible : https://soukdev.shop  
API : https://api.soukdev.shop  
Statut : **TERMINÉ (périmètre livré au 2026-11-10 12:20 Europe/Paris)** — restes listés en fin de fichier (non bloquants pour le rapport)
Mis à jour : 2026-11-10T12:20+01:00 (Europe/Paris)

## Synthèse (pour le rapport final)
- **Critique** : aucun.
- **Élevée** : SEC-006 (HTTP clair → 500 Pingora, pas de redirect HTTPS).
- **Moyenne** : SEC-004 (magic link en spam, domaine d'envoi tiers), SEC-005 (HSTS absent), SEC-007 (CSP `frame-src https:` / `style-src 'unsafe-inline'`), SEC-010 (cookies `Domain=.soukdev.shop`), SEC-011 (`/auth/demo` enregistré en prod, garde OK), SEC-013 (Trivy ne bloque pas la publication), SEC-014 (`VITE_REVERB_KEY` cassée).
- **Faible / Info** : SEC-001/002/003/008/009/012/015 ; positifs SEC-016 (admin API 403), SEC-017 (pas d'IDOR lecture), SEC-018 (OAuth Dev scopes minimaux).
- **Verdict promesse « chaque appli analysée avant publication »** : vraie pour les secrets (gitleaks bloquant, fail-closed), fausse pour les dépendances (Trivy = badge a posteriori).

## Méthode
- Non destructif, comptes de test uniquement, ne rien payer, secrets masqués.
- Références : OWASP Top 10, ASVS.

## Auth observée (surface publique)
- `/connexion` : profil Développeur → GitHub OAuth ; profil Entreprise/particulier → magic link email (pas de mot de passe).
- OAuth authorize : `client_id=Ov23li…q0Me`, `redirect_uri=https://api.soukdev.shop/auth/github/callback`.

Preuves recon détaillées : `/workspace/souk-audit/RAPPORT-RECON-PASSIVE.md`.

## Constats

### SEC-001 — Scopes OAuth GitHub demandés
- **Sévérité** : Info (positif) / Faible (écart marketing)
- **OWASP** : A01 Broken Access Control / ASVS V3 Session / V10
- **Reproduction** : `curl -sI --max-redirs 0 'https://api.soukdev.shop/auth/github?profil=dev'` → Location vers `github.com/login/oauth/authorize?...&scope=user%3Aemail%2Cread%3Auser`
- **Preuve** : scopes demandés = `user:email` + `read:user` uniquement (pas de `repo`, `public_repo`, `workflow`, etc.).
- **Impact** : le consentement OAuth ne donne pas d’accès aux dépôts via le token OAuth. Cohérent avec le principe du moindre privilège. Écart possible avec le copy « seuls les dépôts publics » : si l’app lit les repos via autre mécanisme (token installé, autre flow, scraping), à vérifier après login.
- **Correctif** : documenter clairement dans l’UI ce que le token OAuth permet réellement ; si un scope repo est ajouté plus tard, le justifier et le demander au moment d’usage (incremental auth).

### SEC-002 — Cookies de session API (premier coup d’œil)
- **Sévérité** : Info (bonnes pratiques présentes)
- **Reproduction** : même requête OAuth init ; Set-Cookie sur `.soukdev.shop`
- **Preuve** : `laravel-session` → Secure, HttpOnly, SameSite=Lax ; `XSRF-TOKEN` → Secure, SameSite=Lax, **sans** HttpOnly (attendu pour double-submit CSRF côté JS).
- **Impact** : configuration session raisonnable ; à confirmer côté front `soukdev.shop` et durée Max-Age (ici 7200 s).
- **Correctif** : envisager SameSite=Strict ou Lax+CSRF selon flux cross-site ; documenter rotation/invalidation logout.

### SEC-003 — Stack / en-têtes (partiel, API)
- **Sévérité** : Info
- **Preuve** : `Server: FrankenPHP Caddy` ; CSP stricte sur l’API (`default-src 'none'`, `frame-ancestors 'none'`) ; `X-Frame-Options: DENY` ; `X-Content-Type-Options: nosniff` ; rate-limit headers `x-ratelimit-limit: 60`.
- **Impact** : stack identifiable ; CSP API bonne. À croiser avec les en-têtes du front `soukdev.shop`.
- **Correctif** : masquer ou génériquer `Server` si politique de hardening ; poursuivre audit CSP sur le front.

## Comptes de test
- Entreprise A/B : magic link via inbox bot (`+audit-sec-a` / `+audit-sec-b`) — créés et utilisés (B = id 7, client).
- Dev : OAuth avec GitHub `octavebahoun` (décision Octave) ; uniquement dépôts publics `audit-` ; stop si mdp/2FA.

### SEC-004 — Magic link email classé spam + domaine d’envoi tiers
- **Sévérité** : Moyenne (délivrabilité / confiance) ; Faible (phishing UX)
- **OWASP** : A07 Identification and Authentication Failures / ASVS V2
- **Reproduction** : demander un lien sur `/connexion` (profil Entreprise) vers une boîte réelle ; observer le dossier spam.
- **Preuve** : mail « Votre lien de connexion Souk.dev » reçu depuis `souk@send.excellenceteam.site` (pas `@soukdev.shop`), classé spam par le filtre inbox ; lien unique 15 min vers `api.soukdev.shop/auth/lien-magique/<token>` (token masqué).
- **Impact** : utilisateurs légitimes peuvent manquer le login ; domaine d’envoi non aligné sur la marque facilite le phishing ; token dans l’URL (logs proxy, Referer, historique).
- **Correctif** : SPF/DKIM/DMARC alignés sur `soukdev.shop` (ou sous-domaine auth dédié) ; From cohérent ; éviter le token dans le path si possible (POST one-time) ; headers List-Unsubscribe / branding clair ; tests délivrabilité.

Mis à jour : 2026-11-10T01:30:33+01:00 (Europe/Paris)

### SEC-005 — HSTS absent (front + API)
- **Sévérité** : Moyenne
- **OWASP** : A02 Cryptographic Failures / ASVS V9
- **Reproduction** : `curl -sI https://soukdev.shop/` et `curl -sI https://api.soukdev.shop/api/apps` — aucun `Strict-Transport-Security`.
- **Preuve** : en-têtes front listent CSP, XFO, XCTO, Referrer-Policy, Permissions-Policy ; **pas** HSTS. Idem API.
- **Impact** : pas de sticky HTTPS pour les navigateurs ; aggravé par SEC-006 (HTTP clair cassé).
- **Correctif** : `Strict-Transport-Security: max-age=31536000; includeSubDomains; preload` sur apex, www, api, reverb (après redirect HTTPS fiable).

### SEC-006 — HTTP clair renvoie 500 Pingora (pas de redirect HTTPS)
- **Sévérité** : Élevée
- **OWASP** : A02 / A05 Security Misconfiguration
- **Reproduction** : `curl -sI http://soukdev.shop/` et `http://www.soukdev.shop/` → `HTTP/1.1 500` `Server: Pingora`, body vide, pas de `Location: https://…`.
- **Preuve** : confirmé 10 nov 2026 Europe/Paris ; HTTPS apex OK ; `https://www` → 301 apex.
- **Impact** : utilisateurs / clients HTTP (liens, HSTS preload absent, bookmarks) voient une erreur au lieu d’être élevés en HTTPS ; surface de MITM / confusion ; mauvaise hygiène edge.
- **Correctif** : sur l’edge Pingora/Caddy, **301/308** systématique `http://` → `https://` (apex + www) avant toute app ; alerter si 5xx sur :80.

### SEC-007 — CSP front : `style-src 'unsafe-inline'` et `frame-src https:` trop large
- **Sévérité** : Moyenne (frame-src) / Faible-Moyenne (style-src)
- **OWASP** : A03 Injection / ASVS V14
- **Reproduction** : `curl -sI https://soukdev.shop/` → CSP.
- **Preuve** : `style-src 'self' 'unsafe-inline'` ; `frame-src https:` (tout HTTPS) ; `script-src` limité à `'self'` + 2 hashes (bon).
- **Impact** : XSS CSS possible si injection HTML ; `frame-src https:` permet d’iframe n’importe quel site HTTPS (clickjacking inverse / phishing embed) — à restreindre aux domaines SasPay / nécessaires.
- **Correctif** : retirer unsafe-inline styles (hashes/nonces) ; `frame-src` allowlist explicite (ex. domaines paiement).

### SEC-008 — CORS API : origine figée (positif)
- **Sévérité** : Info
- **Reproduction** : `Origin: https://evil.example` ou `null` sur `GET /api/apps` → `Access-Control-Allow-Origin: https://soukdev.shop` (pas de reflet).
- **Impact** : bon ; credentials OK avec origin unique.
- **Correctif** : maintenir allowlist ; tests CI anti-reflet.

### SEC-009 — Catch-all SPA 200 sur chemins sensibles (pas de fuite .git/.env)
- **Sévérité** : Info / Faible (SEO soft-404)
- **Reproduction** : `/.git/HEAD`, `/.env`, `/robots.txt` → 200 `text/html` shell SPA (pas le contenu git/env).
- **Impact** : pas d’exposition .git/.env sur le front ; en revanche pas de robots/security.txt réels (hors scope Perf SEO) et `/admin` UI chargeable — **auth doit rester API-only**.
- **Correctif** : 404/403 edge pour `/.git`, `/.env` ; robots réels ; garde API sur `/api/admin/*` (déjà 401 observé non auth).

Mis à jour : 2026-11-10T01:31:47+01:00 (Europe/Paris)

### SEC-010 — Cookies Sanctum `Domain=.soukdev.shop` (partage sous-domaines)
- **Sévérité** : Moyenne
- **OWASP** : A07 Auth Failures / ASVS V3
- **Reproduction** : `curl -sI https://api.soukdev.shop/sanctum/csrf-cookie` → `laravel-session` et `XSRF-TOKEN` avec `Domain=.soukdev.shop`.
- **Preuve** : Domain apex-wide ; Secure + SameSite=Lax ; session HttpOnly ; Max-Age ~7200. Nécessaire au modèle SPA Sanctum cross-subdomain, mais élargit la surface.
- **Impact** : XSS ou contenu hostile sur **n’importe quel** sous-domaine `*.soukdev.shop` (ex. copie déployée mal configurée sur le même parent — le prod.example refuse justement DOMAINE_COPIES sous le même apex) peut voler/utiliser la session.
- **Correctif** : garder les copies sur un **domaine distinct** (déjà documenté) ; auditer qu’aucun user-content n’est servi sous `*.soukdev.shop` ; envisager host-only cookies si le modèle le permet ; Cookie Prefixes `__Host-` si Domain retiré.

Mis à jour : 2026-11-10T01:32:47+01:00 (Europe/Paris)

### SEC-011 — `POST /auth/demo` enregistré en prod mais garde active (404)
- **Sévérité** : Moyenne (surface / info) — **pas** de bypass constaté
- **OWASP** : A01 Broken Access Control / A05 Misconfiguration · ASVS V4
- **Reproduction** :
  1. `GET /auth/demo` → **405** `Allow: POST` (révèle la route).
  2. CSRF via `/sanctum/csrf-cookie` puis `POST /auth/demo` JSON `{"compte":"soukdemo-awa"}` (+ `X-XSRF-TOKEN`) → **404** `Introuvable.`
  3. Idem `soukdemo-admin`, `soukdemo-pharmacie` ; `/api/me` reste **401**.
- **Preuve** : aligné tests `DemoTest` (ferme en production même si `demo_connexion=true`) ; OpenAPI dit « jamais en prod » mais `routes/web.php` enregistre toujours la route + throttle.
- **Impact** : pas de session démo obtenue ; surface d’attaque / fingerprinting (405) ; risque de régression si la garde env est un jour cassée.
- **Correctif** : n’enregistrer `Route::post('/auth/demo', …)` que hors production (`APP_ENV` + `DEMO_CONNEXION`) ; en prod **404 uniforme** aussi sur GET (pas de liste de méthodes) ; alerte CI si la route apparaît en build prod.

Réf. croisée : API Souk API-01 (sévérité revue après POST contrôlé).  
Mis à jour : 2026-11-10T01:37:40+01:00 (Europe/Paris)

### SEC-012 — Admin UI SPA rendue pour non-admin ; API 403 (contrôle côté API OK)
- **Sévérité** : Faible (UI) / Info(+) API
- **OWASP** : A01 Broken Access Control
- **Reproduction** : compte Entreprise B connecté (UI) ; ouvrir `/admin/finances`, `/admin/moderation` → UI admin se charge ; requêtes API → **403**. `/admin/serveurs` affiche « Accès réservé ».
- **Impact** : fuite de structure UI admin / surface d’attaque client ; pas d’accès données si API tient (observé 403).
- **Correctif** : garde de route front sur `est_admin` ; ne pas lazy-load chunks admin pour non-admin ; conserver 403 API.

### SEC-013 — Écart promesse « analyse avant publication » (gitleaks dur / Trivy soft)
- **Sévérité** : Moyenne
- **Réf.** : notes-secrets-verif.md SEC-S04
- **Preuve** : secrets → 422/503 fail-closed ; CVE dépendances Trivy → badge post-publication, **ne bloque pas**.
- **Impact** : une appli avec CVE HIGH/CRITICAL peut être publiée/déployée avec badge `problemes`.
- **Correctif** : clarifier copy ; option bloquer déploiement si `securite_statut !== verifie`.

### SEC-014 — `VITE_REVERB_KEY` live = littéral « Secrets déjà présents. »
- **Sévérité** : Moyenne (dispo temps réel / hygiène build)
- **Réf.** : SEC-S05
- **Impact** : Echo/Reverb côté client probablement cassé ; erreur d’injection au build front.
- **Correctif** : rebuild avec vraie clé depuis `secrets_publics/public.env` ; smoke test format clé.

### SEC-015 — Session magic-link : 401 transitoire non reproduit
- **Sévérité** : Info (non confirmé)
- **Reproduction** : après magic link B, un passage avait vu UI connectée + `/api/me` 401 ; **retest** (reload Store) → `GET /api/me` **200**, `GET /sanctum/csrf-cookie` **204**.
- **Impact** : pas de faille durable prouvée ; possible course juste après consommation du lien. Surveiller.
- **Correctif** : s’assurer que le front n’affiche le menu compte qu’après `/api/me` 200 ; retry CSRF+me après magic link.
- Mis à jour : 2026-11-10T01:40:12+01:00 (Europe/Paris)

Détail secrets/verif : `/workspace/soukdev-audit/notes-secrets-verif.md`  
Mis à jour : 2026-11-10T01:38:33+01:00 (Europe/Paris)

### SEC-016 — Contrôle d’accès admin API (compte client B) — OK
- **Sévérité** : Info (positif)
- **Reproduction** : session B (`id=7`, `profil=client`, `est_admin=false`) ; `GET /api/admin/finances|factures|signalements|machines` → **403** `Action non autorisée.` ; UI `/admin/*` finit sur Accès réservé (sauf formulaire « Ajouter un serveur » encore rendu après 403 — voir SEC-012).
- **Impact** : pas d’accès données admin pour un client Entreprise.
- **Correctif** : masquer complètement le formulaire `/admin/serveurs` côté front si 403.

### SEC-017 — IDOR lecture (compte B) — aucun constat
- **Sévérité** : Info (positif, périmètre limité)
- **Reproduction** : `GET /api/factures/1` → 404 ; `/copies`, `/paiements`, `/missions`, `/me/*` → listes vides / zéros propres ; profils `/api/devs/*` publics sans email ; fiche Store app 1 sans contrôles owner.
- **Limite** : peu de ressources privées créées sur A/B ; à rejouer après création de facture/mission/déploiement de test (sans paiement réel) et avec session A croisée.
- **Correctif** : n/a ; compléter batterie IDOR quand données de test existent.

Mis à jour : 2026-11-10T01:46:22+01:00 (Europe/Paris)

## Couverture
- [x] Recon headers/CORS/fichiers sensibles/secrets front
- [x] Comptes magic-link A/B
- [x] OAuth Dev + scopes au consentement (SEC-018)
- [x] Admin API / IDOR lecture (SEC-016/017)
- [x] Promesse scan avant publication (SEC-013, analyse code)

### SEC-018 — Note de session : compte OAuth Dev = compte admin réel (Info / précaution d'audit)
- Connexion GitHub OAuth Dev (octavebahoun) le 2026-11-10 ~02:58 (UTC+1). Scopes demandés : `user:email,read:user` (conformes SEC-001).
- `GET /api/me` → id 1, profil `dev`, `est_admin: true` (email masqué o***@gmail.com).
- `GET /api/me/tableau-de-bord` → 200. Contrôles propriétaire visibles sur `portfolio-open` : « Relancer l'analyse », « Publier une nouvelle version » (non cliqués).
- Conséquence : ce compte n'est PAS un compte de test ; il sert seulement de point de vue admin en lecture. Aucune action d'écriture/admin ne sera faite avec. Les tests IDOR dev→dev exigent un 2e compte Dev de test (GitHub dédié `audit-…`).


## Non couvert (restes, hors délai du rapport)
- Tests actifs XSS / SQLi / CSRF sur mutateurs (seul le mécanisme CSRF Sanctum `X-XSRF-TOKEN` a été observé) et rate limiting au-delà de l'en-tête `x-ratelimit-limit: 60`.
- IDOR en écriture et IDOR dev→dev : nécessite un 2e compte Dev de test (le compte OAuth disponible est l'admin réel id 1, utilisé en lecture seule).
- Preuve dynamique « dépôt piégé » (dépôt public `audit-` avec faux secret) : non faite ; conclusion SEC-013 tirée du code.
- Reverb/WebSocket : seulement la clé de build (SEC-014), pas d'auth de canaux privés.

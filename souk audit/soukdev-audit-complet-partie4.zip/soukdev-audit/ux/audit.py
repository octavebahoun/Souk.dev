import asyncio, json, time, glob
from playwright.async_api import async_playwright
CH=glob.glob('/home/box/.cache/ms-playwright/chromium-1248/chrome-linux*/chrome')[0]
B='https://soukdev.shop'
PAGES={'accueil':'/','store':'/store','fiche-appli':'/store/1','echange':'/echange','devs':'/devs','evenements':'/evenements',
'connexion':'/connexion','connexion-dev':'/connexion?profil=dev','publier':'/publier','copies':'/copies',
'deployer':'/store/1/deployer','dev-profil':'/devs/octavebahoun','paiements':'/paiements','missions':'/missions','cgu':'/legal/cgu','cgv':'/legal/cgv','confidentialite':'/legal/confidentialite','abus':'/legal/abus','404':'/page-qui-nexiste-pas-xyz'}
VP=[(360,800),(390,844),(768,1024),(1440,900)]
JS='''(mobile)=>{
const iw=window.innerWidth, sw=document.documentElement.scrollWidth;
const over=[];document.querySelectorAll('body *').forEach(e=>{const r=e.getBoundingClientRect();if(r.right>iw+1&&r.width>0&&getComputedStyle(e).position!=='fixed')over.push(e.tagName+'.'+(e.className||'').toString().slice(0,40)+' r='+Math.round(r.right))});
const small=[];document.querySelectorAll('a,button,input,select,textarea,[role=button],summary').forEach(e=>{const r=e.getBoundingClientRect();if(r.width>0&&r.height>0&&(r.width<44||r.height<44)){small.push(((e.innerText||e.getAttribute('aria-label')||e.tagName)+'').trim().slice(0,30)+' '+Math.round(r.width)+'x'+Math.round(r.height))}});
const tiny={};const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;while(n=w.nextNode()){const t=n.textContent.trim();if(!t)continue;const p=n.parentElement;const cs=getComputedStyle(p);if(cs.display==='none'||cs.visibility==='hidden')continue;const r=p.getBoundingClientRect();if(!r.width)continue;const fs=parseFloat(cs.fontSize);if(fs<14){const k=fs+'px';(tiny[k]=tiny[k]||[]).push(t.slice(0,30))}}
const imgs=[...document.images].filter(i=>i.complete&&i.naturalWidth===0).map(i=>i.src);
return {iw,sw,overflow:sw>iw,over:over.slice(0,8),small:small.slice(0,40),nsmall:small.length,tiny:Object.fromEntries(Object.entries(tiny).map(([k,v])=>[k,[v.length,v.slice(0,8)]])),broken:imgs,title:document.title,h1:[...document.querySelectorAll('h1')].map(h=>h.innerText),lang:document.documentElement.lang}}'''
DARK={'accueil','store','fiche-appli','deployer','connexion','echange','devs','404'}
JOBS=[(n,p,w,h,'clair') for n,p in PAGES.items() for w,h in VP]+[(n,p,w,h,'sombre') for n,p in PAGES.items() if n in DARK for w,h in VP if w<1440]
res={}
async def one(b,sem,n,path,w,h,th):
  async with sem:
    mobile=w<768
    ctx=await b.new_context(viewport={'width':w,'height':h},is_mobile=mobile,has_touch=mobile,device_scale_factor=1,locale='fr-FR',color_scheme='dark' if th=='sombre' else 'light')
    pg=await ctx.new_page(); errs=[]; failed=[]
    pg.on('console',lambda m: errs.append(m.type+': '+m.text[:200]) if m.type in('error','warning') else None)
    pg.on('pageerror',lambda e: errs.append('pageerror: '+str(e)[:200]))
    pg.on('requestfailed',lambda r: failed.append(r.url[:120]))
    t=time.time(); suf='' if th=='clair' else '-sombre'
    try:
      r=await pg.goto(B+path,wait_until='load',timeout=45000)
      tl=round(time.time()-t,2)
      try: await pg.wait_for_load_state('networkidle',timeout=8000)
      except: pass
      tn=round(time.time()-t,2); await pg.wait_for_timeout(800)
      d=await pg.evaluate(JS,mobile)
      d.update(status=r.status if r else None,load_s=tl,idle_s=tn,url=pg.url,console=errs,failed=failed)
      await pg.screenshot(path=f'captures/{n}-{w}{suf}.png',full_page=True)
      if w==1440 or (w==360 and th=='clair'): d['text']=(await pg.inner_text('body'))[:6000]
      if mobile and n=='accueil':
        try:
          await pg.get_by_role('button',name='Menu').first.click(); await pg.wait_for_timeout(600)
          await pg.screenshot(path=f'captures/menu-ouvert-{w}{suf}.png')
        except Exception as e: d['menu_err']=str(e)[:200]
    except Exception as e: d={'error':str(e)[:300]}
    res[f'{n}-{w}{suf}']=d; print(n,w,th,d.get('status'),d.get('load_s'),d.get('overflow'),d.get('nsmall'),len(errs),flush=True)
    await ctx.close()
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path=CH); sem=asyncio.Semaphore(4)
    await asyncio.gather(*[one(b,sem,*j) for j in JOBS])
    await b.close()
  json.dump(res,open('mesures.json','w'),ensure_ascii=False,indent=1)
asyncio.run(main())

#!/bin/sh
# Une passe au démarrage : afficher la limite mémoire du cgroup, sans charge. Puis nginx.
LIMIT="indisponible"
SOURCE="aucune"
if [ -r /sys/fs/cgroup/memory.max ]; then
  LIMIT=$(cat /sys/fs/cgroup/memory.max)
  SOURCE=/sys/fs/cgroup/memory.max
elif [ -r /sys/fs/cgroup/memory/memory.limit_in_bytes ]; then
  LIMIT=$(cat /sys/fs/cgroup/memory/memory.limit_in_bytes)
  SOURCE=/sys/fs/cgroup/memory/memory.limit_in_bytes
fi

printf '%s\n' "$LIMIT" > /usr/share/nginx/html/memory.txt
printf 'source=%s\nlimit=%s\n' "$SOURCE" "$LIMIT" > /usr/share/nginx/html/memory-meta.txt

cat > /usr/share/nginx/html/index.html <<HTML
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>audit-amp-limites</title>
</head>
<body>
  <h1>audit-amp-limites</h1>
  <p>Dépôt d'audit inoffensif pour Souk.dev (DEP-02). Pas une application de production.</p>
  <p>Limite mémoire du conteneur web (<code>${SOURCE}</code>) : <strong>${LIMIT}</strong></p>
  <p>Valeur brute : <a href="/memory.txt">/memory.txt</a></p>
</body>
</html>
HTML

exec nginx -g "daemon off;"

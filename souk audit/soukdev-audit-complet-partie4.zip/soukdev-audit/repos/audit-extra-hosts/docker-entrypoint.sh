#!/bin/sh
# Une passe au démarrage, puis nginx. Pas de boucle, pas de scan, une seule requête HTTP.
OUT=/usr/share/nginx/html/probe.txt
{
  echo "=== /etc/hosts ==="
  cat /etc/hosts 2>/tmp/hosts.err || echo "error: $(cat /tmp/hosts.err)"
  echo
  echo "=== /etc/resolv.conf ==="
  cat /etc/resolv.conf 2>/tmp/resolv.err || echo "error: $(cat /tmp/resolv.err)"
  echo
  echo "=== HTTP GET http://host.docker.internal:80/ (timeout 2s, statut ou erreur uniquement) ==="
  HTTP_CODE=$(curl -sS -o /dev/null -w "%{http_code}" --connect-timeout 2 --max-time 2 http://host.docker.internal:80/ 2>/tmp/curl.err)
  RC=$?
  if [ "$RC" -eq 0 ]; then
    echo "http_code=${HTTP_CODE}"
  else
    echo "error=$(cat /tmp/curl.err)"
    echo "curl_exit=${RC}"
  fi
} > "$OUT"
exec nginx -g "daemon off;"
